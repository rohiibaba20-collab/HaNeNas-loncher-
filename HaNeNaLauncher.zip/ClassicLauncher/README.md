# HaNeNa Launcher (v1.5)

Android launcher (Kotlin). Features:
- 8 home layouts (Right list, Left list, Center, Dock row, Grid, Circle, Arc wheel (right side, default), Bottom wheel)
- Smooth round wheels + full-screen animation while spinning
- 6 clock styles, 6 fonts, 7 ready designs, color/size controls (text, icon, ring, clock, name, wheel, camera ring, volume bar)
- HaNeNa name on wallpaper (5 styles), wallpaper picker + dim control
- Volume-button animation, side-edge touch wave, selfie-camera ring
- Optional ABCD bar (Settings -> Home layout)
- Lock screen with face-scan animation (Settings -> Lock screen)

## GitHub se APK banane ke steps
1. Repository mein `HaNeNaLauncher.zip` upload karo (purani zip ki jagah) aur `.github/workflows/build.yml` rehne do.
2. Actions tab -> "Build APK from zip" apne aap chalega (3-5 min).
3. Run kholo -> Artifacts -> `HaNeNaLauncher-APK` -> `app-debug.apk` install karo.
4. Settings -> Default apps -> Home app -> HaNeNa Launcher.

Note: ab APK hamesha ek hi fixed key se sign hoti hai, isliye naya APK purani ke upar install ho jata hai
(sirf pehli baar purani APK uninstall karni padegi).

## v1.2 changes
- Saari apps: icons + search, long-press se Home mein jodo / App info / Uninstall
- Home ke favourite apps ab aap khud chun sakte hain (default list sirf tab jab kuch chuna na ho)
- App install/uninstall par home apne aap update
- Wallpaper background mein load hota hai (lag kam)
- Notification permission ka request (Android 13+, lock screen ke liye)

## v1.3 changes
- Charging clock: charger lagte hi landscape mein seconds ring + battery ring + bada waqt + date (Settings -> Charging clock). Touch karo to band, charger hatane par khud band.

## v1.4 changes
- Charging clock ke 6 design: Ring, Big digital, Analog, Flip, Wave, Neon (Settings -> Charging clock)
- Screen lock par bhi: charger lage aur screen band ho to clock khud screen on karke dikhati hai
- Charging clock settings: seconds, date, 12/24 ghanta, brightness, burn-in bachao, screen on
- 4 naye home layout: Glass dock, Side rail
- Advance settings: home apps ki ginti, naam dikhao/chhupao, swipe-up se saari apps, status bar chhupao

## v1.5 changes
- Minimal text aur Big cards hata diye; naye layout: Bubbles (tairte bubbles) aur Coverflow (smooth snap carousel)
- Mix rang: do rang milao (naam, icons, charging clock). Settings -> Rang -> Mix rang
