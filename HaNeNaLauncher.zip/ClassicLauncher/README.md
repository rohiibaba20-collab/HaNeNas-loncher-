# HaNeNa Launcher

Android launcher (Kotlin) with: 8 home layouts (3 round wheels), 6 clock styles, color/font/animation settings,
HaNeNa name on wallpaper, volume + edge-touch gold animations, selfie-camera ring, and a custom lock screen
with face-scan animation.

## GitHub se APK banane ke steps
1. Naya repository banao, is poore folder ki saari files upload karo (`.github` folder bhi).
2. Actions tab -> "Build APK" chalega (3-5 min).
3. Run kholo -> Artifacts -> `ClassicLauncher-APK` -> `app-debug.apk` install karo.
4. Settings -> Default apps -> Home app -> HaNeNa Launcher.
