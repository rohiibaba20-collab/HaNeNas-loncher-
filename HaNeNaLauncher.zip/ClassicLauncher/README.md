# HaNeNa Launcher (v1.6)

Android launcher (Kotlin). Features:
- 8 home layouts (Right list, Left list, Center, Dock row, Grid, Circle, Arc wheel (right side, default), Bottom wheel)
- Smooth round wheels + full-screen animation while spinning
- 6 clock styles, 6 fonts, 7 ready designs, color/size controls (text, icon, ring, clock, name, wheel, camera ring, volume bar)
- HaNeNa name on wallpaper (5 styles), wallpaper picker + dim control
- Volume-button animation, side-edge touch wave, selfie-camera ring
- Optional ABCD bar (Settings -> Home layout)
- Lock screen with face-scan animation (Settings -> Lock screen)

## GitHub se APK banane ke steps
1. Repository mein `HaNeNaLauncher.zip` upload karo (purani zip ki jagah) aur `.github/workflows/build.yml` rehne do.
2. Actions tab -> "Build APK from zip" apne aap chalega (3-5 min).
3. Run kholo -> Artifacts -> `HaNeNaLauncher-APK` -> `app-debug.apk` install karo.
4. Settings -> Default apps -> Home app -> HaNeNa Launcher.

Note: ab APK hamesha ek hi fixed key se sign hoti hai, isliye naya APK purani ke upar install ho jata hai
(sirf pehli baar purani APK uninstall karni padegi).

## v1.2 changes
- Saari apps: icons + search, long-press se Home mein jodo / App info / Uninstall
- Home ke favourite apps ab aap khud chun sakte hain (default list sirf tab jab kuch chuna na ho)
- App install/uninstall par home apne aap update
- Wallpaper background mein load hota hai (lag kam)
- Notification permission ka request (Android 13+, lock screen ke liye)

## v1.3 changes
- Charging clock: charger lagte hi landscape mein seconds ring + battery ring + bada waqt + date (Settings -> Charging clock). Touch karo to band, charger hatane par khud band.

## v1.4 changes
- Charging clock ke 6 design: Ring, Big digital, Analog, Flip, Wave, Neon (Settings -> Charging clock)
- Screen lock par bhi: charger lage aur screen band ho to clock khud screen on karke dikhati hai
- Charging clock settings: seconds, date, 12/24 ghanta, brightness, burn-in bachao, screen on
- 4 naye home layout: Glass dock, Side rail
- Advance settings: home apps ki ginti, naam dikhao/chhupao, swipe-up se saari apps, status bar chhupao

## v1.5 changes
- Minimal text aur Big cards hata diye; naye layout: Bubbles (tairte bubbles) aur Coverflow (smooth snap carousel)
- Mix rang: do rang milao (naam, icons, charging clock). Settings -> Rang -> Mix rang

## v1.6 changes
- **Music player (naya)**: phone ke gaane, 3 stylish style: Vinyl (ghoomta record), Neon bars (glow + naachti patti), Glass card.
  Long-press Home -> Music player, ya Saari apps -> HaNeNa Music. Notification, headset aur bluetooth ke buttons bhi chalte hain.
  Gaana chalte waqt Home par chhota music bar aata hai. Pehli baar music ki ijazat poochta hai.
- **Lock screen par music**: gaana ho to HaNeNa lock screen par chhota music card (prev / play / next) dikhta hai (Settings -> Music player).
- **Snapchat jaisa gol wheel**: item hamesha beech ki selector ring mein snap hota hai, bada ho kar chamakta hai, har item par halka haptic tick,
  ruk-te waqt halka bounce + click. Side wale item par tap = beech mein aaye, beech wale par tap = khule (band bhi kar sakte ho).
- **Auto mode** (Settings -> Auto mode): clock style khud badalta hai (har 30 minute / ghanta / roz), har hafte (Monday se) naya design,
  aur **Jume (Friday)** ke liye alag design, clock aur music style. Aapki apni settings delete nahi hoti, auto band karte hi wapas aa jati hain.

## v1.6.1 fixes and design
- **Spin animation ka rang idhar-udhar nahi failta**: pehle wheel ghoomne par poori screen par gold wash chadh jata tha (icons, clock, naam sab par) aur rukne ke baad bhi lagbhag 1 second rehta tha.
  Ab sirf wheel ke kinare par ek chamakti comet + halki ring dikhti hai, rukte hi turant gayab.
- **Icons ka rang barabar**: andhere icons pehle lagbhag kale ho jate the aur halke icons chamakte the, isliye har app ka rang alag lagta tha.
  Ab sab icons ek hi rang (duotone) mein barabar dikhte hain, aur asli rang kabhi beech mein nahi aata.
- **Music library naya design**: album art ke thumbnails, A-Z sections, glass search, jis gaane ko chal raha ho wo highlight (naachti patti), neeche chhota player, fast scroll.
- **App drawer naya design**: icon grid, glass search, A-Z side rail (bada akshar dikhta hai), favourite par star, animation.
  Settings, Rang mein switch: drawer ke icons asli rang mein ya theme rang mein.

