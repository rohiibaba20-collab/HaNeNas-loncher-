# HaNeNa Launcher (v1.1)

Android launcher (Kotlin). Features:
- 8 home layouts (Right list, Left list, Center, Dock row, Grid, Circle, Arc wheel (right side, default), Bottom wheel)
- Smooth round wheels + full-screen animation while spinning
- 6 clock styles, 6 fonts, 7 ready designs, color/size controls (text, icon, ring, clock, name, wheel, camera ring, volume bar)
- HaNeNa name on wallpaper (5 styles), wallpaper picker + dim control
- Volume-button animation, side-edge touch wave, selfie-camera ring
- Optional ABCD bar (Settings -> Home layout)
- Lock screen with face-scan animation (Settings -> Lock screen)

## GitHub se APK banane ke steps
1. Repository mein `HaNeNaLauncher.zip` upload karo (purani zip ki jagah) aur `.github/workflows/build.yml` rehne do.
2. Actions tab -> "Build APK from zip" apne aap chalega (3-5 min).
3. Run kholo -> Artifacts -> `HaNeNaLauncher-APK` -> `app-debug.apk` install karo.
4. Settings -> Default apps -> Home app -> HaNeNa Launcher.

Note: ab APK hamesha ek hi fixed key se sign hoti hai, isliye naya APK purani ke upar install ho jata hai
(sirf pehli baar purani APK uninstall karni padegi).
