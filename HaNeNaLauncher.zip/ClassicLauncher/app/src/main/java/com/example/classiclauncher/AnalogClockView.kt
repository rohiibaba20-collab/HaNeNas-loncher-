package com.example.classiclauncher

import android.content.Context
import android.graphics.*
import android.view.View
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class AnalogClockView(ctx: Context, private val accent: Int, private val tc: Int) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val tick = Runnable { invalidate() }

    override fun onMeasure(w: Int, h: Int) { val s = (150 * d).toInt(); setMeasuredDimension(s, s) }

    private fun hand(c: Canvas, cx: Float, cy: Float, deg: Float, len: Float, w: Float, col: Int) {
        val r = Math.toRadians((deg - 90).toDouble())
        p.color = col; p.strokeWidth = w
        c.drawLine(cx - 8 * d * cos(r).toFloat(), cy - 8 * d * sin(r).toFloat(),
            cx + len * cos(r).toFloat(), cy + len * sin(r).toFloat(), p)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = min(cx, cy) - 4 * d
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2 * d; p.color = accent; c.drawCircle(cx, cy, r, p)
        p.strokeWidth = d; p.color = Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent))
        c.drawCircle(cx, cy, r - 7 * d, p)
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0)
            val big = i % 3 == 0
            val l = if (big) 10 * d else 5 * d
            p.strokeWidth = if (big) 2.5f * d else 1.2f * d
            p.color = tc
            val r1 = r - 11 * d
            c.drawLine(cx + r1 * sin(a).toFloat(), cy - r1 * cos(a).toFloat(),
                cx + (r1 - l) * sin(a).toFloat(), cy - (r1 - l) * cos(a).toFloat(), p)
        }
        val cal = Calendar.getInstance()
        val s = cal.get(Calendar.SECOND).toFloat()
        val m = cal.get(Calendar.MINUTE) + s / 60f
        val h = cal.get(Calendar.HOUR) + m / 60f
        hand(c, cx, cy, h * 30f, r * 0.5f, 4 * d, tc)
        hand(c, cx, cy, m * 6f, r * 0.75f, 3 * d, tc)
        hand(c, cx, cy, s * 6f, r * 0.85f, 1.3f * d, accent)
        p.style = Paint.Style.FILL; p.color = accent
        c.drawCircle(cx, cy, 5 * d, p)
        removeCallbacks(tick); postDelayed(tick, 1000)
    }

    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }
}
