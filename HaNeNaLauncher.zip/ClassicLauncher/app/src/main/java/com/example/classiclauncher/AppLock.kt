package com.example.classiclauncher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import java.util.Calendar
import kotlin.math.min

/**
 * App lock jiska PIN samay ke hisab se badalta rehta hai.
 *
 *   PIN = (samay ka hissa + aapka 4-ank ka secret) ke aakhri 4 ank
 *   misal: abhi 14:35, secret 1234  ->  1435 + 1234 = 2669
 *
 * Samay ka hissa "kitni der mein PIN badle" se chunte hain: har minute (HHMM), har 10 minute, har ghanta (HH00) ya roz (DDMM).
 * Locked app Home, wheel ya Saari apps se kholne par PIN maangti hai. (Notification ya doosre launcher se khulne wali apps ko ye nahi rok sakta.)
 * Sab kuch alag file "applock" mein rehta hai, isliye "Reset settings" se lock nahi hatta.
 */
object AppLock {
    const val X_TARGET = "target"
    const val X_LABEL = "label"
    const val X_PKG = "pkg"
    const val X_VERIFY = "verify"

    val PERIODS = listOf("Har minute", "Har 10 minute", "Har ghanta", "Roz")
    val RELOCK = listOf("Har baar", "2 minute baad", "10 minute baad")

    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("applock", Context.MODE_PRIVATE)

    // pkg -> kab tak khula hai (sirf RAM mein, process band ho to dobara lock)
    private val unlocked = HashMap<String, Long>()

    fun secret(c: Context): String = sp(c).getString("secret", "") ?: ""
    fun setSecret(c: Context, s: String) { sp(c).edit().putString("secret", s).apply() }
    fun enabled(c: Context): Boolean = sp(c).getBoolean("on", false) && secret(c).length == 4
    fun setEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("on", v).apply() }
    fun period(c: Context): Int = sp(c).getInt("period", 0).coerceIn(0, PERIODS.size - 1)
    fun setPeriod(c: Context, v: Int) { sp(c).edit().putInt("period", v).apply() }
    fun relock(c: Context): Int = sp(c).getInt("relock", 1).coerceIn(0, RELOCK.size - 1)
    fun setRelock(c: Context, v: Int) { sp(c).edit().putInt("relock", v).apply() }
    fun fallback(c: Context): Boolean = sp(c).getBoolean("fallback", true)
    fun setFallback(c: Context, v: Boolean) { sp(c).edit().putBoolean("fallback", v).apply() }

    fun locked(c: Context): Set<String> =
        (sp(c).getString("pkgs", "") ?: "").split(",").filter { it.isNotBlank() }.toSet()

    fun isLocked(c: Context, pkg: String) = locked(c).contains(pkg)

    fun setLocked(c: Context, pkg: String, on: Boolean) {
        val s = locked(c).toMutableSet()
        if (on) s.add(pkg) else s.remove(pkg)
        sp(c).edit().putString("pkgs", s.joinToString(",")).apply()
    }

    // ------------------------------ time wala PIN ------------------------------
    private fun stepMs(p: Int): Long = when (p) {
        0 -> 60_000L
        1 -> 600_000L
        2 -> 3_600_000L
        else -> 86_400_000L
    }

    /** PIN mein jodne wala samay ka hissa (0 se 2359) */
    fun timePart(c: Context, millis: Long): Int {
        val cal = Calendar.getInstance().apply { timeInMillis = millis }
        val hh = cal.get(Calendar.HOUR_OF_DAY)
        val mm = cal.get(Calendar.MINUTE)
        return when (period(c)) {
            0 -> hh * 100 + mm
            1 -> hh * 100 + (mm / 10) * 10
            2 -> hh * 100
            else -> cal.get(Calendar.DAY_OF_MONTH) * 100 + cal.get(Calendar.MONTH) + 1
        }
    }

    fun pinAt(c: Context, millis: Long): String {
        val s = secret(c).toIntOrNull() ?: 0
        return "%04d".format((timePart(c, millis) + s) % 10000)
    }

    fun formulaText(c: Context): String = when (period(c)) {
        0 -> "samay (HHMM)"
        1 -> "samay (ghanta aur minute ka pehla ank, jaise 14:3x = 1430)"
        2 -> "ghanta (HH00, jaise 14:xx = 1400)"
        else -> "tareekh (DDMM, jaise 30 Oct = 3010)"
    } + " + secret"

    /** Abhi ka PIN, ya pichle slot ka (type karte waqt samay badal sakta hai) */
    fun check(c: Context, input: String): Boolean {
        val now = System.currentTimeMillis()
        val p = period(c)
        return input == pinAt(c, now) || (p < 3 && input == pinAt(c, now - stepMs(p)))
    }

    // ------------------------------ galat koshishon par rok ------------------------------
    fun lockedOutMs(c: Context): Long =
        (sp(c).getLong("until", 0L) - System.currentTimeMillis()).coerceAtLeast(0L)

    fun fail(c: Context) {
        val f = sp(c).getInt("fails", 0) + 1
        val e = sp(c).edit().putInt("fails", f)
        if (f % 5 == 0) {
            val sh = (f / 5 - 1).coerceAtMost(5)
            e.putLong("until", System.currentTimeMillis() + min(30_000L shl sh, 900_000L))
        }
        e.apply()
    }

    fun success(c: Context) { sp(c).edit().putInt("fails", 0).putLong("until", 0L).apply() }

    // ------------------------------ app kholne se pehle ------------------------------
    fun markUnlocked(c: Context, pkg: String) {
        val ms = when (relock(c)) { 0 -> 0L; 1 -> 120_000L; else -> 600_000L }
        if (ms > 0L) unlocked[pkg] = System.currentTimeMillis() + ms else unlocked.remove(pkg)
    }

    private fun recently(pkg: String) = (unlocked[pkg] ?: 0L) > System.currentTimeMillis()

    fun pkgOf(c: Context, i: Intent): String? =
        i.component?.packageName ?: i.`package` ?: c.packageManager.resolveActivity(i, 0)?.activityInfo?.packageName

    /** true = PIN screen khul gayi (PIN sahi hone par wahi app kholegi), isliye aap app mat kholo */
    fun guard(c: Context, i: Intent): Boolean {
        if (!enabled(c)) return false
        val pkg = pkgOf(c, i) ?: return false
        if (pkg == c.packageName || !isLocked(c, pkg) || recently(pkg)) return false
        c.startActivity(Intent(c, PinActivity::class.java).putExtra(X_TARGET, i).putExtra(X_PKG, pkg))
        return true
    }
}
