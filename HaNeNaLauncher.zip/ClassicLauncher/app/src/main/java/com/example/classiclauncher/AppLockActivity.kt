package com.example.classiclauncher

import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** App lock ki settings: on/off, secret number, PIN kitni der mein badle, kaun si apps lock hon. Pehle PIN poochta hai. */
class AppLockActivity : AppCompatActivity() {

    private class Entry(val label: String, val pkg: String, val icon: Drawable)

    private var apps = listOf<Entry>()
    private var accent = 0
    private var textC = 0
    private lateinit var tf: Typeface
    private lateinit var script: Typeface
    private lateinit var list: ListView
    private lateinit var headerBox: LinearLayout
    private var pinTv: TextView? = null
    private var infoTv: TextView? = null
    private var started = false
    private val hnd = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { updateLive(); hnd.postDelayed(this, 1000L) } }
    private val tfmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private val verify = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) start() else finish()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun al(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        accent = Prefs.get(this, Prefs.ACCENT)
        textC = Prefs.get(this, Prefs.TEXT)
        tf = Prefs.typeface(this, Prefs.get(this, Prefs.FONT))
        script = Prefs.typeface(this, 0)
        if (AppLock.enabled(this)) {
            verify.launch(Intent(this, PinActivity::class.java)
                .putExtra(AppLock.X_VERIFY, true).putExtra(AppLock.X_LABEL, "App lock settings"))
        } else start()
    }

    override fun onResume() { super.onResume(); if (started) { hnd.removeCallbacks(tick); hnd.post(tick) } }
    override fun onPause() { hnd.removeCallbacks(tick); super.onPause() }

    // ------------------------------ chhote helpers ------------------------------
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

    private fun tv(t: String, size: Float, color: Int, useScript: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); typeface = if (useScript) script else tf
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat(); setColor(Color.argb(26, 255, 255, 255)); setStroke(dp(1), al(accent, 70))
        }
    }

    private fun button(t: String, onTap: () -> Unit) = TextView(this).apply {
        text = t; textSize = 14f; typeface = tf; setTextColor(accent); gravity = Gravity.CENTER
        setPadding(dp(16), dp(10), dp(16), dp(10))
        background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), accent) }
        isClickable = true; setOnClickListener { onTap() }
    }

    private fun sw(on: Boolean, change: (Boolean) -> Unit) = Switch(this).apply {
        isChecked = on
        thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(accent, Color.GRAY))
        trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(al(accent, 120), Color.DKGRAY))
        setOnCheckedChangeListener { _, v -> change(v) }
    }

    private fun switchRow(t: String, on: Boolean, change: (Boolean) -> Unit) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        addView(tv(t, 15f, textC), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(10) })
        addView(sw(on, change))
    }

    private fun chips(opts: List<String>, sel: Int, pick: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var row: LinearLayout? = null
        opts.forEachIndexed { i, o ->
            if (i % 2 == 0) { row = LinearLayout(this); box.addView(row, lp(if (i == 0) 0 else 8)) }
            val on = i == sel
            row!!.addView(TextView(this).apply {
                text = o; textSize = 13f; typeface = tf; gravity = Gravity.CENTER
                setTextColor(if (on) Color.BLACK else textC)
                setPadding(dp(8), dp(10), dp(8), dp(10))
                background = GradientDrawable().apply {
                    cornerRadius = dp(18).toFloat()
                    if (on) setColor(accent) else { setColor(Color.argb(24, 255, 255, 255)); setStroke(dp(1), al(accent, 90)) }
                }
                isClickable = true; setOnClickListener { pick(i) }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        return box
    }

    // ------------------------------ screen ------------------------------
    private fun start() {
        if (started) return
        started = true
        val bgTop = ColorUtils.blendARGB(Color.BLACK, accent, 0.22f)
        window.statusBarColor = bgTop; window.navigationBarColor = Color.BLACK

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; fitsSystemWindows = true
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bgTop, Color.BLACK, Color.BLACK))
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(4), dp(20), 0) }
        head.addView(IconBtn(this, IconBtn.BACK).apply { color = accent; setOnClickListener { finish() } },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        head.addView(tv("App lock", 28f, textC, true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        root.addView(head, lp())

        headerBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        list = ListView(this).apply {
            divider = null; selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false; setPadding(0, 0, 0, dp(16))
            addHeaderView(headerBox, null, false)
            this.adapter = this@AppLockActivity.adapter
            setOnItemClickListener { _, v, p, _ ->
                if (p - headerViewsCount in apps.indices) ((v as LinearLayout).getChildAt(2) as Switch).toggle()
            }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        fillHeader()
        hnd.removeCallbacks(tick); hnd.post(tick)

        Thread {
            val pm = packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val res = pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { Entry(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
            runOnUiThread { apps = res; adapter.notifyDataSetChanged() }
        }.start()
    }

    private fun fillHeader() {
        headerBox.removeAllViews()
        val on = AppLock.enabled(this)
        val hasSecret = AppLock.secret(this).length == 4

        headerBox.addView(tv("Locked app Home, wheel ya Saari apps se kholne par PIN maangti hai. PIN samay ke hisab se badalta rehta hai: PIN = samay + aapka secret number.",
            13f, al(textC, 190)), lp(4))

        val c1 = card()
        c1.addView(switchRow("App lock on", on) { v ->
            if (v && !hasSecret) askSecret(enableAfter = true) else { AppLock.setEnabled(this, v); fillHeader() }
        })
        c1.addView(tv(if (hasSecret) "Secret number: ••••" else "Secret number abhi set nahi hai", 14f, al(textC, 200)), lp(12))
        c1.addView(button(if (hasSecret) "Secret number badlo" else "Secret number set karo") { askSecret(false) }, lp(10))
        headerBox.addView(c1, lp(12))

        if (hasSecret) {
            val c2 = card()
            c2.addView(tv("Abhi ka PIN", 13f, al(textC, 170)))
            val p = tv("----", 44f, accent, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.12f }
            val i = tv("", 12f, al(textC, 150)).apply { gravity = Gravity.CENTER }
            pinTv = p; infoTv = i
            c2.addView(p, lp(2)); c2.addView(i, lp(2))
            headerBox.addView(c2, lp(12))
            updateLive()

            val c3 = card()
            c3.addView(tv("PIN kitni der mein badle", 14f, textC))
            c3.addView(chips(AppLock.PERIODS, AppLock.period(this)) { AppLock.setPeriod(this, it); fillHeader() }, lp(10))
            c3.addView(tv("Ek baar kholne ke baad dobara PIN kab maange", 14f, textC), lp(16))
            c3.addView(chips(AppLock.RELOCK, AppLock.relock(this)) { AppLock.setRelock(this, it); fillHeader() }, lp(10))
            c3.addView(switchRow("PIN bhool jao to fingerprint / phone lock se bhi khule", AppLock.fallback(this)) { AppLock.setFallback(this, it) }, lp(16))
            headerBox.addView(c3, lp(12))
        }

        headerBox.addView(tv("Kaun si apps lock karni hain", 22f, accent, true), lp(20))
    }

    private fun updateLive() {
        val p = pinTv ?: return
        val now = System.currentTimeMillis()
        p.text = AppLock.pinAt(this, now)
        infoTv?.text = "Abhi ka samay ${tfmt.format(Date(now))}\nPIN = ${AppLock.formulaText(this)}\n" +
            "%04d + %s".format(AppLock.timePart(this, now), AppLock.secret(this))
    }

    private fun askSecret(enableAfter: Boolean) {
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            filters = arrayOf(InputFilter.LengthFilter(4))
            hint = "4 ank (jaise 1234)"; gravity = Gravity.CENTER; textSize = 24f
        }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Apna secret number (4 ank)")
            .setMessage("Ye yaad rakhna. Har baar PIN = abhi ka samay + ye secret.")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                val s = et.text.toString()
                if (s.length == 4) {
                    AppLock.setSecret(this, s)
                    if (enableAfter) AppLock.setEnabled(this, true)
                } else Toast.makeText(this, "Poore 4 ank daalo", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cancel", null)
            .setOnDismissListener { fillHeader() }
            .show()
    }

    // ------------------------------ apps ki list ------------------------------
    private val adapter = object : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(p: Int) = apps[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val row = (cv as? LinearLayout) ?: LinearLayout(this@AppLockActivity).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(dp(22), dp(8), dp(22), dp(8))
                addView(ImageView(context), LinearLayout.LayoutParams(dp(40), dp(40)))
                addView(TextView(context).apply { textSize = 15f; setSingleLine(true) },
                    LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(14); marginEnd = dp(10) })
                addView(sw(false) { })
            }
            val e = apps[p]
            (row.getChildAt(0) as ImageView).setImageDrawable(e.icon)
            (row.getChildAt(1) as TextView).apply { text = e.label; typeface = tf; setTextColor(textC) }
            val s = row.getChildAt(2) as Switch
            s.setOnCheckedChangeListener(null)
            s.isChecked = AppLock.isLocked(this@AppLockActivity, e.pkg)
            s.setOnCheckedChangeListener { _, v -> AppLock.setLocked(this@AppLockActivity, e.pkg, v) }
            return row
        }
    }
}
