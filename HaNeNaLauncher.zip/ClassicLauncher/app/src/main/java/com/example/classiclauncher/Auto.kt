package com.example.classiclauncher

import android.content.Context
import android.graphics.Color
import java.util.Calendar

/**
 * Auto mode: launcher ka look din / hafte ke hisab se khud badalta hai.
 *  - Har hafte (Monday se) naya ready design
 *  - Clock style har 30 minute / ghanta / roz khud badalta hai
 *  - Jume (Friday) ke liye alag design, clock aur music style
 * Ye sab "overlay" hai: aapki apni chuni hui settings delete nahi hoti, auto band karte hi wapas aa jati hain.
 */
object Auto {
    val KEYS = setOf(
        Prefs.ACCENT, Prefs.TEXT, Prefs.FONT, Prefs.LAYOUT, Prefs.FX, Prefs.NSTYLE,
        Prefs.CLOCK, Prefs.CHSTYLE, Prefs.MUSTYLE
    )

    private const val DAY = 86_400_000L

    private fun localMillis(): Long {
        val now = System.currentTimeMillis()
        return now + Calendar.getInstance().timeZone.getOffset(now)
    }

    private fun isFriday(c: Context): Boolean =
        Prefs.raw(c, Prefs.FRI) == 1 && Calendar.getInstance().get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY

    /** Monday se shuru hone wale hafte ka number */
    private fun weekNo(): Int {
        val days = Math.floorDiv(localMillis(), DAY)
        return Math.floorDiv(days - 4L, 7L).toInt()      // 1 Jan 1970 Thursday tha, Monday = din 4
    }

    private fun preset(c: Context, fri: Boolean): Preset? {
        if (fri) return Opts.presets[Prefs.raw(c, Prefs.FRIPRESET).coerceIn(0, Opts.presets.size - 1)]
        if (Prefs.raw(c, Prefs.AUTOWEEK) == 1) return Opts.presets[Math.floorMod(weekNo(), Opts.presets.size)]
        return null
    }

    private fun clockIdx(c: Context, fri: Boolean): Int? {
        if (fri) return Prefs.raw(c, Prefs.FRICLOCK).coerceIn(0, Opts.clocks.size - 1)
        val ivl = when (Prefs.raw(c, Prefs.AUTOROT)) {
            1 -> 30L * 60_000L
            2 -> 3_600_000L
            3 -> DAY
            else -> return null
        }
        return Math.floorMod(localMillis() / ivl, Opts.clocks.size.toLong()).toInt()
    }

    /** Is key ki auto value (null = auto kuch nahi badal raha, apni value chalegi) */
    fun eff(c: Context, k: String): Int? {
        val fri = isFriday(c)
        return when (k) {
            Prefs.CLOCK, Prefs.CHSTYLE -> clockIdx(c, fri)
            Prefs.MUSTYLE ->
                if (fri) Prefs.raw(c, Prefs.FRIMUSIC).coerceIn(0, Opts.musicStyles.size - 1)
                else if (Prefs.raw(c, Prefs.AUTOWEEK) == 1) Math.floorMod(weekNo(), Opts.musicStyles.size)
                else null
            else -> preset(c, fri)?.let { p ->
                when (k) {
                    Prefs.ACCENT -> Color.parseColor(p.accent)
                    Prefs.TEXT -> Color.parseColor(p.text)
                    Prefs.FONT -> p.font
                    Prefs.LAYOUT -> if (Prefs.raw(c, Prefs.AUTOLAY) == 1) p.layout else null
                    Prefs.FX -> p.fx
                    Prefs.NSTYLE -> p.nameStyle
                    else -> null
                }
            }
        }
    }

    /** Look (clock ke bina) badla ya nahi, ye pakadne ke liye */
    fun sig(c: Context): String =
        if (Prefs.raw(c, Prefs.AUTO) != 1) ""
        else listOf(Prefs.ACCENT, Prefs.TEXT, Prefs.FONT, Prefs.LAYOUT, Prefs.FX, Prefs.NSTYLE, Prefs.MUSTYLE)
            .joinToString(",") { Prefs.get(c, it).toString() }

    /** Settings mein dikhane ke liye ek line */
    fun status(c: Context): String {
        val fri = isFriday(c)
        val look = preset(c, fri)?.title ?: "Aapka apna design"
        val clock = Opts.clocks[Prefs.get(c, Prefs.CLOCK).coerceIn(0, Opts.clocks.size - 1)]
        val mus = Opts.musicStyles[Prefs.get(c, Prefs.MUSTYLE).coerceIn(0, Opts.musicStyles.size - 1)]
        return (if (fri) "Aaj Jume hai\n" else "") + "Design: $look\nClock: $clock\nMusic style: $mus"
    }
}
