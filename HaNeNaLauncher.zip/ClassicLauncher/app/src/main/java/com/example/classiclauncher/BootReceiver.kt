package com.example.classiclauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED &&
            LockService.wanted(c) && Settings.canDrawOverlays(c)) {
            try { ContextCompat.startForegroundService(c, Intent(c, LockService::class.java)) } catch (e: Exception) {}
        }
    }
}
