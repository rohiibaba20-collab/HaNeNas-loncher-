package com.example.classiclauncher

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat

/** HaNeNa Phone ki saari settings ek jagah (alag file "dialer") */
object DialerPrefs {
    const val FLASH = "flash"; const val FLASH_STYLE = "flash_style"; const val FLASH_WHEN = "flash_when"
    const val KEY_TONE = "key_tone"; const val KEY_HAPTIC = "key_haptic"; const val KEY_STYLE = "key_style"; const val KEY_SIZE = "key_size"
    const val CONFIRM = "confirm"; const val T9 = "t9"; const val PHOTOS = "photos"; const val SHOW_DUR = "show_dur"
    const val RECENTS_N = "recents_n"; const val FAVS = "favs"; const val SHOW_NAMES = "show_names"

    private fun sp(c: Context): SharedPreferences = c.applicationContext.getSharedPreferences("dialer", Context.MODE_PRIVATE)
    fun bool(c: Context, k: String, def: Boolean) = sp(c).getBoolean(k, def)
    fun setBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun int(c: Context, k: String, def: Int) = sp(c).getInt(k, def)
    fun setInt(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply() }
    fun str(c: Context, k: String) = sp(c).getString(k, "") ?: ""
    fun setStr(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }

    fun recentsLimit(c: Context): Int = when (int(c, RECENTS_N, 1)) { 0 -> 50; 1 -> 150; else -> 400 }

    fun favIds(c: Context): Set<Long> = str(c, FAVS).split(",").mapNotNull { it.toLongOrNull() }.toSet()
    fun toggleFav(c: Context, id: Long) {
        val s = favIds(c).toMutableSet()
        if (!s.add(id)) s.remove(id)
        setStr(c, FAVS, s.joinToString(","))
    }
}

/** Call aane par camera ki flash light (torch) alag alag andaaz mein chamkati hai */
object CallFlash {
    val STYLES = listOf("Tez blink", "Dheema pulse", "SOS", "Seedhi jalti rahe")
    val WHEN = listOf("Hamesha", "Sirf silent / vibrate par")

    private val h = Handler(Looper.getMainLooper())
    private var running = false
    private var idx = 0
    private var steady = false
    private var pattern = longArrayOf(160, 160)
    private var torchId: String? = null

    private fun pat(style: Int): LongArray = when (style) {
        0 -> longArrayOf(160, 160)
        1 -> longArrayOf(550, 550)
        2 -> longArrayOf(200, 200, 200, 200, 200, 600, 600, 200, 600, 200, 600, 600, 200, 200, 200, 200, 200, 1400)
        else -> longArrayOf(1000, 0)
    }

    private fun torch(cm: CameraManager, on: Boolean) {
        try { torchId?.let { cm.setTorchMode(it, on) } } catch (e: Exception) { }
    }

    fun start(ctx: Context, style: Int) {
        if (running) return
        val cm = ctx.applicationContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        torchId = try {
            cm.cameraIdList.firstOrNull {
                val ch = cm.getCameraCharacteristics(it)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        } catch (e: Exception) { null }
        if (torchId == null) return
        running = true; idx = 0; steady = style == 3; pattern = pat(style)
        if (steady) { torch(cm, true); return }
        step(cm)
    }

    private fun step(cm: CameraManager) {
        if (!running) return
        val on = idx % 2 == 0
        torch(cm, on)
        val dur = pattern[idx % pattern.size]
        idx++
        h.postDelayed({ step(cm) }, if (dur <= 0L) 1L else dur)
    }

    fun stop(ctx: Context) {
        val was = running
        running = false
        h.removeCallbacksAndMessages(null)
        if (was) torch(ctx.applicationContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager, false)
    }

    /** Settings mein "test" ke liye 3 second */
    fun test(ctx: Context, style: Int) {
        stop(ctx); start(ctx, style)
        h.postDelayed({ stop(ctx) }, 3500L)
    }

    /** Setting on ho aur ijazat ho to call dekhne wali service chalao, warna band */
    fun sync(ctx: Context) {
        val app = ctx.applicationContext
        val on = DialerPrefs.bool(app, DialerPrefs.FLASH, false) &&
            app.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        try {
            if (on) ContextCompat.startForegroundService(app, Intent(app, CallWatchService::class.java))
            else app.stopService(Intent(app, CallWatchService::class.java))
        } catch (e: Exception) { }
    }
}

/** Call ki halat sunti rehti hai (ring hote hi flash). Chhoti si silent notification dikhti hai. */
class CallWatchService : Service() {
    private var tm: TelephonyManager? = null
    private var legacy: PhoneStateListener? = null
    private var modern: Any? = null

    private fun onState(state: Int) {
        if (state == TelephonyManager.CALL_STATE_RINGING) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val onlySilent = DialerPrefs.int(this, DialerPrefs.FLASH_WHEN, 0) == 1
            if (!onlySilent || am.ringerMode != AudioManager.RINGER_MODE_NORMAL)
                CallFlash.start(this, DialerPrefs.int(this, DialerPrefs.FLASH_STYLE, 0))
        } else CallFlash.stop(this)
    }

    @RequiresApi(31)
    private inner class Cb : TelephonyCallback(), TelephonyCallback.CallStateListener {
        override fun onCallStateChanged(state: Int) { onState(state) }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("callflash", "Call flash alert", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "callflash")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Call par flash alert chalu")
            .setContentText("HaNeNa Phone settings se band kar sakte ho")
            .setOngoing(true).build()
        startForeground(4, n)
        val t = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        tm = t
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val c = Cb(); modern = c
                t.registerTelephonyCallback(ContextCompat.getMainExecutor(this), c)
            } else {
                @Suppress("DEPRECATION")
                val l = object : PhoneStateListener() {
                    override fun onCallStateChanged(state: Int, phoneNumber: String?) { onState(state) }
                }
                legacy = l
                t.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
            }
        } catch (e: Exception) { stopSelf() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try {
            if (Build.VERSION.SDK_INT >= 31) (modern as? TelephonyCallback)?.let { tm?.unregisterTelephonyCallback(it) }
            else legacy?.let { tm?.listen(it, PhoneStateListener.LISTEN_NONE) }
        } catch (e: Exception) { }
        CallFlash.stop(this)
        super.onDestroy()
    }
}
