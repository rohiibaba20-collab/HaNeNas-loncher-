package com.example.classiclauncher

import android.content.*
import android.graphics.Color
import android.os.BatteryManager
import android.os.Bundle
import android.text.format.DateFormat
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** Mobile charge par lagte hi landscape mein khoobsurat clock. Touch karo to band. */
class ChargeClockActivity : AppCompatActivity() {

    companion object {
        /** Clock abhi screen par hai? (power button dabane par dobara na khule) */
        @Volatile var visible = false
    }

    private lateinit var v: ChargeClockView
    private var test = false

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_POWER_DISCONNECTED -> if (!test) finish()
                Intent.ACTION_BATTERY_CHANGED -> update(i)
            }
        }
    }

    private fun update(i: Intent) {
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        v.level = lvl * 100 / scale
        v.charging = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        if (!v.charging && !test) finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        test = intent.getBooleanExtra("test", false)
        setShowWhenLocked(true)
        if (intent.getBooleanExtra("wake", false)) setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val bright = Prefs.get(this, Prefs.CHBRIGHT).coerceIn(5, 100) / 100f
        window.attributes = window.attributes.apply {
            screenBrightness = bright
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        v = ChargeClockView(this).apply {
            accent = Prefs.get(this@ChargeClockActivity, Prefs.ACCENT)
            textC = Prefs.get(this@ChargeClockActivity, Prefs.TEXT)
            accent2 = if (Prefs.mixOn(this@ChargeClockActivity, Prefs.MIXCHG)) Prefs.get(this@ChargeClockActivity, Prefs.ACCENT2) else 0
            tf = Prefs.typeface(this@ChargeClockActivity, 2)
            scriptTf = Prefs.typeface(this@ChargeClockActivity, 0)
            name = Prefs.name(this@ChargeClockActivity)
            is24 = when (Prefs.get(this@ChargeClockActivity, Prefs.CH24)) {
                1 -> false
                2 -> true
                else -> DateFormat.is24HourFormat(this@ChargeClockActivity)
            }
            style = Prefs.get(this@ChargeClockActivity, Prefs.CHSTYLE)
            showSec = Prefs.get(this@ChargeClockActivity, Prefs.CHSEC) == 1
            showDate = Prefs.get(this@ChargeClockActivity, Prefs.CHDATE) == 1
            drift = Prefs.get(this@ChargeClockActivity, Prefs.CHDRIFT) == 1
            setOnClickListener { finish() }
        }
        setContentView(v)
        WindowInsetsControllerCompat(window, v).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onStart() {
        super.onStart()
        visible = true
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED); addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        registerReceiver(rx, f)?.let { update(it) }
    }

    override fun onStop() {
        visible = false
        try { unregisterReceiver(rx) } catch (e: Exception) {}
        super.onStop()
    }
}
