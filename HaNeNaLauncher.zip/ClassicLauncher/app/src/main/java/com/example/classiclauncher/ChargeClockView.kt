package com.example.classiclauncher

import android.content.Context
import android.graphics.*
import android.view.View
import java.text.SimpleDateFormat
import java.util.*
import androidx.core.graphics.ColorUtils
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Charging ke waqt landscape clock: 6 alag design (style 0..5) */
class ChargeClockView(c: Context) : View(c) {

    var accent = Color.parseColor("#D4AF37")
    var accent2 = 0   // 0 = mix band
    private var baseAccent = 0
    var textC = Color.WHITE
    var tf: Typeface = Typeface.DEFAULT
    var scriptTf: Typeface = Typeface.DEFAULT
    var name = "HaNeNa"
    var level = 0
    var charging = true
    var is24 = false
    var style = 0
    var showSec = true
    var showDate = true
    var drift = true

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val dateFmt = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault())
    private val frame = object : Runnable {
        override fun run() { invalidate(); postDelayed(this, 33) }
    }

    private class T(val hh: String, val mm: String, val ss: String, val ap: String)

    init {
        setBackgroundColor(Color.BLACK)
        setLayerType(LAYER_TYPE_SOFTWARE, null)   // glow (shadow layer) ke liye
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(frame) }
    override fun onDetachedFromWindow() { removeCallbacks(frame); super.onDetachedFromWindow() }

    private fun withAlpha(col: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(col), Color.green(col), Color.blue(col))

    private fun timeOf(cal: Calendar): T {
        val h24 = cal.get(Calendar.HOUR_OF_DAY)
        val h = if (is24) h24 else (if (h24 % 12 == 0) 12 else h24 % 12)
        return T(
            if (is24) String.format(Locale.US, "%02d", h) else h.toString(),
            String.format(Locale.US, "%02d", cal.get(Calendar.MINUTE)),
            String.format(Locale.US, "%02d", cal.get(Calendar.SECOND)),
            if (is24) "" else (if (h24 < 12) "AM" else "PM"))
    }

    private fun dateText(cal: Calendar, t: T) =
        dateFmt.format(cal.time) + (if (t.ap.isEmpty()) "" else "   " + t.ap)

    private fun glow(col: Int, r: Float) = p.setShadowLayer(r, 0f, 0f, col)

    private fun bar(cv: Canvas, x: Float, y: Float, bw: Float, bh: Float, now: Long) {
        p.style = Paint.Style.FILL; p.color = Color.argb(40, 255, 255, 255)
        rect.set(x, y, x + bw, y + bh); cv.drawRoundRect(rect, bh / 2, bh / 2, p)
        val a = if (charging) (200 + 55 * sin(now / 450.0)).toInt() else 230
        p.color = withAlpha(if (level <= 15 && !charging) Color.parseColor("#FF4D4D") else accent, a)
        rect.set(x, y, x + bw * level.coerceIn(0, 100) / 100f, y + bh)
        cv.drawRoundRect(rect, bh / 2, bh / 2, p)
    }

    private fun nameTag(cv: Canvas, x: Float, y: Float, size: Float, align: Paint.Align) {
        p.style = Paint.Style.FILL; p.typeface = scriptTf; p.textAlign = align
        p.textSize = size; p.color = accent; glow(withAlpha(accent, 140), dp(10f))
        cv.drawText(name, x, y, p); p.clearShadowLayer()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w == 0f || h == 0f) return
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        val sec = cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000f
        if (accent2 != 0) {   // mix rang: dono rang dheere dheere ek doosre mein badalte hain
            if (baseAccent == 0) baseAccent = accent
            accent = ColorUtils.blendARGB(baseAccent, accent2, 0.5f + 0.5f * sin(now / 1500.0).toFloat())
        }
        cv.save()
        if (drift) {   // burn-in se bachne ke liye halka sa khisakna
            val d = now / 60000.0
            cv.translate((sin(d * 0.7) * dp(14f)).toFloat(), (cos(d * 0.9) * dp(10f)).toFloat())
        }
        when (style) {
            1 -> big(cv, w, h, now, cal, sec)
            2 -> analog(cv, w, h, now, cal, sec)
            3 -> flip(cv, w, h, now, cal, sec)
            4 -> wave(cv, w, h, now, cal)
            5 -> neon(cv, w, h, now, cal)
            else -> ring(cv, w, h, now, cal, sec)
        }
        cv.restore()
    }

    // ---------------- 0: Ring ----------------
    private fun ring(cv: Canvas, w: Float, h: Float, now: Long, cal: Calendar, sec: Float) {
        val cx = w * 0.27f; val cy = h / 2f
        val r = min(h * 0.33f, w * 0.19f)
        p.shader = null; p.style = Paint.Style.STROKE
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0 - 90)
            val big = i % 5 == 0
            val r1 = r * 1.2f; val r2 = r1 + dp(if (big) 11f else 6f)
            p.strokeWidth = dp(if (big) 2.2f else 1.2f)
            p.color = if (showSec && i <= sec.toInt()) withAlpha(accent, if (big) 255 else 190) else Color.argb(if (big) 110 else 60, 255, 255, 255)
            cv.drawLine(cx + (cos(a) * r1).toFloat(), cy + (sin(a) * r1).toFloat(),
                cx + (cos(a) * r2).toFloat(), cy + (sin(a) * r2).toFloat(), p)
        }
        rect.set(cx - r, cy - r, cx + r, cy + r)
        p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = dp(6f)
        p.color = Color.argb(28, 255, 255, 255)
        cv.drawArc(rect, 0f, 360f, false, p)
        if (showSec) {
            p.color = accent; glow(accent, dp(12f))
            cv.drawArc(rect, -90f, sec * 6f, false, p); p.clearShadowLayer()
        }
        val rb = r * 0.76f
        rect.set(cx - rb, cy - rb, cx + rb, cy + rb)
        p.strokeWidth = dp(9f); p.strokeCap = Paint.Cap.BUTT
        p.color = Color.argb(28, 255, 255, 255)
        cv.drawArc(rect, 0f, 360f, false, p)
        val pulse = if (charging) (200 + 55 * sin(now / 450.0)).toInt() else 230
        p.color = withAlpha(if (level <= 15 && !charging) Color.parseColor("#FF4D4D") else textC, pulse)
        cv.drawArc(rect, -90f, 360f * level.coerceIn(0, 100) / 100f, false, p)
        centerBattery(cv, cx, cy, r)
        rightPanel(cv, w * 0.53f, w * 0.43f, cy, h, cal, now)
    }

    private fun centerBattery(cv: Canvas, cx: Float, cy: Float, r: Float) {
        p.style = Paint.Style.FILL; p.typeface = tf; p.textAlign = Paint.Align.CENTER
        p.color = textC; p.textSize = r * 0.46f
        cv.drawText("$level%", cx, cy + r * 0.2f, p)
        if (charging) {
            val s = r * 0.12f; val by = cy - r * 0.36f
            path.reset()
            path.moveTo(cx + 0.3f * s, by - s); path.lineTo(cx - 0.6f * s, by + 0.2f * s)
            path.lineTo(cx - 0.05f * s, by + 0.2f * s); path.lineTo(cx - 0.3f * s, by + s)
            path.lineTo(cx + 0.6f * s, by - 0.2f * s); path.lineTo(cx + 0.05f * s, by - 0.2f * s)
            path.close()
            p.color = accent; glow(accent, dp(8f))
            cv.drawPath(path, p); p.clearShadowLayer()
        }
        p.color = withAlpha(accent, 220); p.textSize = r * 0.15f
        cv.drawText(if (charging) "CHARGING" else "BATTERY", cx, cy + r * 0.45f, p)
    }

    private fun rightPanel(cv: Canvas, left: Float, rw: Float, cy: Float, h: Float, cal: Calendar, now: Long) {
        val t = timeOf(cal); val hm = t.hh + ":" + t.mm
        p.style = Paint.Style.FILL; p.typeface = tf; p.textAlign = Paint.Align.LEFT
        var ts = h * 0.42f
        fun total(): Float {
            p.textSize = ts; val a = p.measureText(hm)
            p.textSize = ts * 0.3f
            return a + (if (showSec) dp(12f) + p.measureText(t.ss) else 0f)
        }
        while (total() > rw && ts > 24f) ts -= 4f
        val base = cy + ts * 0.18f
        p.textSize = ts; p.color = textC; glow(withAlpha(accent, 90), dp(18f))
        cv.drawText(hm, left, base, p); p.clearShadowLayer()
        if (showSec) {
            val hmW = p.measureText(hm)
            p.textSize = ts * 0.3f; p.color = accent
            cv.drawText(t.ss, left + hmW + dp(12f), base, p)
        }
        if (showDate) {
            p.textSize = h * 0.07f; p.color = withAlpha(textC, 210)
            cv.drawText(dateText(cal, t), left, base + h * 0.1f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(1.5f); p.color = withAlpha(accent, 170)
            cv.drawLine(left, base + h * 0.145f, left + rw * 0.45f, base + h * 0.145f, p)
        }
        nameTag(cv, left, base + h * 0.27f, h * 0.1f, Paint.Align.LEFT)
    }

    // ---------------- 1: Big digital ----------------
    private fun big(cv: Canvas, w: Float, h: Float, now: Long, cal: Calendar, sec: Float) {
        val t = timeOf(cal); val hm = t.hh + ":" + t.mm
        p.style = Paint.Style.FILL; p.typeface = tf; p.textAlign = Paint.Align.LEFT
        var ts = h * 0.55f
        fun total(): Float {
            p.textSize = ts; val a = p.measureText(hm)
            p.textSize = ts * 0.28f
            return a + (if (showSec) dp(14f) + p.measureText(t.ss) else 0f)
        }
        while (total() > w * 0.88f && ts > 24f) ts -= 4f
        val x0 = (w - total()) / 2f
        val base = h * 0.44f + ts * 0.35f
        p.textSize = ts; p.color = textC; glow(withAlpha(accent, 100), dp(22f))
        cv.drawText(hm, x0, base, p); p.clearShadowLayer()
        if (showSec) {
            val hmW = p.measureText(hm)
            p.textSize = ts * 0.28f; p.color = accent
            cv.drawText(t.ss, x0 + hmW + dp(14f), base, p)
        }
        p.textAlign = Paint.Align.CENTER
        if (showDate) {
            p.typeface = tf; p.textSize = h * 0.07f; p.color = withAlpha(textC, 210)
            cv.drawText(dateText(cal, t), w / 2f, base + h * 0.11f, p)
        }
        p.typeface = tf; p.textSize = h * 0.05f; p.color = withAlpha(accent, 230)
        cv.drawText("$level%   " + (if (charging) "CHARGING" else "BATTERY"), w / 2f, h * 0.88f, p)
        bar(cv, w * 0.3f, h * 0.915f, w * 0.4f, dp(6f), now)
        nameTag(cv, w / 2f, h * 0.1f, h * 0.075f, Paint.Align.CENTER)
    }

    // ---------------- 2: Analog ----------------
    private fun analog(cv: Canvas, w: Float, h: Float, now: Long, cal: Calendar, sec: Float) {
        val cx = w * 0.3f; val cy = h / 2f
        val r = min(h * 0.41f, w * 0.22f)
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = dp(2.5f); p.color = withAlpha(accent, 210); glow(withAlpha(accent, 120), dp(10f))
        cv.drawCircle(cx, cy, r * 1.06f, p); p.clearShadowLayer()
        for (i in 0 until 60) {
            val a = Math.toRadians(i * 6.0 - 90); val big = i % 5 == 0
            val r1 = r * (if (big) 0.86f else 0.93f); val r2 = r * 0.99f
            p.strokeWidth = dp(if (big) 2.4f else 1f)
            p.color = if (big) accent else Color.argb(90, 255, 255, 255)
            cv.drawLine(cx + (cos(a) * r1).toFloat(), cy + (sin(a) * r1).toFloat(),
                cx + (cos(a) * r2).toFloat(), cy + (sin(a) * r2).toFloat(), p)
        }
        p.style = Paint.Style.FILL; p.typeface = tf; p.textAlign = Paint.Align.CENTER
        p.textSize = r * 0.2f; p.color = textC
        for (n in 1..12) {
            val a = Math.toRadians(n * 30.0 - 90)
            cv.drawText(n.toString(), cx + (cos(a) * r * 0.69).toFloat(), cy + (sin(a) * r * 0.69).toFloat() + p.textSize * 0.35f, p)
        }
        val mn = cal.get(Calendar.MINUTE)
        fun hand(deg: Float, len: Float, wd: Float, col: Int, tail: Float) {
            val a = Math.toRadians(deg - 90.0)
            p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = wd; p.color = col
            cv.drawLine(cx - cos(a).toFloat() * tail, cy - sin(a).toFloat() * tail,
                cx + cos(a).toFloat() * len, cy + sin(a).toFloat() * len, p)
        }
        hand(((cal.get(Calendar.HOUR) % 12) + mn / 60f) * 30f, r * 0.5f, dp(6f), textC, 0f)
        hand((mn + sec / 60f) * 6f, r * 0.76f, dp(4f), textC, 0f)
        if (showSec) { glow(accent, dp(8f)); hand(sec * 6f, r * 0.84f, dp(2f), accent, r * 0.15f); p.clearShadowLayer() }
        p.style = Paint.Style.FILL; p.color = accent; cv.drawCircle(cx, cy, r * 0.05f, p)

        val left = w * 0.57f; val rw = w * 0.38f
        val t = timeOf(cal)
        p.typeface = tf; p.textAlign = Paint.Align.LEFT
        var ts = h * 0.24f
        val hm = t.hh + ":" + t.mm
        while (p.also { it.textSize = ts }.measureText(hm) > rw && ts > 20f) ts -= 4f
        val base = cy - h * 0.04f
        p.color = textC; glow(withAlpha(accent, 90), dp(14f)); cv.drawText(hm, left, base, p); p.clearShadowLayer()
        if (showDate) {
            p.textSize = h * 0.065f; p.color = withAlpha(textC, 210)
            cv.drawText(dateText(cal, t), left, base + h * 0.1f, p)
        }
        p.textSize = h * 0.05f; p.color = withAlpha(accent, 230)
        cv.drawText("$level%   " + (if (charging) "CHARGING" else "BATTERY"), left, base + h * 0.2f, p)
        bar(cv, left, base + h * 0.23f, rw * 0.8f, dp(6f), now)
        nameTag(cv, left, base + h * 0.37f, h * 0.09f, Paint.Align.LEFT)
    }

    // ---------------- 3: Flip ----------------
    private fun flip(cv: Canvas, w: Float, h: Float, now: Long, cal: Calendar, sec: Float) {
        val h24 = cal.get(Calendar.HOUR_OF_DAY)
        val hv = if (is24) h24 else (if (h24 % 12 == 0) 12 else h24 % 12)
        val hs = String.format(Locale.US, "%02d", hv)
        val ms = String.format(Locale.US, "%02d", cal.get(Calendar.MINUTE))
        val t = timeOf(cal)
        val cw = w * 0.19f; val gs = w * 0.012f; val gg = w * 0.07f
        val ch = min(h * 0.5f, cw * 1.35f)
        val total = 4 * cw + 2 * gs + gg
        var x = (w - total) / 2f; val y = h * 0.14f; val x0 = x
        fun card(d: Char) {
            rect.set(x, y, x + cw, y + ch)
            p.style = Paint.Style.FILL; p.color = Color.parseColor("#17171A")
            cv.drawRoundRect(rect, dp(12f), dp(12f), p)
            p.typeface = tf; p.textAlign = Paint.Align.CENTER; p.textSize = ch * 0.78f; p.color = textC
            cv.drawText(d.toString(), x + cw / 2f, y + ch * 0.5f + p.textSize * 0.35f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(2.2f); p.color = Color.BLACK
            cv.drawLine(x, y + ch / 2f, x + cw, y + ch / 2f, p)
        }
        card(hs[0]); x += cw + gs; card(hs[1]); x += cw + gg
        card(ms[0]); x += cw + gs; card(ms[1])
        p.style = Paint.Style.FILL; p.color = accent; glow(accent, dp(8f))
        val mx = x0 + 2 * cw + gs + gg / 2f
        cv.drawCircle(mx, y + ch * 0.36f, dp(4.5f), p); cv.drawCircle(mx, y + ch * 0.64f, dp(4.5f), p)
        p.clearShadowLayer()
        if (showSec) {
            val yy = y + ch + h * 0.05f
            p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = dp(3f)
            p.color = Color.argb(40, 255, 255, 255); cv.drawLine(x0, yy, x0 + total, yy, p)
            p.color = accent; cv.drawLine(x0, yy, x0 + total * sec / 60f, yy, p)
        }
        p.style = Paint.Style.FILL; p.typeface = tf; p.textAlign = Paint.Align.CENTER
        if (showDate) {
            p.textSize = h * 0.065f; p.color = withAlpha(textC, 210)
            cv.drawText(dateText(cal, t), w / 2f, y + ch + h * 0.16f, p)
        }
        p.textSize = h * 0.045f; p.color = withAlpha(accent, 230)
        cv.drawText("$level%   " + (if (charging) "CHARGING" else "BATTERY"), w / 2f, h * 0.9f, p)
        bar(cv, w * 0.35f, h * 0.93f, w * 0.3f, dp(5f), now)
        nameTag(cv, w / 2f, h * 0.095f, h * 0.07f, Paint.Align.CENTER)
    }

    // ---------------- 4: Wave (paani jaisi battery) ----------------
    private fun wave(cv: Canvas, w: Float, h: Float, now: Long, cal: Calendar) {
        val cx = w * 0.29f; val cy = h / 2f
        val r = min(h * 0.4f, w * 0.21f)
        p.style = Paint.Style.STROKE; p.strokeWidth = dp(3f); p.color = withAlpha(accent, 210)
        glow(withAlpha(accent, 150), dp(14f)); cv.drawCircle(cx, cy, r, p); p.clearShadowLayer()
        path.reset(); path.addCircle(cx, cy, r - dp(3f), Path.Direction.CW)
        cv.save(); cv.clipPath(path)
        val yTop = cy + r - 2 * r * level.coerceIn(0, 100) / 100f
        for (layer in 0..1) {
            val amp = r * (if (layer == 0) 0.05f else 0.035f)
            val ph = now / (if (layer == 0) 700.0 else 520.0) * (if (layer == 0) 1 else -1)
            path.reset(); path.moveTo(cx - r, cy + r)
            var x = cx - r
            while (x <= cx + r) { path.lineTo(x, yTop + (amp * sin(x / r * 4.0 + ph)).toFloat()); x += dp(6f) }
            path.lineTo(cx + r, cy + r); path.close()
            p.style = Paint.Style.FILL; p.color = withAlpha(accent, if (layer == 0) 120 else 75)
            cv.drawPath(path, p)
        }
        cv.restore()
        p.style = Paint.Style.FILL; p.typeface = tf; p.textAlign = Paint.Align.CENTER
        p.color = textC; p.textSize = r * 0.5f; cv.drawText("$level%", cx, cy + r * 0.18f, p)
        p.color = withAlpha(textC, 200); p.textSize = r * 0.14f
        cv.drawText(if (charging) "CHARGING" else "BATTERY", cx, cy + r * 0.42f, p)
        rightPanel(cv, w * 0.53f, w * 0.43f, cy, h, cal, now)
    }

    // ---------------- 5: Neon outline ----------------
    private fun neon(cv: Canvas, w: Float, h: Float, now: Long, cal: Calendar) {
        val t = timeOf(cal); val hm = t.hh + ":" + t.mm
        p.typeface = tf; p.textAlign = Paint.Align.CENTER
        var ts = h * 0.62f
        while (p.also { it.textSize = ts }.measureText(hm) > w * 0.92f && ts > 24f) ts -= 4f
        val base = h * 0.46f + ts * 0.3f
        p.style = Paint.Style.STROKE; p.strokeWidth = dp(2.5f); p.color = accent
        glow(accent, dp(26f)); cv.drawText(hm, w / 2f, base, p)
        cv.drawText(hm, w / 2f, base, p); p.clearShadowLayer()
        p.style = Paint.Style.FILL; p.textSize = h * 0.065f; p.color = withAlpha(accent, 230)
        val line = (if (showDate) dateText(cal, t) else "") + (if (showSec) "   " + t.ss else "")
        if (line.isNotBlank()) cv.drawText(line.trim(), w / 2f, base + h * 0.12f, p)
        val n = 10; val sw = w * 0.5f; val g = dp(6f); val seg = (sw - g * (n - 1)) / n
        val x0 = (w - sw) / 2f; val y = h * 0.92f
        val lit = ceil(level.coerceIn(0, 100) / 10f).toInt()
        p.textSize = h * 0.045f; p.color = withAlpha(textC, 210)
        cv.drawText("$level%   " + (if (charging) "CHARGING" else "BATTERY"), w / 2f, y - dp(10f), p)
        for (i in 0 until n) {
            rect.set(x0 + i * (seg + g), y, x0 + i * (seg + g) + seg, y + dp(8f))
            val on = i < lit
            val a = if (on && charging && i == lit - 1) (150 + 105 * sin(now / 400.0)).toInt() else 255
            p.color = if (on) withAlpha(accent, a) else Color.argb(40, 255, 255, 255)
            cv.drawRoundRect(rect, dp(4f), dp(4f), p)
        }
        nameTag(cv, w / 2f, h * 0.1f, h * 0.07f, Paint.Align.CENTER)
    }
}
