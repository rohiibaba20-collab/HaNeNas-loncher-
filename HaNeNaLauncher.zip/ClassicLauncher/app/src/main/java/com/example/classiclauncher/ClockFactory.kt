package com.example.classiclauncher

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextClock

/** Home aur lock screen dono ka clock yahin se banta hai */
object ClockFactory {
    fun build(ctx: Context, tf: Typeface, accent: Int, textC: Int, fs: Float, style: Int): View {
        fun tc(f12: String, f24: String, size: Float, face: Typeface, color: Int,
               caps: Boolean = false, spacing: Float = 0f) = TextClock(ctx).apply {
            format12Hour = f12; format24Hour = f24
            typeface = face; textSize = size * fs; setTextColor(color)
            isAllCaps = caps; letterSpacing = spacing
        }
        val script = Prefs.typeface(ctx, 0)
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        when (style) {
            0 -> {
                box.addView(tc("dd - MMMM", "dd - MMMM", 20f, tf, textC, true))
                box.addView(tc("h:mm", "H:mm", 64f, Typeface.SERIF, textC).apply {
                    setShadowLayer(12f, 0f, 0f, Color.argb(100, 255, 255, 255)) })
                box.addView(tc("EEE", "EEE", 18f, tf, textC, true))
            }
            1 -> {
                val big = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                box.addView(tc("hh", "HH", 84f, big, textC))
                box.addView(tc("mm", "mm", 84f, big, accent))
                box.addView(tc("EEE, dd MMM", "EEE, dd MMM", 15f, tf, textC, true, 0.15f))
            }
            2 -> {
                box.addView(tc("h:mm", "H:mm", 84f, script, textC))
                box.addView(tc("EEEE, dd MMMM", "EEEE, dd MMMM", 22f, script, accent))
            }
            3 -> {
                val mono = Typeface.create("monospace", Typeface.BOLD)
                box.addView(tc("h:mm", "HH:mm", 58f, mono, accent))
                box.addView(tc("EEE | dd MMM", "EEE | dd MMM", 15f, mono, textC, true, 0.25f))
            }
            4 -> {
                box.addView(tc("h:mm", "H:mm", 52f, Typeface.create("sans-serif-thin", Typeface.NORMAL), textC))
                box.addView(tc("EEEE, dd MMMM", "EEEE, dd MMMM", 14f,
                    Typeface.create("sans-serif-light", Typeface.NORMAL), accent, true, 0.2f))
            }
            else -> {
                box.addView(AnalogClockView(ctx, accent, textC))
                box.addView(tc("EEE, dd MMM", "EEE, dd MMM", 16f, tf, textC, true, 0.1f))
            }
        }
        return box
    }
}
