package com.example.classiclauncher

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract

/** Phone ke contacts (Phone aur Messages dono ke kaam aata hai). Load karna peeche (background) thread se karo. */
object ContactsData {
    class Contact(val id: Long, val name: String, val number: String, val photo: String?)

    private var cache: List<Contact>? = null
    private var byNum: HashMap<String, String> = HashMap()

    fun has(c: Context) = c.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    /** Number ko tulna ke liye chhota karo: aakhri 10 ank. Letter wale sender (jaise "HDFCBK") jaise ke taise */
    fun norm(n: String): String {
        val d = n.filter { it.isDigit() }
        return if (d.length >= 7) d.takeLast(10) else n.trim().lowercase()
    }

    fun load(c: Context, force: Boolean = false): List<Contact> {
        if (!has(c)) return emptyList()
        if (!force) cache?.let { return it }
        val out = ArrayList<Contact>()
        val map = HashMap<String, String>()
        val seen = HashSet<String>()
        try {
            val ph = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val proj = arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI
            )
            c.applicationContext.contentResolver.query(ph, proj, null, null, null)?.use { q ->
                while (q.moveToNext()) {
                    val id = q.getLong(0)
                    val name = q.getString(1) ?: continue
                    val num = q.getString(2) ?: continue
                    val key = id.toString() + "|" + norm(num)
                    if (!seen.add(key)) continue
                    out.add(Contact(id, name, num, q.getString(3)))
                    if (!map.containsKey(norm(num))) map[norm(num)] = name
                }
            }
        } catch (e: Exception) { }
        out.sortBy { it.name.lowercase() }
        cache = out; byNum = map
        return out
    }

    fun nameFor(c: Context, number: String): String? {
        if (cache == null) load(c)
        return byNum[norm(number)]
    }
}
