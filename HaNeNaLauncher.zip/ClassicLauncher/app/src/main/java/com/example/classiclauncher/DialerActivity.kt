package com.example.classiclauncher

import android.Manifest
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * HaNeNa Phone: gol glass keypad, recents aur contacts. Call lagane ke baad call ki screen phone ki apni hi rehti hai
 * (usse badalne ke liye app ko phone ka default dialer banna padta hai).
 */
class DialerActivity : AppCompatActivity() {

    private class CallRow(val number: String, val name: String?, val type: Int, val date: Long, val dur: Long)
    private class CRow(val header: String?, val c: ContactsData.Contact?)

    private lateinit var k: Skin
    private lateinit var content: FrameLayout
    private lateinit var tabHolder: FrameLayout
    private var tab = 0
    private val number = StringBuilder()
    private var numTv: TextView? = null
    private var sugTv: TextView? = null
    private var contacts: List<ContactsData.Contact> = emptyList()
    private var calls: List<CallRow> = emptyList()
    private var cRows: List<CRow> = emptyList()
    private var cQuery = ""
    private var tone: ToneGenerator? = null
    private val tfmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dfmt = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { reload() }

    private val callAdapter = object : BaseAdapter() {
        override fun getCount() = calls.size
        override fun getItem(p: Int) = calls[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View = recentRow(calls[p], cv)
    }

    private val contactAdapter = object : BaseAdapter() {
        override fun getCount() = cRows.size
        override fun getItem(p: Int) = cRows[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(p: Int) = if (cRows[p].header != null) 0 else 1
        override fun isEnabled(p: Int) = cRows[p].header == null
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val r = cRows[p]
            val h = r.header
            return if (h != null) contactHeader(h, cv) else contactRow(r.c!!, cv)
        }
    }

    // ------------------------------ screen ------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        k = Skin(this)
        window.statusBarColor = k.bgTop(); window.navigationBarColor = Color.BLACK
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true; background = k.gradient() }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(8), k.dp(4), k.dp(8), 0) }
        head.addView(IconBtn(this, IconBtn.BACK).apply { color = k.accent; setOnClickListener { finish() } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        head.addView(k.tv("Phone", 28f, k.textC, true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(6) })
        head.addView(IconBtn(this, IconBtn.GEAR).apply { color = k.accent; setOnClickListener { startActivity(Intent(this@DialerActivity, DialerSettingsActivity::class.java)) } },
            LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        root.addView(head, k.lp())
        tabHolder = FrameLayout(this)
        root.addView(tabHolder, k.lp(4).apply { setMargins(k.dp(12), k.dp(6), k.dp(12), k.dp(6)) })
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        intent.getStringExtra("number")?.let { number.append(it) }
        fillTabs(); showTab()
        val need = listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALL_LOG, Manifest.permission.CALL_PHONE)
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) perms.launch(need.toTypedArray()) else reload()
    }

    override fun onResume() { super.onResume(); if (contacts.isNotEmpty() || calls.isNotEmpty()) reload() }

    override fun onDestroy() { try { tone?.release() } catch (e: Exception) { }; super.onDestroy() }

    private fun fillTabs() {
        tabHolder.removeAllViews()
        tabHolder.addView(k.chips(listOf("Keypad", "Recents", "Contacts"), tab) { tab = it; fillTabs(); showTab() })
    }

    private fun showTab() {
        content.removeAllViews()
        content.addView(when (tab) { 0 -> buildKeypad(); 1 -> buildRecents(); else -> buildContacts() }, FrameLayout.LayoutParams(-1, -1))
    }

    private fun reload() {
        Thread {
            val cs = ContactsData.load(this, true)
            val cl = readCalls(DialerPrefs.recentsLimit(this))
            runOnUiThread { contacts = cs; calls = cl; buildRows(); callAdapter.notifyDataSetChanged(); contactAdapter.notifyDataSetChanged() }
        }.start()
    }

    private fun readCalls(limit: Int): List<CallRow> {
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return emptyList()
        val out = ArrayList<CallRow>()
        try {
            contentResolver.query(CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION),
                null, null, "date DESC")?.use { q ->
                while (q.moveToNext() && out.size < limit)
                    out.add(CallRow(q.getString(0) ?: "", q.getString(1), q.getInt(2), q.getLong(3), q.getLong(4)))
            }
        } catch (e: Exception) { }
        return out
    }

    // ------------------------------ call lagana ------------------------------
    private fun call(num: String) {
        if (num.isBlank()) return
        if (DialerPrefs.bool(this, DialerPrefs.CONFIRM, false)) {
            val nm = ContactsData.nameFor(this, num) ?: num
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Call karein?").setMessage(nm)
                .setPositiveButton("Call") { _, _ -> doCall(num) }.setNegativeButton("Nahi", null).show()
        } else doCall(num)
    }

    private fun doCall(num: String) {
        val u = Uri.parse("tel:" + Uri.encode(num))
        try {
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) startActivity(Intent(Intent.ACTION_CALL, u))
            else startActivity(Intent(Intent.ACTION_DIAL, u))
        } catch (e: Exception) { Toast.makeText(this, "Call nahi lag saka", Toast.LENGTH_SHORT).show() }
    }

    private fun message(num: String) {
        startActivity(Intent(this, SmsChatActivity::class.java).putExtra("address", num))
    }

    // ------------------------------ keypad ------------------------------
    private fun t9(name: String): String {
        val sb = StringBuilder()
        for (ch in name.lowercase()) sb.append(when (ch) {
            in 'a'..'c' -> '2'; in 'd'..'f' -> '3'; in 'g'..'i' -> '4'; in 'j'..'l' -> '5'
            in 'm'..'o' -> '6'; in 'p'..'s' -> '7'; in 't'..'v' -> '8'; in 'w'..'z' -> '9'
            in '0'..'9' -> ch; else -> ' '
        })
        return sb.toString().replace(" ", "")
    }

    private fun prettyNumber(s: String): String {
        if (s.length <= 5 || s.startsWith("*") || s.startsWith("#")) return s
        val sb = StringBuilder()
        s.forEachIndexed { i, c -> if (i > 0 && (s.length - i) % 3 == 0 && i >= 2 && s.length <= 12) sb.append(' '); sb.append(c) }
        return sb.toString()
    }

    private fun refreshNumber() {
        numTv?.text = if (number.isEmpty()) "Number daalo" else prettyNumber(number.toString())
        numTv?.alpha = if (number.isEmpty()) 0.45f else 1f
        var s = ""
        if (number.length >= 2 && DialerPrefs.bool(this, DialerPrefs.T9, true)) {
            val d = number.toString()
            val hit = contacts.firstOrNull { ContactsData.norm(it.number).contains(d) || t9(it.name).contains(d) }
            if (hit != null) s = hit.name + "  •  " + hit.number
        }
        sugTv?.text = s
        sugTv?.setOnClickListener { contacts.firstOrNull { (it.name + "  •  " + it.number) == sugTv?.text }?.let { number.setLength(0); number.append(it.number.filter { ch -> ch.isDigit() || ch == '+' }); refreshNumber() } }
    }

    private fun keyBg(): StateListDrawable {
        val style = DialerPrefs.int(this, DialerPrefs.KEY_STYLE, 0)
        fun shape(fill: Int, stroke: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(fill); setStroke(k.dp(1), stroke) }
        val normal = when (style) {
            1 -> shape(Color.TRANSPARENT, k.accent)
            2 -> shape(k.al(k.accent, 70), k.al(k.accent, 150))
            else -> shape(Color.argb(28, 255, 255, 255), k.al(k.accent, 80))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(k.al(k.accent, 130), k.accent))
            addState(intArrayOf(), normal)
        }
    }

    private fun press(d: String) {
        number.append(d); refreshNumber()
        if (DialerPrefs.bool(this, DialerPrefs.KEY_TONE, true)) {
            try {
                if (tone == null) tone = ToneGenerator(AudioManager.STREAM_DTMF, 60)
                val t = when (d) { "*" -> ToneGenerator.TONE_DTMF_S; "#" -> ToneGenerator.TONE_DTMF_P
                    else -> ToneGenerator.TONE_DTMF_0 + d.toInt() }
                tone?.startTone(t, 110)
            } catch (e: Exception) { }
        }
    }

    private fun buildKeypad(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        numTv = k.tv("", 34f, k.textC, true).apply { gravity = Gravity.CENTER; setSingleLine(true); ellipsize = TextUtils.TruncateAt.START }
        sugTv = k.tv("", 13f, k.accent).apply { gravity = Gravity.CENTER; setSingleLine(true); ellipsize = TextUtils.TruncateAt.END; isClickable = true }
        box.addView(numTv, k.lp(10).apply { setMargins(k.dp(20), k.dp(10), k.dp(20), 0) })
        box.addView(sugTv, k.lp(2).apply { setMargins(k.dp(20), k.dp(2), k.dp(20), k.dp(6)) })
        val big = DialerPrefs.int(this, DialerPrefs.KEY_SIZE, 0) == 1
        val ks = (resources.displayMetrics.heightPixels * (if (big) 0.094f else 0.082f)).toInt().coerceIn(k.dp(52), k.dp(84))
        val keys = listOf("1" to "", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO",
            "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to "", "0" to "+", "#" to "")
        for (r in 0 until 4) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
            for (c in 0 until 3) {
                val (d, letters) = keys[r * 3 + c]
                val key = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                    background = keyBg(); isClickable = true
                    addView(k.tv(d, if (big) 28f else 25f, k.textC).apply { gravity = Gravity.CENTER })
                    if (letters.isNotEmpty()) addView(k.tv(letters, 8f, k.dim(150)).apply { gravity = Gravity.CENTER; letterSpacing = 0.15f })
                    setOnClickListener {
                        if (DialerPrefs.bool(this@DialerActivity, DialerPrefs.KEY_HAPTIC, true)) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        press(d)
                    }
                    setOnLongClickListener {
                        if (d == "0") { number.append('+'); refreshNumber(); true }
                        else if (d in "123456789") {
                            val sd = DialerPrefs.str(this@DialerActivity, "sd$d")
                            if (sd.isNotEmpty()) { call(sd); true } else false
                        } else false
                    }
                }
                row.addView(key, LinearLayout.LayoutParams(ks, ks).apply { setMargins(k.dp(9), k.dp(5), k.dp(9), k.dp(5)) })
            }
            box.addView(row)
        }
        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER }
        bottom.addView(IconBtn(this, IconBtn.MSG).apply {
            color = k.accent; setOnClickListener { if (number.isNotEmpty()) message(number.toString()) }
        }, LinearLayout.LayoutParams(ks, ks).apply { setMargins(k.dp(9), k.dp(8), k.dp(9), k.dp(8)) })
        val callBtn = IconBtn(this, IconBtn.CALL).apply {
            color = Color.BLACK
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(k.accent) }
            setOnClickListener {
                if (number.isNotEmpty()) call(number.toString())
                else calls.firstOrNull { it.type == CallLog.Calls.OUTGOING_TYPE }?.let { number.append(it.number); refreshNumber() }
            }
        }
        bottom.addView(callBtn, LinearLayout.LayoutParams(ks, ks).apply { setMargins(k.dp(9), k.dp(8), k.dp(9), k.dp(8)) })
        bottom.addView(IconBtn(this, IconBtn.DEL).apply {
            color = k.textC
            setOnClickListener { if (number.isNotEmpty()) { number.setLength(number.length - 1); refreshNumber() } }
            setOnLongClickListener { number.setLength(0); refreshNumber(); true }
        }, LinearLayout.LayoutParams(ks, ks).apply { setMargins(k.dp(9), k.dp(8), k.dp(9), k.dp(8)) })
        box.addView(bottom)
        refreshNumber()
        return box
    }

    // ------------------------------ recents ------------------------------
    private fun when_(ms: Long): String {
        val now = Calendar.getInstance(); val t = Calendar.getInstance().apply { timeInMillis = ms }
        val sameDay = now.get(Calendar.YEAR) == t.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == t.get(Calendar.DAY_OF_YEAR)
        now.add(Calendar.DAY_OF_YEAR, -1)
        val yday = now.get(Calendar.YEAR) == t.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == t.get(Calendar.DAY_OF_YEAR)
        return if (sameDay) tfmt.format(Date(ms)) else if (yday) "Kal " + tfmt.format(Date(ms)) else dfmt.format(Date(ms))
    }

    private fun avatar(label: String, size: Int): TextView = TextView(this).apply {
        text = label.trim().firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "#"
        gravity = Gravity.CENTER; textSize = 18f; setTextColor(Color.BLACK); typeface = k.script
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(k.accent, k.accent2)).apply { shape = GradientDrawable.OVAL }
        layoutParams = LinearLayout.LayoutParams(size, size)
    }

    private fun recentRow(r: CallRow, cv: View?): View {
        val outer = (cv as? FrameLayout) ?: FrameLayout(this).apply {
            setPadding(k.dp(12), k.dp(3), k.dp(12), k.dp(3))
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(12), k.dp(10), k.dp(8), k.dp(10)); background = k.glass(18, 20, 40)
                addView(avatar("#", k.dp(44)))
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(k.tv("", 16f).apply { setSingleLine(true); ellipsize = TextUtils.TruncateAt.END })
                    addView(k.tv("", 12f, k.dim(150)).apply { setSingleLine(true) })
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(12) })
                addView(IconBtn(context, IconBtn.CALL), LinearLayout.LayoutParams(k.dp(40), k.dp(40)))
            }, FrameLayout.LayoutParams(-1, -2))
        }
        val row = outer.getChildAt(0) as LinearLayout
        val name = r.name?.takeIf { it.isNotBlank() } ?: ContactsData.nameFor(this, r.number)
        val missed = r.type == CallLog.Calls.MISSED_TYPE || r.type == CallLog.Calls.REJECTED_TYPE
        val shown = name ?: prettyNumber(r.number).ifBlank { "Unknown" }
        val av = row.getChildAt(0) as TextView
        av.text = shown.trim().firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "#"
        val col = row.getChildAt(1) as LinearLayout
        (col.getChildAt(0) as TextView).apply { text = shown; setTextColor(if (missed) k.red else k.textC) }
        val arrow = when (r.type) { CallLog.Calls.INCOMING_TYPE -> "↙ Aaya"; CallLog.Calls.OUTGOING_TYPE -> "↗ Gaya"; CallLog.Calls.MISSED_TYPE -> "↙ Miss"; else -> "✕ Reject" }
        var sub = arrow + "  •  " + when_(r.date)
        if (DialerPrefs.bool(this, DialerPrefs.SHOW_DUR, true) && r.dur > 0) sub += "  •  " + (r.dur / 60) + "m " + (r.dur % 60) + "s"
        (col.getChildAt(1) as TextView).apply { text = sub; setTextColor(if (missed) k.al(k.red, 200) else k.dim(150)) }
        (row.getChildAt(2) as IconBtn).apply { color = k.accent; setOnClickListener { call(r.number) } }
        row.setOnClickListener { call(r.number) }
        row.setOnLongClickListener { recentMenu(r); true }
        return outer
    }

    private fun recentMenu(r: CallRow) {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(r.name ?: r.number)
            .setItems(arrayOf("Call", "Message", "Number copy karo", "Keypad mein daalo")) { _, i ->
                when (i) {
                    0 -> call(r.number)
                    1 -> message(r.number)
                    2 -> (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("number", r.number))
                    else -> { number.setLength(0); number.append(r.number.filter { it.isDigit() || it == '+' }); tab = 0; fillTabs(); showTab() }
                }
            }.show()
    }

    private fun buildRecents(): View {
        val lv = ListView(this).apply {
            divider = null; selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false; setPadding(0, k.dp(2), 0, k.dp(14)); adapter = callAdapter
            emptyView = null
        }
        val frame = FrameLayout(this)
        frame.addView(lv, FrameLayout.LayoutParams(-1, -1))
        val none = k.tv("Abhi koi call nahi (ya call log ki ijazat nahi di)", 14f, k.dim(150)).apply { gravity = Gravity.CENTER; setPadding(k.dp(30), 0, k.dp(30), 0) }
        none.visibility = if (calls.isEmpty()) View.VISIBLE else View.GONE
        frame.addView(none, FrameLayout.LayoutParams(-1, -1))
        return frame
    }

    // ------------------------------ contacts ------------------------------
    private fun buildRows() {
        val q = cQuery.trim()
        val base = if (q.isEmpty()) contacts else contacts.filter { it.name.contains(q, true) || it.number.contains(q) }
        val out = ArrayList<CRow>()
        if (q.isEmpty()) {
            val favs = DialerPrefs.favIds(this)
            val fl = base.filter { favs.contains(it.id) }.distinctBy { it.id }
            if (fl.isNotEmpty()) { out.add(CRow("★", null)); fl.forEach { out.add(CRow(null, it)) } }
        }
        var last = ""
        for (c in base) {
            if (q.isEmpty()) {
                val ch = c.name.trim().firstOrNull()?.uppercaseChar()
                val key = if (ch != null && ch.isLetter()) ch.toString() else "#"
                if (key != last) { out.add(CRow(key, null)); last = key }
            }
            out.add(CRow(null, c))
        }
        cRows = out
    }

    private fun contactHeader(letter: String, cv: View?): View {
        val v = (cv as? LinearLayout) ?: LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(24), k.dp(14), k.dp(24), k.dp(4))
            addView(k.tv("", 22f, k.accent, true))
            addView(View(context).apply { setBackgroundColor(Color.argb(38, 255, 255, 255)) }, LinearLayout.LayoutParams(0, k.dp(1), 1f).apply { marginStart = k.dp(14) })
        }
        (v.getChildAt(0) as TextView).text = letter
        return v
    }

    private fun contactRow(c: ContactsData.Contact, cv: View?): View {
        val outer = (cv as? FrameLayout) ?: FrameLayout(this).apply {
            setPadding(k.dp(12), k.dp(3), k.dp(12), k.dp(3))
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(12), k.dp(8), k.dp(6), k.dp(8)); background = k.glass(18, 20, 40)
                addView(FrameLayout(context).apply {
                    addView(avatar("#", k.dp(44)))
                    addView(ImageView(context).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) } }
                        clipToOutline = true
                    }, FrameLayout.LayoutParams(k.dp(44), k.dp(44)))
                }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(k.tv("", 16f).apply { setSingleLine(true); ellipsize = TextUtils.TruncateAt.END })
                    addView(k.tv("", 12f, k.dim(150)).apply { setSingleLine(true) })
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(12) })
                addView(IconBtn(context, IconBtn.MSG), LinearLayout.LayoutParams(k.dp(40), k.dp(40)))
                addView(IconBtn(context, IconBtn.CALL), LinearLayout.LayoutParams(k.dp(40), k.dp(40)))
            }, FrameLayout.LayoutParams(-1, -2))
        }
        val row = outer.getChildAt(0) as LinearLayout
        val fr = row.getChildAt(0) as FrameLayout
        (fr.getChildAt(0) as TextView).text = c.name.trim().firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "#"
        val iv = fr.getChildAt(1) as ImageView
        if (c.photo != null && DialerPrefs.bool(this, DialerPrefs.PHOTOS, true)) { iv.visibility = View.VISIBLE; try { iv.setImageURI(Uri.parse(c.photo)) } catch (e: Exception) { iv.visibility = View.GONE } }
        else iv.visibility = View.GONE
        val col = row.getChildAt(1) as LinearLayout
        val fav = DialerPrefs.favIds(this).contains(c.id)
        (col.getChildAt(0) as TextView).apply { text = (if (fav) "★ " else "") + c.name; setTextColor(k.textC) }
        (col.getChildAt(1) as TextView).text = c.number
        (row.getChildAt(2) as IconBtn).apply { color = k.accent; setOnClickListener { message(c.number) } }
        (row.getChildAt(3) as IconBtn).apply { color = k.accent; setOnClickListener { call(c.number) } }
        row.setOnClickListener { call(c.number) }
        row.setOnLongClickListener { DialerPrefs.toggleFav(this, c.id); buildRows(); contactAdapter.notifyDataSetChanged(); true }
        return outer
    }

    private fun buildContacts(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val et = EditText(this).apply {
            hint = "Naam ya number dhundo"; setHintTextColor(Color.argb(120, 255, 255, 255)); setTextColor(Color.WHITE)
            textSize = 15f; setSingleLine(true); background = null; setPadding(k.dp(20), k.dp(12), k.dp(20), k.dp(12))
            setText(cQuery)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { cQuery = s?.toString().orEmpty(); buildRows(); contactAdapter.notifyDataSetChanged() }
            })
        }
        box.addView(FrameLayout(this).apply { background = k.glass(26, 34, 110); addView(et, FrameLayout.LayoutParams(-1, -2)) },
            k.lp(0).apply { setMargins(k.dp(16), k.dp(2), k.dp(16), k.dp(4)) })
        val lv = ListView(this).apply {
            divider = null; selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false; setPadding(0, k.dp(2), 0, k.dp(14)); adapter = contactAdapter; isFastScrollEnabled = true
        }
        box.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        if (contacts.isEmpty()) box.addView(k.tv("Contacts ki ijazat do ya contacts khali hain. Lamba dabao: favourite", 13f, k.dim(150)).apply { gravity = Gravity.CENTER; setPadding(k.dp(24), k.dp(8), k.dp(24), k.dp(12)) })
        buildRows()
        return box
    }
}
