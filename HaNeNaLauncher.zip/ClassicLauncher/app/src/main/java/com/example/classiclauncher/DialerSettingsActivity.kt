package com.example.classiclauncher

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/** HaNeNa Phone ki settings: call par flash, keypad, call karne ka tareeka, speed dial */
class DialerSettingsActivity : AppCompatActivity() {

    private lateinit var k: Skin
    private lateinit var box: LinearLayout

    private val phonePerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) DialerPrefs.setBool(this, DialerPrefs.FLASH, true)
        else { DialerPrefs.setBool(this, DialerPrefs.FLASH, false); Toast.makeText(this, "Call pehchanne ki ijazat chahiye", Toast.LENGTH_LONG).show() }
        CallFlash.sync(this); fill()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        k = Skin(this)
        window.statusBarColor = k.bgTop(); window.navigationBarColor = Color.BLACK
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true; background = k.gradient() }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(8), k.dp(4), k.dp(20), 0) }
        head.addView(IconBtn(this, IconBtn.BACK).apply { color = k.accent; setOnClickListener { finish() } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        head.addView(k.tv("Phone settings", 26f, k.textC, true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(6) })
        root.addView(head, k.lp())
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(k.dp(16), k.dp(4), k.dp(16), k.dp(24)) }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(box) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        fill()
    }

    private fun b(key: String, def: Boolean) = DialerPrefs.bool(this, key, def)

    private fun toggle(text: String, key: String, def: Boolean, extra: ((Boolean) -> Unit)? = null) =
        k.switchRow(text, b(key, def)) { DialerPrefs.setBool(this, key, it); extra?.invoke(it) }

    private fun fill() {
        box.removeAllViews()
        val permOk = checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        val flashOn = b(DialerPrefs.FLASH, false) && permOk

        // ---- call par flash ----
        val c1 = k.card()
        c1.addView(k.tv("Call par flash light", 20f, k.accent, true))
        c1.addView(k.tv("Call aane par camera ki flash light chamakti hai. Silent phone mein bhi call ka pata chal jata hai.", 12f, k.dim(160)), k.lp(4))
        c1.addView(k.switchRow("Call aane par flash chalao", flashOn) { v ->
            if (v && !permOk) phonePerm.launch(Manifest.permission.READ_PHONE_STATE)
            else { DialerPrefs.setBool(this, DialerPrefs.FLASH, v); CallFlash.sync(this); fill() }
        }, k.lp(12))
        if (flashOn) {
            c1.addView(k.tv("Flash ka andaaz", 14f), k.lp(14))
            c1.addView(chips2(CallFlash.STYLES, DialerPrefs.int(this, DialerPrefs.FLASH_STYLE, 0)) { DialerPrefs.setInt(this, DialerPrefs.FLASH_STYLE, it); fill() }, k.lp(8))
            c1.addView(k.tv("Kab chamake", 14f), k.lp(14))
            c1.addView(chips2(CallFlash.WHEN, DialerPrefs.int(this, DialerPrefs.FLASH_WHEN, 0)) { DialerPrefs.setInt(this, DialerPrefs.FLASH_WHEN, it); fill() }, k.lp(8))
            c1.addView(k.button("Flash test karo (3 second)") { CallFlash.test(this, DialerPrefs.int(this, DialerPrefs.FLASH_STYLE, 0)) }, k.lp(14))
        }
        box.addView(c1, k.lp(10))

        // ---- keypad ----
        val c2 = k.card()
        c2.addView(k.tv("Keypad", 20f, k.accent, true))
        c2.addView(toggle("Keypad ki awaaz (tone)", DialerPrefs.KEY_TONE, true), k.lp(12))
        c2.addView(toggle("Keypad par halka vibration", DialerPrefs.KEY_HAPTIC, true), k.lp(10))
        c2.addView(k.tv("Keypad ka style", 14f), k.lp(14))
        c2.addView(k.chips(listOf("Glass", "Outline", "Solid"), DialerPrefs.int(this, DialerPrefs.KEY_STYLE, 0)) { DialerPrefs.setInt(this, DialerPrefs.KEY_STYLE, it); fill() }, k.lp(8))
        c2.addView(k.tv("Keypad ka size", 14f), k.lp(14))
        c2.addView(k.chips(listOf("Normal", "Bada"), DialerPrefs.int(this, DialerPrefs.KEY_SIZE, 0)) { DialerPrefs.setInt(this, DialerPrefs.KEY_SIZE, it); fill() }, k.lp(8))
        box.addView(c2, k.lp(12))

        // ---- calls ----
        val c3 = k.card()
        c3.addView(k.tv("Calls aur contacts", 20f, k.accent, true))
        c3.addView(toggle("Call karne se pehle poochho", DialerPrefs.CONFIRM, false), k.lp(12))
        c3.addView(toggle("Number likhte waqt contact suggest karo", DialerPrefs.T9, true), k.lp(10))
        c3.addView(toggle("Contacts ki photo dikhao", DialerPrefs.PHOTOS, true), k.lp(10))
        c3.addView(toggle("Recents mein call ki lambai dikhao", DialerPrefs.SHOW_DUR, true), k.lp(10))
        c3.addView(k.tv("Recents mein kitni calls", 14f), k.lp(14))
        c3.addView(k.chips(listOf("50", "150", "400"), DialerPrefs.int(this, DialerPrefs.RECENTS_N, 1)) { DialerPrefs.setInt(this, DialerPrefs.RECENTS_N, it); fill() }, k.lp(8))
        box.addView(c3, k.lp(12))

        // ---- speed dial ----
        val c4 = k.card()
        c4.addView(k.tv("Speed dial", 20f, k.accent, true))
        c4.addView(k.tv("Keypad par 1 se 9 ko lamba dabao to number seedha lagta hai.", 12f, k.dim(160)), k.lp(4))
        for (d in 1..9) {
            val cur = DialerPrefs.str(this, "sd$d")
            c4.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(k.tv("$d", 20f, k.accent, true), LinearLayout.LayoutParams(k.dp(30), -2))
                addView(k.tv(if (cur.isEmpty()) "Set nahi" else (ContactsData.nameFor(this@DialerSettingsActivity, cur) ?: cur), 14f, if (cur.isEmpty()) k.dim(120) else k.textC),
                    LinearLayout.LayoutParams(0, -2, 1f))
                addView(k.button(if (cur.isEmpty()) "Set karo" else "Badlo") { askSpeed(d) })
            }, k.lp(10))
        }
        box.addView(c4, k.lp(12))

        box.addView(k.tv("Dhyan: call lagne ke baad call ki screen (uthana / kaatna) phone ki apni hi rehti hai. Usse badalne ke liye app ko phone ka default dialer banna padta hai.",
            12f, k.dim(130)), k.lp(14))
    }

    private fun chips2(opts: List<String>, sel: Int, pick: (Int) -> Unit): LinearLayout {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(k.chips(opts.take(2), if (sel < 2) sel else -1) { pick(it) })
        if (opts.size > 2) col.addView(k.chips(opts.drop(2), if (sel >= 2) sel - 2 else -1) { pick(it + 2) }, k.lp(6))
        return col
    }

    private fun askSpeed(d: Int) {
        val et = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_PHONE; hint = "Number (khali chhodo to hat jayega)"; setText(DialerPrefs.str(this@DialerSettingsActivity, "sd$d"))
        }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Speed dial $d").setView(et)
            .setPositiveButton("Save") { _, _ -> DialerPrefs.setStr(this, "sd$d", et.text.toString().trim()); fill() }
            .setNegativeButton("Cancel", null).show()
    }
}
