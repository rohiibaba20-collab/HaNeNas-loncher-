package com.example.classiclauncher

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

/** Saari apps: icons + search + long-press (favourite / app info / uninstall) */
class DrawerActivity : AppCompatActivity() {

    private class Entry(val label: String, val pkg: String, val cls: String, val icon: Drawable)

    private var all = listOf<Entry>()
    private var shown = listOf<Entry>()
    private lateinit var search: EditText
    private lateinit var list: ListView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int) = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val row = (cv as? LinearLayout) ?: LinearLayout(this@DrawerActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(8), dp(16), dp(8))
                addView(ImageView(context), LinearLayout.LayoutParams(dp(44), dp(44)))
                addView(TextView(context).apply {
                    textSize = 18f; setTextColor(Prefs.get(context, Prefs.TEXT)); setPadding(dp(16), 0, 0, 0)
                }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(TextView(context).apply { text = "★"; textSize = 18f }, LinearLayout.LayoutParams(-2, -2))
            }
            val e = shown[p]
            (row.getChildAt(0) as ImageView).setImageDrawable(e.icon)
            (row.getChildAt(1) as TextView).text = e.label
            (row.getChildAt(2) as TextView).apply {
                setTextColor(Prefs.get(context, Prefs.ACCENT))
                visibility = if (Prefs.favs(context).contains(e.pkg)) View.VISIBLE else View.GONE
            }
            return row
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            fitsSystemWindows = true
        }
        search = EditText(this).apply {
            hint = "App dhundo..."
            setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setSingleLine(true)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { filter(s?.toString().orEmpty()) }
            })
        }
        list = ListView(this).apply {
            divider = null
            this.adapter = this@DrawerActivity.adapter
            setOnItemClickListener { _, _, p, _ -> open(shown[p]) }
            setOnItemLongClickListener { _, _, p, _ -> menu(shown[p]); true }
        }
        root.addView(search, -1, -2)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        intent.getStringExtra("q")?.let { search.setText(it) }
    }

    override fun onResume() { super.onResume(); load() }

    private fun load() {
        Thread {
            val pm = packageManager
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val res = pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { Entry(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name, it.loadIcon(pm)) }
                .sortedBy { it.label.lowercase() }
                .toMutableList()
            // HaNeNa Music bhi list mein (favourite bana kar Home par laga sakte ho)
            res.add(0, Entry("HaNeNa Music", Prefs.MUSIC_PKG, MusicActivity::class.java.name, packageManager.getApplicationIcon(packageName)))
            runOnUiThread { all = res; filter(search.text.toString()) }
        }.start()
    }

    private fun filter(q: String) {
        val t = q.trim()
        shown = if (t.isEmpty()) all else all.filter { it.label.contains(t, ignoreCase = true) }
            .sortedBy { if (it.label.startsWith(t, ignoreCase = true)) 0 else 1 }
        adapter.notifyDataSetChanged()
    }

    private fun open(e: Entry) {
        if (e.pkg == Prefs.MUSIC_PKG) { startActivity(Intent(this, MusicActivity::class.java)); return }
        try {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(e.pkg, e.cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (x: Exception) { Toast.makeText(this, "App khul nahi saki", Toast.LENGTH_SHORT).show() }
    }

    private fun menu(e: Entry) {
        val isFav = Prefs.favs(this).contains(e.pkg)
        if (e.pkg == Prefs.MUSIC_PKG) {
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(e.label)
                .setItems(arrayOf(if (isFav) "Home se hatao" else "Home mein jodo")) { _, _ ->
                    Prefs.toggleFav(this, e.pkg); adapter.notifyDataSetChanged()
                }.show()
            return
        }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(e.label)
            .setItems(arrayOf(if (isFav) "Home se hatao" else "Home mein jodo", "App info", "Uninstall")) { _, i ->
                when (i) {
                    0 -> { Prefs.toggleFav(this, e.pkg); adapter.notifyDataSetChanged() }
                    1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${e.pkg}")))
                    else -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${e.pkg}")))
                }
            }.show()
    }
}
