package com.example.classiclauncher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewAnimationUtils
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.AnimationSet
import android.view.animation.DecelerateInterpolator
import android.view.animation.LayoutAnimationController
import android.view.animation.OvershootInterpolator
import android.view.animation.ScaleAnimation
import android.view.animation.TranslateAnimation
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.doOnLayout
import kotlin.math.hypot
import kotlin.math.max

/**
 * Saari apps: glass search, icon grid, A-Z side rail, long-press (favourite / app info / uninstall).
 * Icons asli rang mein dikhte hain; Settings se theme rang bhi diya ja sakta hai.
 */
class DrawerActivity : AppCompatActivity() {

    private class Entry(val label: String, val pkg: String, val cls: String, val icon: Drawable)

    private var all = listOf<Entry>()
    private var shown = listOf<Entry>()
    private var favSet = setOf<String>()
    private var themed = false
    private var accent = 0
    private var textC = 0
    private var bgTop = 0
    private lateinit var tf: Typeface
    private lateinit var script: Typeface
    private lateinit var search: EditText
    private lateinit var grid: GridView
    private lateinit var countTv: TextView
    private lateinit var bubble: TextView
    private lateinit var rail: LinearLayout
    private lateinit var root: LinearLayout
    private lateinit var ring: RevealRing
    private lateinit var headV: View
    private lateinit var pillV: View
    private lateinit var emptyTv: TextView
    private var revealed = false
    private var dataReady = false
    private var closing = false

    private val letters: List<Char> = ('A'..'Z').toList() + '#'
    private val railViews = ArrayList<TextView>()
    private var startLetter: Char? = null
    private var animateNext = true
    private val hnd = Handler(Looper.getMainLooper())
    private val hideBubble = Runnable { bubble.visibility = View.GONE }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun al(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun keyOf(label: String): Char {
        val c = label.trim().firstOrNull()?.uppercaseChar()
        return if (c != null && c in 'A'..'Z') c else '#'
    }

    // ------------------------------ grid ------------------------------
    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int) = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val cell = (cv as? LinearLayout) ?: makeCell()
            val e = shown[p]
            val tile = cell.getChildAt(0) as FrameLayout
            tile.background = if (themed) GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(Color.argb(95, 0, 0, 0)); setStroke(dp(1), al(accent, 150))
            } else null
            val iv = tile.getChildAt(0) as ImageView
            val sz = dp(if (themed) 36 else 50)
            iv.layoutParams = FrameLayout.LayoutParams(sz, sz, Gravity.CENTER)
            iv.setImageDrawable(e.icon)
            (tile.getChildAt(1) as TextView).visibility = if (favSet.contains(e.pkg)) View.VISIBLE else View.GONE
            (cell.getChildAt(1) as TextView).text = e.label
            return cell
        }
    }

    private fun makeCell(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(2), dp(10), dp(2), dp(6))
        val tile = FrameLayout(context)
        tile.addView(ImageView(context), FrameLayout.LayoutParams(dp(50), dp(50), Gravity.CENTER))
        tile.addView(TextView(context).apply { text = "★"; textSize = 11f; setTextColor(accent) },
            FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        addView(tile, LinearLayout.LayoutParams(dp(62), dp(62)))
        addView(TextView(context).apply {
            textSize = 11.5f; gravity = Gravity.CENTER; maxLines = 2; ellipsize = TextUtils.TruncateAt.END
            setTextColor(textC); typeface = tf
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90L).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(140L).start()
            }
            false
        }
    }

    // ------------------------------ screen ------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        accent = Prefs.get(this, Prefs.ACCENT)
        textC = Prefs.get(this, Prefs.TEXT)
        tf = Prefs.typeface(this, Prefs.get(this, Prefs.FONT))
        script = Prefs.typeface(this, 0)
        bgTop = ColorUtils.blendARGB(Color.BLACK, accent, 0.22f)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bgTop, Color.BLACK, Color.BLACK))
        }

        // ---- upar: wapas, title, ginti ----
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(4), dp(20), 0) }
        head.addView(IconBtn(this, IconBtn.BACK).apply { color = accent; setOnClickListener { closeAnimated() } },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        head.addView(TextView(this).apply {
            text = "Saari apps"; typeface = script; textSize = 30f; setTextColor(textC)
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        countTv = TextView(this).apply { textSize = 13f; setTextColor(accent) }
        head.addView(countTv, LinearLayout.LayoutParams(-2, -2))

        // ---- glass search ----
        search = EditText(this).apply {
            hint = "App dhundo"; setHintTextColor(Color.argb(120, 255, 255, 255)); setTextColor(Color.WHITE)
            textSize = 15f; setSingleLine(true); background = null
            setPadding(dp(20), dp(12), dp(20), dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { filter(s?.toString().orEmpty()) }
            })
        }
        val pill = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat(); setColor(Color.argb(34, 255, 255, 255)); setStroke(dp(1), al(accent, 110))
            }
            addView(search, FrameLayout.LayoutParams(-1, -2))
        }

        // ---- apps ka grid ----
        val set = AnimationSet(false).apply {
            addAnimation(AlphaAnimation(0f, 1f).apply { duration = 300L })
            addAnimation(ScaleAnimation(0.55f, 1f, 0.55f, 1f,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f
            ).apply { duration = 440L; interpolator = OvershootInterpolator(1.2f) })
            addAnimation(TranslateAnimation(
                Animation.RELATIVE_TO_SELF, 0f, Animation.RELATIVE_TO_SELF, 0f,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0f
            ).apply { duration = 380L; interpolator = DecelerateInterpolator() })
        }
        grid = GridView(this).apply {
            numColumns = (resources.displayMetrics.widthPixels / dp(88)).coerceIn(3, 5)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = dp(2)
            selector = ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false; setPadding(dp(10), dp(6), dp(32), dp(14))
            isVerticalScrollBarEnabled = false
            this.adapter = this@DrawerActivity.adapter
            setOnItemClickListener { _, _, p, _ -> open(shown[p]) }
            setOnItemLongClickListener { _, _, p, _ -> menu(shown[p]); true }
            layoutAnimation = LayoutAnimationController(set, 0.06f)
            visibility = View.INVISIBLE       // reveal ke baad animation ke saath aata hai
        }
        val empty = TextView(this).apply {
            text = "Koi app nahi mili"; textSize = 15f; gravity = Gravity.CENTER
            setTextColor(Color.argb(150, 255, 255, 255)); visibility = View.GONE
        }
        emptyTv = empty

        // ---- A-Z side rail + bada akshar ----
        rail = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (ch in letters) {
            val tv = TextView(this).apply {
                text = ch.toString(); textSize = 10.5f; gravity = Gravity.CENTER; typeface = tf; setTextColor(accent)
            }
            railViews.add(tv)
            rail.addView(tv, LinearLayout.LayoutParams(dp(24), 0, 1f))
        }
        rail.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    v.parent.requestDisallowInterceptTouchEvent(true)
                    val i = (ev.y / v.height * letters.size).toInt().coerceIn(0, letters.size - 1)
                    jump(letters[i])
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    hnd.removeCallbacks(hideBubble); hnd.postDelayed(hideBubble, 500L)
                }
            }
            true
        }
        bubble = TextView(this).apply {
            typeface = script; textSize = 44f; gravity = Gravity.CENTER; setTextColor(accent); visibility = View.GONE
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(Color.argb(200, 0, 0, 0)); setStroke(dp(2), accent)
            }
        }

        val content = FrameLayout(this)
        content.addView(grid, FrameLayout.LayoutParams(-1, -1))
        content.addView(empty, FrameLayout.LayoutParams(-1, -1))
        content.addView(rail, FrameLayout.LayoutParams(dp(26), -1, Gravity.END).apply { topMargin = dp(6); bottomMargin = dp(10) })
        content.addView(bubble, FrameLayout.LayoutParams(dp(88), dp(88), Gravity.CENTER))

        root.addView(head, LinearLayout.LayoutParams(-1, -2))
        root.addView(pill, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(10), dp(16), dp(4)) })
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        headV = head; pillV = pill

        ring = RevealRing(this, accent)
        val frame = FrameLayout(this)
        frame.addView(root, FrameLayout.LayoutParams(-1, -1))
        frame.addView(ring, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, wi ->
            val b = wi.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = wi.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, max(b.bottom, ime.bottom))
            WindowInsetsCompat.CONSUMED
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { closeAnimated() }
        })
        root.visibility = View.INVISIBLE
        root.doOnLayout { reveal() }

        val q = intent.getStringExtra("q")
        if (q != null && q.length == 1) startLetter = q[0].uppercaseChar()
        else if (!q.isNullOrEmpty()) search.setText(q)
    }

    override fun onResume() { super.onResume(); load() }

    override fun onDestroy() { hnd.removeCallbacks(hideBubble); super.onDestroy() }

    // ------------------------------ opening / closing animation ------------------------------
    /** Neeche ke beech se gol ho kar khulta hai, kinare par chamakti ring, phir header, search aur icons ek ek karke aate hain */
    private fun reveal() {
        val cx = root.width / 2
        val cy = root.height
        val endR = hypot(cx.toFloat(), cy.toFloat())
        root.visibility = View.VISIBLE
        try {
            ViewAnimationUtils.createCircularReveal(root, cx, cy, 0f, endR).apply {
                setDuration(560L); setInterpolator(DecelerateInterpolator(1.5f))
            }.start()
            ring.play(cx.toFloat(), cy.toFloat(), endR, 560L, false)
        } catch (e: Exception) { }
        headV.translationY = -dp(26).toFloat(); headV.alpha = 0f
        headV.animate().translationY(0f).alpha(1f).setStartDelay(180L).setDuration(380L)
            .setInterpolator(DecelerateInterpolator()).start()
        pillV.translationY = -dp(18).toFloat(); pillV.alpha = 0f
        pillV.animate().translationY(0f).alpha(1f).setStartDelay(260L).setDuration(380L)
            .setInterpolator(DecelerateInterpolator()).start()
        rail.translationX = dp(36).toFloat(); rail.alpha = 0f
        rail.animate().translationX(0f).alpha(1f).setStartDelay(440L).setDuration(380L).start()
        revealed = true
        tryGridAnim()
    }

    private fun tryGridAnim() {
        if (!animateNext) { grid.visibility = View.VISIBLE; return }
        if (!revealed || !dataReady) return
        animateNext = false
        grid.postDelayed({ grid.visibility = View.VISIBLE; grid.scheduleLayoutAnimation() }, 230L)
    }

    private fun closeAnimated() {
        if (closing) return
        closing = true
        val cx = root.width / 2
        val cy = root.height
        val endR = hypot(cx.toFloat(), cy.toFloat())
        try {
            ring.play(cx.toFloat(), cy.toFloat(), endR, 380L, true)
            ViewAnimationUtils.createCircularReveal(root, cx, cy, endR, 0f).apply {
                setDuration(380L); setInterpolator(AccelerateInterpolator(1.2f))
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(a: Animator) { root.visibility = View.INVISIBLE; finish(); overridePendingTransition(0, 0) }
                })
            }.start()
        } catch (e: Exception) { finish(); overridePendingTransition(0, 0) }
    }

    private fun load() {
        themed = Prefs.get(this, Prefs.DRTINT) == 1
        val th = themed
        val col = Prefs.colorOr(this, Prefs.ICONC)
        Thread {
            val pm = packageManager
            fun ic(d: Drawable): Drawable = if (th) IconTint.apply(d, col) else d
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val res = pm.queryIntentActivities(main, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { Entry(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name, ic(it.loadIcon(pm))) }
                .sortedBy { it.label.lowercase() }
                .toMutableList()
            // HaNeNa Music bhi list mein (favourite bana kar Home par laga sakte ho)
            res.add(0, Entry("HaNeNa Music", Prefs.MUSIC_PKG, MusicActivity::class.java.name, ic(pm.getApplicationIcon(packageName))))
            runOnUiThread {
                all = res
                filter(search.text.toString())
                dataReady = true
                tryGridAnim()
                startLetter?.let { l -> startLetter = null; grid.post { jump(l) } }
            }
        }.start()
    }

    private fun filter(q: String) {
        val t = q.trim()
        shown = if (t.isEmpty()) all else all.filter { it.label.contains(t, ignoreCase = true) }
            .sortedBy { if (it.label.startsWith(t, ignoreCase = true)) 0 else 1 }
        rail.visibility = if (t.isEmpty()) View.VISIBLE else View.GONE
        emptyTv.visibility = if (shown.isEmpty() && all.isNotEmpty()) View.VISIBLE else View.GONE
        countTv.text = "${shown.size} apps"
        refreshFavs()
        val present = shown.map { keyOf(it.label) }.toSet()
        railViews.forEachIndexed { i, tv -> tv.alpha = if (present.contains(letters[i])) 1f else 0.28f }
    }

    private fun refreshFavs() {
        favSet = Prefs.favs(this).toSet()
        adapter.notifyDataSetChanged()
    }

    /** Side rail ka akshar chhoone par us akshar wali pehli app par jao */
    private fun jump(ch: Char) {
        val pos = shown.indexOfFirst { keyOf(it.label) == ch }
        bubble.text = ch.toString(); bubble.visibility = View.VISIBLE
        hnd.removeCallbacks(hideBubble)
        railViews.forEachIndexed { i, tv -> tv.textSize = if (letters[i] == ch) 16f else 10.5f }
        if (pos >= 0) grid.setSelection(pos)
    }

    private fun open(e: Entry) {
        if (e.pkg == Prefs.MUSIC_PKG) { startActivity(Intent(this, MusicActivity::class.java)); return }
        val go = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(e.pkg, e.cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (AppLock.guard(this, go)) return           // locked app: pehle PIN
        try {
            startActivity(go)
        } catch (x: Exception) { Toast.makeText(this, "App khul nahi saki", Toast.LENGTH_SHORT).show() }
    }

    private fun menu(e: Entry) {
        val isFav = Prefs.favs(this).contains(e.pkg)
        if (e.pkg == Prefs.MUSIC_PKG) {
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(e.label)
                .setItems(arrayOf(if (isFav) "Home se hatao" else "Home mein jodo")) { _, _ ->
                    Prefs.toggleFav(this, e.pkg); refreshFavs()
                }.show()
            return
        }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(e.label)
            .setItems(arrayOf(if (isFav) "Home se hatao" else "Home mein jodo", "App info", "Uninstall")) { _, i ->
                when (i) {
                    0 -> { Prefs.toggleFav(this, e.pkg); refreshFavs() }
                    1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${e.pkg}")))
                    else -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${e.pkg}")))
                }
            }.show()
    }
}

/** Reveal ke kinare par chamakti rang ki ring */
private class RevealRing(ctx: Context, private val col: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density
    private var cx = 0f
    private var cy = 0f
    private var r = 0f
    private var a = 0f

    fun play(x: Float, y: Float, endR: Float, dur: Long, reverse: Boolean) {
        cx = x; cy = y
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = dur
            interpolator = if (reverse) AccelerateInterpolator(1.2f) else DecelerateInterpolator(1.5f)
            addUpdateListener {
                val f = it.animatedValue as Float
                r = endR * (if (reverse) 1f - f else f)
                a = if (reverse) (1f - f).coerceIn(0f, 1f) else (1f - f * f).coerceIn(0f, 1f)
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(an: Animator) { a = 0f; invalidate() }
            })
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        if (a < 0.01f) return
        p.style = Paint.Style.STROKE
        p.strokeWidth = 16f * d; p.color = Color.argb((60 * a).toInt(), Color.red(col), Color.green(col), Color.blue(col))
        c.drawCircle(cx, cy, r, p)
        p.strokeWidth = 2.5f * d; p.color = Color.argb((230 * a).toInt(), Color.red(col), Color.green(col), Color.blue(col))
        c.drawCircle(cx, cy, r, p)
    }
}
