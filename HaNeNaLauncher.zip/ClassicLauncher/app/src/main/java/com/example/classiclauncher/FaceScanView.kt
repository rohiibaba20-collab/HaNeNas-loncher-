package com.example.classiclauncher

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.View
import androidx.core.graphics.ColorUtils
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * Chehre ki scan wali animation (sirf drawing, camera istemal nahi hota).
 * 30 fps par chalti hai taake kam RAM wale phone par bhi halki rahe.
 */
class FaceScanView(ctx: Context) : View(ctx) {

    var accent = Color.parseColor("#D4AF37")

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private val seg = Path()

    // 0 idle, 1 scanning, 2 success
    private var state = 0
    private var t0 = 0L
    private var failT = -1L
    private var done: (() -> Unit)? = null
    private var doneFired = false

    private val dots: FloatArray = run {
        val l = ArrayList<Float>()
        for (gy in 0..10) for (gx in 0..8) {
            val u = (gx - 4) / 4f; val v = (gy - 5) / 5f
            if (u * u + v * v <= 1f) { l.add(u); l.add(v) }
        }
        l.toFloatArray()
    }

    fun startScan() { state = 1; t0 = SystemClock.uptimeMillis(); doneFired = false; invalidate() }
    fun fail() { failT = SystemClock.uptimeMillis(); invalidate() }
    fun reset() { state = 0; failT = -1L; done = null; doneFired = false; invalidate() }
    fun success(onDone: () -> Unit) {
        state = 2; t0 = SystemClock.uptimeMillis(); done = onDone; doneFired = false; invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = (230 * d).toInt(); setMeasuredDimension(s, s)
    }

    private fun a(c: Int, al: Float) = Color.argb((al.coerceIn(0f, 1f) * 255).toInt(), Color.red(c), Color.green(c), Color.blue(c))

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val cx = width / 2f; val cy = height / 2f
        val r = min(cx, cy) - 6 * d
        var shake = 0f
        var col = accent
        if (failT > 0) {
            val ft = (now - failT) / 450f
            if (ft < 1f) { shake = sin(ft * 40f) * (1f - ft) * 10f * d; col = ColorUtils.blendARGB(accent, Color.RED, (1f - ft) * 0.8f) }
            else failT = -1L
        }
        c.save(); c.translate(shake, 0f)

        val breath = 0.5f + 0.5f * sin(now / 700.0).toFloat()
        val s = if (state == 2) min(1f, (now - t0) / 700f) else 0f

        // bahar ka ring
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f * d; p.strokeCap = Paint.Cap.ROUND
        p.color = a(col, 0.25f); c.drawCircle(cx, cy, r, p)

        // chaaron kone ke brackets
        val hb = r * 0.82f; val ln = 26 * d
        p.strokeWidth = 3f * d; p.color = a(col, if (state == 0) 0.45f + 0.25f * breath else 0.95f)
        for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1)) {
            val x = cx + sx * hb; val y = cy + sy * hb
            c.drawLine(x, y, x - sx * ln, y, p); c.drawLine(x, y, x, y - sy * ln, p)
        }

        // chehre ka oval
        val ow = r * 0.55f; val oh = r * 0.72f
        rect.set(cx - ow, cy - oh, cx + ow, cy + oh)
        p.strokeWidth = 1.6f * d
        p.color = a(col, if (state == 0) 0.35f + 0.25f * breath else 0.8f)
        c.drawOval(rect, p)

        // mesh dots
        var sy = cy
        if (state == 1) {
            val pr = ((now - t0) % 1600L) / 1600f
            sy = cy - oh + (if (pr < 0.5f) pr * 2f else (1f - pr) * 2f) * 2f * oh
        }
        p.style = Paint.Style.FILL
        var i = 0
        while (i < dots.size) {
            val x = cx + dots[i] * ow; val y = cy + dots[i + 1] * oh
            val br = when (state) {
                1 -> { val q = (y - sy) / (oh * 0.28f); exp(-q * q) * 0.85f + 0.18f }
                2 -> 0.9f * (1f - s * 0.6f)
                else -> 0.2f + 0.2f * breath
            }
            p.color = a(col, br)
            c.drawCircle(x, y, (1.3f + br * 1.3f) * d, p)
            i += 2
        }

        if (state == 1) {
            // scan line + glow
            p.shader = LinearGradient(cx - ow - 10 * d, 0f, cx + ow + 10 * d, 0f,
                intArrayOf(a(col, 0f), a(col, 1f), a(col, 0f)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(cx - ow - 10 * d, sy - 1.5f * d, cx + ow + 10 * d, sy + 1.5f * d, p)
            p.shader = LinearGradient(0f, sy - 22 * d, 0f, sy + 22 * d,
                intArrayOf(a(col, 0f), a(col, 0.28f), a(col, 0f)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(cx - ow, sy - 22 * d, cx + ow, sy + 22 * d, p)
            p.shader = null
            // ghoomta hua arc
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f * d; p.color = a(col, 0.95f)
            rect.set(cx - r, cy - r, cx + r, cy + r)
            c.drawArc(rect, (now / 4L % 360L).toFloat(), 90f, false, p)
        }

        if (state == 2) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 3.5f * d; p.color = a(col, 1f)
            rect.set(cx - r, cy - r, cx + r, cy + r)
            c.drawArc(rect, -90f, 360f * s, false, p)
            // sahi ka nishaan
            val k = ((s - 0.35f) / 0.65f).coerceIn(0f, 1f)
            if (k > 0f) {
                path.reset()
                path.moveTo(cx - r * 0.28f, cy + r * 0.02f)
                path.lineTo(cx - r * 0.08f, cy + r * 0.24f)
                path.lineTo(cx + r * 0.32f, cy - r * 0.2f)
                val pm = PathMeasure(path, false)
                seg.reset(); pm.getSegment(0f, pm.length * k, seg, true)
                p.strokeWidth = 5f * d; c.drawPath(seg, p)
            }
            // chhote sitaare
            p.style = Paint.Style.FILL
            for (j in 0 until 12) {
                val ang = Math.toRadians(j * 30.0)
                val rr = r * (1f + s * 0.3f)
                p.color = a(col, 1f - s)
                c.drawCircle(cx + (rr * Math.cos(ang)).toFloat(), cy + (rr * Math.sin(ang)).toFloat(), 2.5f * d, p)
            }
            if (s >= 1f && !doneFired) {
                doneFired = true
                val cb = done
                postDelayed({ cb?.invoke() }, 250)
            }
        }

        c.restore()
        if (isShown) postInvalidateDelayed(33)
    }
}
