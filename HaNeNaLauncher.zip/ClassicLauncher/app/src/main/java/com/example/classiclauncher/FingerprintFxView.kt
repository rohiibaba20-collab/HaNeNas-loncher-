package com.example.classiclauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Side fingerprint sensor ke saath chalne wali animation (poori screen par transparent overlay).
 *  - idle: sensor ke paas screen ke kinare par saans leti halki roshni + halka fingerprint nishan ("yahan finger rakho")
 *  - scanning: sensor se phailti gol lehren + fingerprint ki lakeeren bharti hain + scan line
 *  - success: lakeeren poori, chamak, sahi ka nishan, phir onEnd
 *  - fail: laal hila hua nishan, X, kinaron par laal roshni
 * Android apps ko "finger abhi laga" ka signal nahi deta; animation tab shuru hoti hai jab phone ka sensor
 * apna nateeja (padh liya / adhoora / galat / sahi) bhejta hai.
 */
class FingerprintFxView(ctx: Context) : View(ctx) {

    var accent = Color.parseColor("#D4AF37")
    var right = true
    var yFrac = 0.42f
    var tf: Typeface = Typeface.DEFAULT

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val clip = Path()
    private val check = Path()
    private val red = Color.parseColor("#FF4D4D")

    private var state = 0            // 0 idle, 1 scanning, 2 success, 3 fail
    private var t0 = SystemClock.uptimeMillis()
    private var poke = 0L
    private var endCb: (() -> Unit)? = null

    private fun al(c: Int, a: Float) = Color.argb((a * 255f).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    fun reset() { state = 0; t0 = SystemClock.uptimeMillis(); endCb = null; invalidate() }

    /** Sensor ne kuch padha (adhoora ya poora): scan animation chalu / badhao */
    fun scanning() {
        val now = SystemClock.uptimeMillis()
        if (state != 1) { state = 1; t0 = now }
        poke = now
        invalidate()
    }

    fun success(onEnd: () -> Unit) {
        state = 2; t0 = SystemClock.uptimeMillis(); endCb = onEnd; invalidate()
    }

    fun fail() { state = 3; t0 = SystemClock.uptimeMillis(); endCb = null; invalidate() }

    // ------------------------------ drawing ------------------------------
    private fun icon(c: Canvas, cx: Float, cy: Float, r: Float, progress: Float, color: Int, alpha: Float) {
        val n = 6
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 2.4f * d
        for (k in 0 until n) {
            val rr = r * (0.2f + 0.8f * k / (n - 1))
            val vis = (progress * n - k).coerceIn(0f, 1f)
            if (vis <= 0f) continue
            p.color = al(color, alpha * (0.45f + 0.55f * vis))
            rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
            val start = -200f + k * 23f
            c.drawArc(rect, start, 230f * vis, false, p)
            if (k > 1) c.drawArc(rect, start + 250f, 60f * vis, false, p)
        }
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f) return
        val sx = if (right) w else 0f
        val sy = h * yFrac
        val dir = if (right) -1f else 1f
        val r = 34f * d
        val ix = sx + dir * 84f * d
        val iy = sy
        val t = (now - t0).toFloat()
        val br = 0.5f + 0.5f * sin(now / 600f)

        if (state == 1 && now - poke > 1700L) { state = 0; t0 = now }

        // ---- kinare ki saans leti roshni (hamesha) ----
        val tone = if (state == 3) red else accent
        p.style = Paint.Style.FILL
        for (k in 3 downTo 1) {
            p.color = al(tone, (0.05f + 0.05f * br) * (4 - k) / 3f * (if (state == 0) 1f else 2.2f))
            c.drawCircle(sx, sy, 18f * d * k + 10f * d * br, p)
        }

        when (state) {
            0 -> icon(c, ix, iy, r, 1f, accent, 0.18f + 0.16f * br)

            1 -> {
                // sensor se phailti lehren
                p.style = Paint.Style.STROKE
                val maxR = hypot(w, h) * 0.85f
                for (j in 0..2) {
                    val age = (((now - t0) + j * 370L) % 1110L) / 1110f
                    p.strokeWidth = (2f + (1f - age) * 5f) * d
                    p.color = al(accent, (1f - age) * 0.45f)
                    c.drawCircle(sx, sy, age * maxR, p)
                }
                val prog = min(1f, 0.25f + (t / 1100f) * 0.75f)
                icon(c, ix, iy, r, prog, accent, 1f)
                // scan line (gol ke andar)
                c.save()
                clip.reset(); clip.addCircle(ix, iy, r * 1.1f, Path.Direction.CW); c.clipPath(clip)
                val ly = iy - r + 2f * r * (((now - t0) % 900L) / 900f)
                p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
                p.strokeWidth = 2.6f * d; p.color = al(accent, 0.95f); c.drawLine(ix - r, ly, ix + r, ly, p)
                p.strokeWidth = 9f * d; p.color = al(accent, 0.18f); c.drawLine(ix - r, ly, ix + r, ly, p)
                c.restore()
                label(c, ix, iy + r + 24f * d, "Scan ho raha hai...", accent)
            }

            2 -> {
                val pr = min(1f, t / 420f)
                icon(c, ix, iy, r, 1f, accent, 1f)
                p.style = Paint.Style.STROKE
                val pulse = min(1f, t / 900f)
                p.strokeWidth = (6f - 4f * pulse) * d; p.color = al(accent, (1f - pulse) * 0.8f)
                c.drawCircle(ix, iy, r * (1.1f + 2.6f * pulse), p)
                p.strokeWidth = 3f * d; p.color = al(accent, (1f - pulse) * 0.5f)
                c.drawCircle(sx, sy, pulse * hypot(w, h) * 0.9f, p)
                // sahi ka nishan
                val ck = ((t - 250f) / 350f).coerceIn(0f, 1f)
                if (ck > 0f) {
                    p.style = Paint.Style.STROKE; p.strokeWidth = 4.2f * d; p.color = al(accent, 1f)
                    check.reset()
                    check.moveTo(ix - r * 0.38f, iy + r * 0.02f)
                    check.lineTo(ix - r * 0.1f, iy + r * 0.3f)
                    check.lineTo(ix + r * 0.42f, iy - r * 0.28f)
                    c.save(); c.clipRect(ix - r, iy - r, ix - r + 2f * r * ck, iy + r); c.drawPath(check, p); c.restore()
                }
                label(c, ix, iy + r + 24f * d, "Pehchan liya", accent)
                if (pr >= 1f && t > 950f) { val cb = endCb; endCb = null; cb?.invoke() }
            }

            else -> {
                val k = max(0f, 1f - t / 700f)
                val shake = sin(t * 0.045f) * 9f * d * k
                icon(c, ix + shake, iy, r, 1f, red, 1f)
                p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 4.4f * d; p.color = al(red, 1f)
                c.drawLine(ix + shake - r * 0.34f, iy - r * 0.34f, ix + shake + r * 0.34f, iy + r * 0.34f, p)
                c.drawLine(ix + shake - r * 0.34f, iy + r * 0.34f, ix + shake + r * 0.34f, iy - r * 0.34f, p)
                // kinaron par laal roshni (do baar chamakti hai)
                val pulse = (0.5f + 0.5f * sin(t / 90f)) * max(0f, 1f - t / 1300f)
                p.strokeWidth = 14f * d * pulse; p.color = al(red, 0.55f * pulse); c.drawRect(0f, 0f, w, h, p)
                p.strokeWidth = 4f * d; p.color = al(red, 0.7f * pulse); c.drawRect(0f, 0f, w, h, p)
                val age = min(1f, t / 600f)
                p.strokeWidth = (5f - 3f * age) * d; p.color = al(red, (1f - age) * 0.7f)
                c.drawCircle(sx, sy, age * hypot(w, h) * 0.6f, p)
                label(c, ix, iy + r + 24f * d, "Galat finger!", red)
                if (t > 1500f) { state = 0; t0 = now }
            }
        }
        postInvalidateOnAnimation()
    }

    private fun label(c: Canvas, x: Float, y: Float, s: String, col: Int) {
        p.style = Paint.Style.FILL; p.typeface = tf; p.textSize = 13f * d; p.textAlign = Paint.Align.CENTER
        p.color = al(col, 0.95f)
        c.drawText(s, x, y, p)
        p.textAlign = Paint.Align.LEFT
    }
}
