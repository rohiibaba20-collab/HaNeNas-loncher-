package com.example.classiclauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Side fingerprint sensor ke saath chalne wali animation (poori screen par transparent overlay).
 * Koi fingerprint ka nishan nahi dikhta, sirf animation. 4 style:
 *   0 Lehar  : sensor se phailti lehren
 *   1 Edge   : screen ke kinare par chalti roshni ki patti
 *   2 Orb    : chamakta gola, ghoomte kan, sahi par phatta hai
 *   3 Radar  : ghoomti sweep line aur blips
 * State: idle -> scanning (sensor ne kuch padha) -> success / fail.
 * Android "finger abhi laga" ka signal nahi deta, animation tab shuru hoti hai jab sensor apna nateeja bhejta hai.
 */
class FingerprintFxView(ctx: Context) : View(ctx) {

    var accent = Color.parseColor("#D4AF37")
    var onRight = true
    var yFrac = 0.42f
    var tf: Typeface = Typeface.DEFAULT
    var style = 0
    var idleGlow = false          // idle mein bhi halki saans leti roshni

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val red = Color.parseColor("#FF4D4D")

    private var state = 0            // 0 idle, 1 scanning, 2 success, 3 fail
    private var t0 = SystemClock.uptimeMillis()
    private var poke = 0L
    private var endCb: (() -> Unit)? = null

    private fun al(c: Int, a: Float) = Color.argb((a * 255f).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    fun reset() { state = 0; t0 = SystemClock.uptimeMillis(); endCb = null; invalidate() }

    fun scanning() {
        val now = SystemClock.uptimeMillis()
        if (state != 1) { state = 1; t0 = now }
        poke = now
        invalidate()
    }

    fun success(onEnd: () -> Unit) { state = 2; t0 = SystemClock.uptimeMillis(); endCb = onEnd; invalidate() }

    fun fail() { state = 3; t0 = SystemClock.uptimeMillis(); endCb = null; invalidate() }

    // ------------------------------ saajha helper ------------------------------
    /** Kinare par sensor ke paas naram roshni ke gole */
    private fun glow(c: Canvas, sx: Float, sy: Float, col: Int, strength: Float, br: Float) {
        p.style = Paint.Style.FILL
        for (k in 3 downTo 1) {
            p.color = al(col, (0.05f + 0.05f * br) * (4 - k) / 3f * strength)
            c.drawCircle(sx, sy, 18f * d * k + 10f * d * br, p)
        }
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f) return
        val sx = if (onRight) w else 0f
        val sy = h * yFrac
        val dir = if (onRight) -1f else 1f
        val t = (now - t0).toFloat()
        val br = 0.5f + 0.5f * sin(now / 600f)
        if (state == 1 && now - poke > 1700L) { state = 0; t0 = now }
        val col = if (state == 3) red else accent

        if (state != 0 || idleGlow) glow(c, sx, sy, col, if (state == 0) 1f else 2.2f, br)

        when (style) {
            1 -> edge(c, w, h, sx, sy, t, now, col)
            2 -> orb(c, w, h, sx, sy, dir, t, now, col)
            3 -> radar(c, w, h, sx, sy, dir, t, now, col)
            else -> waves(c, w, h, sx, sy, t, now, col)
        }

        if (state == 2 && t > 1000f) { val cb = endCb; endCb = null; cb?.invoke() }
        if (state == 3 && t > 1500f) { state = 0; t0 = now }
        if (state != 0 || idleGlow) postInvalidateOnAnimation()
    }

    // ------------------------------ 0: lehren ------------------------------
    private fun waves(c: Canvas, w: Float, h: Float, sx: Float, sy: Float, t: Float, now: Long, col: Int) {
        val maxR = hypot(w, h) * 0.85f
        p.style = Paint.Style.STROKE
        when (state) {
            1 -> for (j in 0..2) {
                val age = (((now - t0) + j * 370L) % 1110L) / 1110f
                p.strokeWidth = (2f + (1f - age) * 6f) * d; p.color = al(col, (1f - age) * 0.5f)
                c.drawCircle(sx, sy, age * maxR, p)
            }
            2 -> {
                val a = min(1f, t / 900f)
                for (j in 0..1) {
                    val q = ((t - j * 160f) / 900f).coerceIn(0f, 1f)
                    p.strokeWidth = (7f - 5f * q) * d; p.color = al(col, (1f - q) * 0.85f)
                    c.drawCircle(sx, sy, q * maxR, p)
                }
                p.style = Paint.Style.FILL; p.color = al(col, (1f - a) * 0.10f); c.drawRect(0f, 0f, w, h, p)
            }
            3 -> {
                val pulse = (0.5f + 0.5f * sin(t / 90f)) * max(0f, 1f - t / 1300f)
                p.strokeWidth = 14f * d * pulse; p.color = al(col, 0.55f * pulse); c.drawRect(0f, 0f, w, h, p)
                p.strokeWidth = 4f * d; p.color = al(col, 0.7f * pulse); c.drawRect(0f, 0f, w, h, p)
                for (j in 0..1) {
                    val q = ((t - j * 200f) / 700f).coerceIn(0f, 1f)
                    p.strokeWidth = (5f - 3f * q) * d; p.color = al(col, (1f - q) * 0.7f)
                    c.drawCircle(sx, sy, q * maxR * 0.7f, p)
                }
            }
        }
    }

    // ------------------------------ 1: kinare ki roshni ------------------------------
    private fun bar(c: Canvas, x: Float, y0: Float, y1: Float, col: Int, a: Float) {
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 26f * d; p.color = al(col, 0.10f * a); c.drawLine(x, y0, x, y1, p)
        p.strokeWidth = 14f * d; p.color = al(col, 0.22f * a); c.drawLine(x, y0, x, y1, p)
        p.strokeWidth = 4.5f * d; p.color = al(col, 0.95f * a); c.drawLine(x, y0, x, y1, p)
        p.strokeCap = Paint.Cap.BUTT
    }

    private fun edge(c: Canvas, w: Float, h: Float, sx: Float, sy: Float, t: Float, now: Long, col: Int) {
        val x = if (onRight) w - 3f * d else 3f * d
        when (state) {
            1 -> {
                val half = h * (0.10f + 0.04f * sin(now / 220f))
                bar(c, x, sy - half, sy + half, col, 0.9f)
                // upar-neeche daudta chamakta bindu
                val yy = sy + sin(now / 240f) * h * 0.28f
                p.style = Paint.Style.FILL
                p.color = al(col, 0.35f); c.drawCircle(x, yy, 14f * d, p)
                p.color = al(col, 1f); c.drawCircle(x, yy, 5f * d, p)
            }
            2 -> {
                val q = (t / 650f).coerceIn(0f, 1f)
                val half = (0.08f + 0.92f * q) * h * 0.5f
                bar(c, x, sy - half, sy + half, col, 1f - max(0f, (t - 650f) / 350f))
            }
            3 -> {
                val on = ((t / 120f).toInt() % 2 == 0) && t < 1000f
                val shake = sin(t * 0.05f) * 5f * d * max(0f, 1f - t / 700f)
                if (on) bar(c, x + shake * dir(), 0f, h, col, 1f)
                else bar(c, x, sy - h * 0.12f, sy + h * 0.12f, col, 0.5f)
            }
            else -> if (idleGlow) bar(c, x, sy - h * 0.05f, sy + h * 0.05f, col, 0.25f + 0.2f * sin(now / 600f))
        }
    }

    private fun dir() = if (onRight) -1f else 1f

    // ------------------------------ 2: orb ------------------------------
    private fun orb(c: Canvas, w: Float, h: Float, sx: Float, sy: Float, dir: Float, t: Float, now: Long, col: Int) {
        val ox0 = sx + dir * 74f * d
        val oy = sy
        p.style = Paint.Style.FILL
        when (state) {
            0 -> if (idleGlow) { p.color = al(col, 0.10f); c.drawCircle(ox0, oy, 20f * d, p); p.color = al(col, 0.30f); c.drawCircle(ox0, oy, 7f * d, p) }
            1 -> {
                val r = 24f * d * (1f + 0.12f * sin(now / 140f))
                for (k in 4 downTo 1) { p.color = al(col, 0.07f * (5 - k)); c.drawCircle(ox0, oy, r * (0.7f + 0.35f * k), p) }
                p.color = al(col, 0.95f); c.drawCircle(ox0, oy, r * 0.5f, p)
                for (i in 0 until 9) {
                    val a = now / 170.0 + i * (Math.PI * 2 / 9)
                    val rr = r * 1.9f + 7f * d * sin(now / 200f + i)
                    p.color = al(col, 0.9f)
                    c.drawCircle(ox0 + (rr * cos(a)).toFloat(), oy + (rr * sin(a)).toFloat(), 2.6f * d, p)
                }
            }
            2 -> {
                val q = (t / 900f).coerceIn(0f, 1f)
                p.color = al(col, (1f - q) * 0.9f); c.drawCircle(ox0, oy, 24f * d * (1f - q * 0.6f), p)
                for (i in 0 until 28) {
                    val a = i * (Math.PI * 2 / 28) + (i % 3) * 0.11
                    val sp = (0.30f + 0.12f * (i % 3)) * d
                    val dist = 24f * d + t * sp
                    p.color = al(col, (1f - q) * 0.95f)
                    c.drawCircle(ox0 + (dist * cos(a)).toFloat(), oy + (dist * sin(a)).toFloat(), (3.4f - 2f * q) * d, p)
                }
                p.style = Paint.Style.STROKE; p.strokeWidth = (5f - 4f * q) * d; p.color = al(col, (1f - q) * 0.6f)
                c.drawCircle(ox0, oy, 24f * d + q * 150f * d, p)
            }
            3 -> {
                val k = max(0f, 1f - t / 700f)
                val ox = ox0 + sin(t * 0.05f) * 10f * d * k
                val fade = max(0f, 1f - t / 1400f)
                for (m in 4 downTo 1) { p.color = al(col, 0.08f * (5 - m) * fade); c.drawCircle(ox, oy, 24f * d * (0.7f + 0.35f * m), p) }
                p.color = al(col, 0.95f * fade); c.drawCircle(ox, oy, 12f * d, p)
                val q = (t / 700f).coerceIn(0f, 1f)
                for (i in 0 until 10) {                       // kan andar ki taraf girte hain
                    val a = i * (Math.PI * 2 / 10)
                    val dist = (60f * d) * (1f - q) + 14f * d
                    p.color = al(col, (1f - q) * 0.85f)
                    c.drawCircle(ox + (dist * cos(a)).toFloat(), oy + (dist * sin(a)).toFloat(), 2.4f * d, p)
                }
            }
        }
    }

    // ------------------------------ 3: radar ------------------------------
    private fun radar(c: Canvas, w: Float, h: Float, sx: Float, sy: Float, dir: Float, t: Float, now: Long, col: Int) {
        val maxR = min(w * 0.95f, h * 0.45f)
        val speed = when (state) { 1 -> 0.5f; 2 -> 0.9f; 3 -> 1.1f; else -> 0.12f }
        val ang = ((now - t0) * speed) % 360f
        val vis = when (state) {
            0 -> if (idleGlow) 0.35f else 0f
            1 -> 1f
            2 -> max(0f, 1f - t / 1000f)
            else -> max(0f, 1f - t / 1400f)
        }
        if (vis <= 0f) return
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f * d
        for (k in 1..3) { p.color = al(col, 0.22f * vis); c.drawCircle(sx, sy, maxR * k / 3f, p) }
        rect.set(sx - maxR, sy - maxR, sx + maxR, sy + maxR)
        p.style = Paint.Style.FILL
        for (k in 0 until 16) {
            p.color = al(col, 0.30f * vis * (1f - k / 16f))
            c.drawArc(rect, ang - (k + 1) * 4.5f, 4.5f, true, p)
        }
        val r = Math.toRadians(ang.toDouble())
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.4f * d; p.color = al(col, 0.95f * vis)
        c.drawLine(sx, sy, sx + (maxR * cos(r)).toFloat(), sy + (maxR * sin(r)).toFloat(), p)
        // blips: sweep guzarne par chamakte hain
        p.style = Paint.Style.FILL
        for (i in 0 until 7) {
            val ba = (i * 53f + 20f) % 360f
            val br2 = maxR * (0.28f + 0.1f * ((i * 37) % 7))
            val behind = ((ang - ba) % 360f + 360f) % 360f
            val a = if (behind < 200f) (1f - behind / 200f) else 0f
            if (a <= 0.02f) continue
            val rb = Math.toRadians(ba.toDouble())
            p.color = al(col, a * vis)
            c.drawCircle(sx + (br2 * cos(rb)).toFloat(), sy + (br2 * sin(rb)).toFloat(), 3.6f * d, p)
        }
        if (state == 2) {
            val q = (t / 1000f).coerceIn(0f, 1f)
            p.style = Paint.Style.STROKE; p.strokeWidth = (5f - 3.5f * q) * d; p.color = al(col, (1f - q) * 0.8f)
            c.drawCircle(sx, sy, maxR * (0.3f + 0.8f * q), p)
        }
    }
}
