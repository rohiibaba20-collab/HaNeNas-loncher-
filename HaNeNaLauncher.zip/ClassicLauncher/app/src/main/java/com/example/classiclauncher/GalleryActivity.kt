package com.example.classiclauncher

import android.Manifest
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Gallery ki ek photo ya video */
class GItem(
    val id: Long, val uri: Uri, val video: Boolean, val date: Long, val dur: Long,
    val w: Int, val h: Int, val size: Long, val name: String, val bucketId: Long, val bucket: String
) {
    val key: String get() = (if (video) "v" else "i") + id
}

/** Gallery aur viewer ke beech list baantne ke liye (ek hi process hai) */
object GalleryState { var items: List<GItem> = emptyList() }

/** Gallery ke favourites (dil) */
object GalleryFav {
    private var cache: MutableSet<String>? = null
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("gallery", Context.MODE_PRIVATE)
    private fun set(c: Context): MutableSet<String> {
        cache?.let { return it }
        val s = (sp(c).getString("favs", "") ?: "").split(",").filter { it.isNotBlank() }.toMutableSet()
        cache = s; return s
    }
    fun has(c: Context, key: String) = set(c).contains(key)
    fun toggle(c: Context, key: String): Boolean {
        val s = set(c)
        val now = if (s.contains(key)) { s.remove(key); false } else { s.add(key); true }
        sp(c).edit().putString("favs", s.joinToString(",")).apply()
        return now
    }
    fun setAll(c: Context, keys: Collection<String>, on: Boolean) {
        val s = set(c)
        if (on) s.addAll(keys) else s.removeAll(keys.toSet())
        sp(c).edit().putString("favs", s.joinToString(",")).apply()
    }
}

/** Ek tile: gol kone ka thumbnail, video ka badge + duration, dil, aur chunne ka nishan */
class GalleryThumb(ctx: Context, private val k: Skin) : View(ctx) {
    var bmp: Bitmap? = null
        set(v) { field = v; shader = null; invalidate() }
    var video = false
    var dur = ""
    var fav = false
    var selecting = false
    var selected = false
    private var shader: BitmapShader? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private val m = Matrix()
    private val path = Path()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { shader = null }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val r = k.dp(14).toFloat()
        val inset = if (selected) k.dp(7).toFloat() else 0f
        rf.set(inset, inset, w - inset, h - inset)
        val b = bmp
        p.style = Paint.Style.FILL
        if (b != null) {
            if (shader == null) {
                val sh = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                val sc = maxOf(w / b.width, h / b.height)
                m.reset(); m.setScale(sc, sc); m.postTranslate((w - b.width * sc) / 2f, (h - b.height * sc) / 2f)
                sh.setLocalMatrix(m); shader = sh
            }
            p.shader = shader; c.drawRoundRect(rf, r, r, p); p.shader = null
        } else { p.color = Color.rgb(26, 26, 32); c.drawRoundRect(rf, r, r, p) }

        if (video) {
            p.shader = LinearGradient(0f, h * 0.62f, 0f, h, 0, Color.argb(170, 0, 0, 0), Shader.TileMode.CLAMP)
            c.save(); c.clipRect(rf.left, h * 0.62f, rf.right, rf.bottom); c.drawRoundRect(rf, r, r, p); c.restore(); p.shader = null
            val u = k.dp(5).toFloat(); val bx = rf.left + k.dp(9); val by = rf.bottom - k.dp(10)
            p.color = Color.WHITE
            path.reset(); path.moveTo(bx, by - u * 1.1f); path.lineTo(bx + u * 1.6f, by - u * 0.1f); path.lineTo(bx, by + u * 0.9f); path.close(); c.drawPath(path, p)
            p.typeface = k.tf; p.textSize = k.dp(11).toFloat(); p.textAlign = Paint.Align.RIGHT
            c.drawText(dur, rf.right - k.dp(8), rf.bottom - k.dp(7), p); p.textAlign = Paint.Align.LEFT
        }
        if (fav) {
            val cx = rf.right - k.dp(14); val cy = rf.top + k.dp(14); val u = k.dp(5).toFloat()
            path.reset()
            path.moveTo(cx, cy + u * 0.95f)
            path.cubicTo(cx - u * 1.8f, cy - u * 0.15f, cx - u * 0.95f, cy - u * 1.4f, cx, cy - u * 0.45f)
            path.cubicTo(cx + u * 0.95f, cy - u * 1.4f, cx + u * 1.8f, cy - u * 0.15f, cx, cy + u * 0.95f)
            path.close()
            p.color = Color.argb(120, 0, 0, 0); c.drawCircle(cx, cy, u * 2.1f, p)
            p.color = k.accent; c.drawPath(path, p)
        }
        if (selected) {
            p.style = Paint.Style.STROKE; p.strokeWidth = k.dp(3).toFloat(); p.color = k.accent
            c.drawRoundRect(rf, r, r, p); p.style = Paint.Style.FILL
            p.color = Color.argb(60, 0, 0, 0); c.drawRoundRect(rf, r, r, p)
        }
        if (selecting) {
            val cx = rf.left + k.dp(16); val cy = rf.top + k.dp(16); val rr = k.dp(10).toFloat()
            if (selected) {
                p.style = Paint.Style.FILL; p.color = k.accent; c.drawCircle(cx, cy, rr, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = k.dp(2).toFloat(); p.color = Color.BLACK; p.strokeCap = Paint.Cap.ROUND
                path.reset(); path.moveTo(cx - rr * 0.45f, cy); path.lineTo(cx - rr * 0.1f, cy + rr * 0.4f); path.lineTo(cx + rr * 0.5f, cy - rr * 0.35f); c.drawPath(path, p)
            } else {
                p.style = Paint.Style.FILL; p.color = Color.argb(70, 0, 0, 0); c.drawCircle(cx, cy, rr, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = k.dp(2).toFloat(); p.color = Color.WHITE; c.drawCircle(cx, cy, rr, p)
            }
            p.style = Paint.Style.FILL
        }
    }
}

/** Album ka bada card: cover photo, neeche naam aur ginti */
class AlbumCard(ctx: Context, private val k: Skin) : View(ctx) {
    var bmp: Bitmap? = null
        set(v) { field = v; shader = null; invalidate() }
    var name = ""
    var count = ""
    private var shader: BitmapShader? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private val m = Matrix()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { shader = null }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val r = k.dp(20).toFloat()
        rf.set(0f, 0f, w, h)
        val b = bmp
        p.style = Paint.Style.FILL
        if (b != null) {
            if (shader == null) {
                val sh = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                val sc = maxOf(w / b.width, h / b.height)
                m.reset(); m.setScale(sc, sc); m.postTranslate((w - b.width * sc) / 2f, (h - b.height * sc) / 2f)
                sh.setLocalMatrix(m); shader = sh
            }
            p.shader = shader; c.drawRoundRect(rf, r, r, p); p.shader = null
        } else { p.color = Color.rgb(26, 26, 32); c.drawRoundRect(rf, r, r, p) }
        p.shader = LinearGradient(0f, h * 0.45f, 0f, h, 0, Color.argb(215, 0, 0, 0), Shader.TileMode.CLAMP)
        c.drawRoundRect(rf, r, r, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = k.dp(1).toFloat(); p.color = k.al(k.accent, 90); c.drawRoundRect(rf, r, r, p)
        p.style = Paint.Style.FILL
        p.typeface = k.script; p.textSize = k.dp(19).toFloat(); p.color = Color.WHITE
        c.drawText(if (name.length > 16) name.take(15) + "…" else name, k.dp(14).toFloat(), h - k.dp(30).toFloat(), p)
        p.typeface = k.tf; p.textSize = k.dp(12).toFloat(); p.color = k.accent
        c.drawText(count, k.dp(14).toFloat(), h - k.dp(12).toFloat(), p)
    }
}

/** HaNeNa Gallery: din ke hisab se sections, albums, videos, favourites, chun kar share / delete */
class GalleryActivity : AppCompatActivity() {

    private class Album(val id: Long, val name: String, val cover: GItem, val count: Int)
    private class Row(val header: String?, val tiles: List<GItem>?, val albums: List<Album>?)

    private lateinit var k: Skin
    private lateinit var lv: ListView
    private lateinit var msg: TextView
    private lateinit var titleTv: TextView
    private lateinit var sub: TextView
    private lateinit var selBar: LinearLayout
    private lateinit var selCount: TextView
    private lateinit var headBar: LinearLayout
    private lateinit var tabHolder: FrameLayout
    private var all: List<GItem> = emptyList()
    private var shown: List<GItem> = emptyList()
    private var rows: List<Row> = emptyList()
    private var tab = 0
    private var album: Album? = null
    private var selecting = false
    private val selected = LinkedHashSet<String>()
    private val dayFmt = SimpleDateFormat("EEE, dd MMM", Locale.getDefault())
    private val fullFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    private val perm: List<String>
        get() = if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private val ask = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { load() }
    private val del = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == RESULT_OK) { exitSelect(); load() }
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).toInt()
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(p: Int) = rows[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getViewTypeCount() = 3
        override fun getItemViewType(p: Int) = if (rows[p].header != null) 0 else if (rows[p].tiles != null) 1 else 2
        override fun isEnabled(p: Int) = false
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val r = rows[p]
            return if (r.header != null) headerView(r.header, cv) else if (r.tiles != null) tilesView(r.tiles, cv) else albumsView(r.albums!!, cv)
        }
    }

    // ------------------------------ screen ------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        k = Skin(this)
        window.statusBarColor = k.bgTop(); window.navigationBarColor = Color.BLACK
        val frame = FrameLayout(this).apply { fitsSystemWindows = true; background = k.gradient() }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        headBar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(8), k.dp(4), k.dp(14), k.dp(2)) }
        headBar.addView(IconBtn(this, IconBtn.BACK).apply { color = k.accent; setOnClickListener { onBackPressedDispatcher.onBackPressed() } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        val tcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleTv = k.tv("Gallery", 28f, k.textC, true); sub = k.tv("", 12f, k.accent)
        tcol.addView(titleTv); tcol.addView(sub)
        headBar.addView(tcol, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(6) })
        headBar.addView(k.button("Chuno") { startSelect() })
        col.addView(headBar, k.lp())

        selBar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(8), k.dp(4), k.dp(8), k.dp(2)); visibility = View.GONE }
        selBar.addView(IconBtn(this, IconBtn.CLOSE).apply { color = k.accent; setOnClickListener { exitSelect() } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        selCount = k.tv("0", 20f, k.textC, true)
        selBar.addView(selCount, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(6) })
        selBar.addView(IconBtn(this, IconBtn.HEART).apply { color = k.accent; setOnClickListener { favSelected() } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        selBar.addView(IconBtn(this, IconBtn.SHARE).apply { color = k.accent; setOnClickListener { shareSelected() } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        selBar.addView(IconBtn(this, IconBtn.TRASH).apply { color = k.red; setOnClickListener { deleteSelected() } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        col.addView(selBar, k.lp())

        lv = ListView(this).apply {
            divider = null; selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false; setPadding(k.dp(8), k.dp(4), k.dp(8), k.dp(96)); adapter = this@GalleryActivity.adapter
            isVerticalScrollBarEnabled = false
        }
        col.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        frame.addView(col, FrameLayout.LayoutParams(-1, -1))

        msg = k.tv("", 14f, k.dim(160)).apply { gravity = Gravity.CENTER; setPadding(k.dp(30), 0, k.dp(30), 0) }
        frame.addView(msg, FrameLayout.LayoutParams(-1, -1))

        // neeche tairta glass tab bar
        tabHolder = FrameLayout(this).apply { background = k.glass(30, 70, 120); setPadding(k.dp(6), k.dp(6), k.dp(6), k.dp(6)) }
        frame.addView(tabHolder, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(k.dp(16), 0, k.dp(16), k.dp(14)) })
        fillTabs()
        setContentView(frame)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (selecting) exitSelect()
                else if (album != null) { album = null; rebuild() }
                else finish()
            }
        })
        if (perm.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }) load() else ask.launch(perm.toTypedArray())
    }

    override fun onResume() { super.onResume(); if (all.isNotEmpty()) adapter.notifyDataSetChanged() }

    private fun fillTabs() {
        tabHolder.removeAllViews()
        tabHolder.addView(k.chips(listOf("Photos", "Albums", "Videos", "Favourites"), tab) { tab = it; album = null; exitSelect(); fillTabs(); rebuild() })
    }

    // ------------------------------ data ------------------------------
    private fun query(video: Boolean): List<GItem> {
        val out = ArrayList<GItem>()
        try {
            val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val cols = arrayListOf("_id", "_display_name", "datetaken", "date_added", "_size", "width", "height", "bucket_id", "bucket_display_name")
            if (video) cols.add("duration")
            contentResolver.query(base, cols.toTypedArray(), null, null, "date_added DESC")?.use { q ->
                while (q.moveToNext()) {
                    val id = q.getLong(0)
                    val taken = q.getLong(2)
                    val date = if (taken > 0) taken else q.getLong(3) * 1000L
                    out.add(GItem(id, ContentUris.withAppendedId(base, id), video, date, if (video) q.getLong(9) else 0L,
                        q.getInt(5), q.getInt(6), q.getLong(4), q.getString(1) ?: "", q.getLong(7), q.getString(8) ?: "Other"))
                }
            }
        } catch (e: Exception) { }
        return out
    }

    private fun load() {
        Thread {
            val list = (query(false) + query(true)).sortedByDescending { it.date }
            runOnUiThread {
                all = list
                msg.text = if (list.isEmpty()) "Gallery khali hai ya ijazat nahi di." else ""
                msg.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                rebuild()
            }
        }.start()
    }

    private fun dayLabel(ms: Long): String {
        val now = Calendar.getInstance(); val t = Calendar.getInstance().apply { timeInMillis = ms }
        val diff = (now.get(Calendar.YEAR) - t.get(Calendar.YEAR)) * 366 + (now.get(Calendar.DAY_OF_YEAR) - t.get(Calendar.DAY_OF_YEAR))
        return if (diff == 0 && now.get(Calendar.YEAR) == t.get(Calendar.YEAR)) "Aaj"
        else if (diff == 1) "Kal"
        else if (now.get(Calendar.YEAR) == t.get(Calendar.YEAR)) dayFmt.format(Date(ms)) else fullFmt.format(Date(ms))
    }

    private fun rebuild() {
        val favKeys = all.filter { GalleryFav.has(this, it.key) }
        val a = album
        val base = when {
            a != null -> all.filter { it.bucketId == a.id }
            tab == 2 -> all.filter { it.video }
            tab == 3 -> favKeys
            else -> all
        }
        shown = base
        val out = ArrayList<Row>()
        if (tab == 1 && a == null) {
            val groups = all.groupBy { it.bucketId }
            val albums = groups.map { (id, l) -> Album(id, l[0].bucket, l[0], l.size) }.sortedByDescending { it.count }
            albums.chunked(2).forEach { out.add(Row(null, null, it)) }
            titleTv.text = "Albums"; sub.text = "${albums.size} albums"
        } else {
            var last = ""
            var bucket = ArrayList<GItem>()
            fun flush() { bucket.chunked(3).forEach { out.add(Row(null, it, null)) }; bucket = ArrayList() }
            for (it in base) {
                val d = dayLabel(it.date)
                if (d != last) { flush(); out.add(Row(d, null, null)); last = d }
                bucket.add(it)
            }
            flush()
            titleTv.text = a?.name ?: when (tab) { 2 -> "Videos"; 3 -> "Favourites"; else -> "Gallery" }
            sub.text = "${base.size} items"
        }
        if (all.isNotEmpty() && out.isEmpty()) { msg.text = if (tab == 3) "Abhi koi favourite nahi. Photo par lamba dabao, phir dil dabao." else "Kuch nahi mila."; msg.visibility = View.VISIBLE }
        else if (all.isNotEmpty()) msg.visibility = View.GONE
        rows = out
        adapter.notifyDataSetChanged()
    }

    // ------------------------------ rows ------------------------------
    private fun headerView(t: String, cv: View?): View {
        val v = (cv as? TextView) ?: TextView(this).apply {
            textSize = 20f; setTextColor(k.accent); typeface = k.script; setPadding(k.dp(10), k.dp(16), k.dp(10), k.dp(6))
        }
        v.text = t
        return v
    }

    private fun tilesView(items: List<GItem>, cv: View?): View {
        val sz = (resources.displayMetrics.widthPixels - k.dp(16 + 12)) / 3
        val row = (cv as? LinearLayout) ?: LinearLayout(this).apply {
            for (i in 0 until 3) addView(GalleryThumb(context, k), LinearLayout.LayoutParams(sz, sz).apply { setMargins(k.dp(2), k.dp(2), k.dp(2), k.dp(2)) })
        }
        for (i in 0 until 3) {
            val th = row.getChildAt(i) as GalleryThumb
            val it = items.getOrNull(i)
            if (it == null) { th.visibility = View.INVISIBLE; th.setOnClickListener(null); th.setOnLongClickListener(null); continue }
            th.visibility = View.VISIBLE
            th.video = it.video; th.dur = fmt(it.dur); th.fav = GalleryFav.has(this, it.key)
            th.selecting = selecting; th.selected = selected.contains(it.key)
            th.tag = it.key
            val w = 360
            val have = Thumbs.peek(Thumbs.key(it.video, it.id, w, w))
            th.bmp = have
            if (have == null) Thumbs.load(this, it.uri, it.id, it.video, w, w) { b -> if (th.tag == it.key) th.bmp = b }
            th.setOnClickListener {
                if (selecting) toggleSel(items[i]) else open(items[i])
            }
            th.setOnLongClickListener {
                if (!selecting) startSelect()
                toggleSel(items[i]); true
            }
        }
        return row
    }

    private fun albumsView(albums: List<Album>, cv: View?): View {
        val w = (resources.displayMetrics.widthPixels - k.dp(16 + 16)) / 2
        val row = (cv as? LinearLayout) ?: LinearLayout(this).apply {
            for (i in 0 until 2) addView(AlbumCard(context, k), LinearLayout.LayoutParams(w, (w * 1.1f).toInt()).apply { setMargins(k.dp(4), k.dp(4), k.dp(4), k.dp(4)) })
        }
        for (i in 0 until 2) {
            val c = row.getChildAt(i) as AlbumCard
            val a = albums.getOrNull(i)
            if (a == null) { c.visibility = View.INVISIBLE; c.setOnClickListener(null); continue }
            c.visibility = View.VISIBLE
            c.name = a.name; c.count = "${a.count} items"; c.tag = a.id
            val have = Thumbs.peek(Thumbs.key(a.cover.video, a.cover.id, 360, 360))
            c.bmp = have
            if (have == null) Thumbs.load(this, a.cover.uri, a.cover.id, a.cover.video, 360, 360) { b -> if (c.tag == a.id) c.bmp = b }
            c.setOnClickListener { album = a; rebuild() }
        }
        return row
    }

    // ------------------------------ kholna / chunna ------------------------------
    private fun open(it: GItem) {
        GalleryState.items = shown
        startActivity(Intent(this, GalleryViewerActivity::class.java).putExtra("index", shown.indexOf(it).coerceAtLeast(0)))
    }

    private fun startSelect() {
        selecting = true; headBar.visibility = View.GONE; selBar.visibility = View.VISIBLE
        selCount.text = "${selected.size} chuni"
        adapter.notifyDataSetChanged()
    }

    private fun exitSelect() {
        selecting = false; selected.clear(); selBar.visibility = View.GONE; headBar.visibility = View.VISIBLE
        adapter.notifyDataSetChanged()
    }

    private fun toggleSel(it: GItem) {
        if (!selected.add(it.key)) selected.remove(it.key)
        selCount.text = "${selected.size} chuni"
        adapter.notifyDataSetChanged()
    }

    private fun picked(): List<GItem> = shown.filter { selected.contains(it.key) }

    private fun favSelected() {
        val list = picked(); if (list.isEmpty()) return
        val allFav = list.all { GalleryFav.has(this, it.key) }
        GalleryFav.setAll(this, list.map { it.key }, !allFav)
        Toast.makeText(this, if (allFav) "Favourite se hata diya" else "Favourite mein jod diya", Toast.LENGTH_SHORT).show()
        exitSelect(); rebuild()
    }

    private fun shareSelected() {
        val list = picked(); if (list.isEmpty()) return
        val it = if (list.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, list[0].uri)
        else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(list.map { x -> x.uri }))
        it.type = if (list.all { x -> x.video }) "video/*" else if (list.none { x -> x.video }) "image/*" else "*/*"
        it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(it, "Share karo"))
    }

    private fun deleteSelected() {
        val list = picked(); if (list.isEmpty()) return
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("${list.size} item hatani hain?").setMessage("Ye phone se hamesha ke liye hat jayengi.")
            .setPositiveButton("Hatao") { _, _ -> doDelete(list.map { it.uri }) }.setNegativeButton("Nahi", null).show()
    }

    private fun doDelete(uris: List<Uri>) {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createDeleteRequest(contentResolver, uris)
                del.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } else {
                var n = 0
                for (u in uris) try { if (contentResolver.delete(u, null, null) > 0) n++ } catch (e: Exception) { }
                Toast.makeText(this, "$n item hat gayi", Toast.LENGTH_SHORT).show()
                exitSelect(); load()
            }
        } catch (e: Exception) { Toast.makeText(this, "Phone delete nahi karne de raha", Toast.LENGTH_LONG).show() }
    }
}
