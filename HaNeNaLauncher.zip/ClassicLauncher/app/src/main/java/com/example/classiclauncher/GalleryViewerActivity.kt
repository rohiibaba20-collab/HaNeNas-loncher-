package com.example.classiclauncher

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.*
import android.animation.ValueAnimator
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/** Pinch se zoom, double tap se zoom, kheench kar idhar-udhar, swipe se agli / pichli photo */
class ZoomImageView(ctx: Context) : ImageView(ctx) {
    var onTap: (() -> Unit)? = null
    var onSwipe: ((Int) -> Unit)? = null      // +1 agli, -1 pichli
    var onClose: (() -> Unit)? = null
    var onTouchStart: (() -> Unit)? = null

    private val m = Matrix()
    private val v = FloatArray(9)
    private val r = RectF()
    private var base = 1f

    init { scaleType = ScaleType.MATRIX }

    private fun cur(): Float { m.getValues(v); return v[Matrix.MSCALE_X] }
    private fun zoomed() = cur() > base * 1.05f

    fun fit() {
        val d = drawable ?: return
        val dw = d.intrinsicWidth.toFloat(); val dh = d.intrinsicHeight.toFloat()
        if (dw <= 0f || dh <= 0f || width == 0) return
        base = minOf(width / dw, height / dh)
        m.reset(); m.postScale(base, base)
        m.postTranslate((width - dw * base) / 2f, (height - dh * base) / 2f)
        imageMatrix = m
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); fit() }

    override fun setImageBitmap(bm: Bitmap?) { super.setImageBitmap(bm); fit() }

    private fun fix() {
        val d = drawable ?: return
        r.set(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        m.mapRect(r)
        var dx = 0f; var dy = 0f
        if (r.width() <= width) dx = (width - r.width()) / 2f - r.left
        else { if (r.left > 0f) dx = -r.left else if (r.right < width) dx = width - r.right }
        if (r.height() <= height) dy = (height - r.height()) / 2f - r.top
        else { if (r.top > 0f) dy = -r.top else if (r.bottom < height) dy = height - r.bottom }
        m.postTranslate(dx, dy)
        imageMatrix = m
    }

    private fun zoomBy(f: Float, fx: Float, fy: Float) {
        val target = (cur() * f).coerceIn(base * 0.9f, base * 7f)
        val k = target / cur()
        m.postScale(k, k, fx, fy)
        fix()
    }

    private val sg = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean { zoomBy(d.scaleFactor, d.focusX, d.focusY); return true }
    })

    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onTap?.invoke(); return true }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            val to = if (zoomed()) base else base * 2.6f
            val from = cur()
            ValueAnimator.ofFloat(from, to).apply {
                duration = 220L
                addUpdateListener { val s = it.animatedValue as Float; zoomBy(s / cur(), e.x, e.y) }
                start()
            }
            return true
        }
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (zoomed()) { m.postTranslate(-dx, -dy); fix() }
            return true
        }
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (zoomed() || e1 == null) return true
            val dx = e2.x - e1.x; val dy = e2.y - e1.y
            if (abs(dx) > abs(dy) && abs(dx) > 110f && abs(vx) > 500f) onSwipe?.invoke(if (dx < 0) 1 else -1)
            else if (dy > 160f && abs(dy) > abs(dx) && vy > 700f) onClose?.invoke()
            return true
        }
    })

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) onTouchStart?.invoke()
        sg.onTouchEvent(e)
        if (!sg.isInProgress) gd.onTouchEvent(e)
        return true
    }
}

/** HaNeNa Gallery ka bada viewer: zoom, swipe, slideshow, favourite, share, delete, details */
class GalleryViewerActivity : AppCompatActivity() {

    private lateinit var k: Skin
    private lateinit var iv: ZoomImageView
    private lateinit var top: LinearLayout
    private lateinit var bottom: LinearLayout
    private lateinit var nameTv: TextView
    private lateinit var dateTv: TextView
    private lateinit var heart: IconBtn
    private lateinit var slideBtn: IconBtn
    private lateinit var playBig: IconBtn
    private lateinit var spinner: ProgressBar
    private var items: List<GItem> = emptyList()
    private var index = 0
    private var barsOn = true
    private var slide = false
    private var busy = false
    private val hnd = Handler(Looper.getMainLooper())
    private val fmtDate = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
    private val slideRun = object : Runnable { override fun run() { if (slide) { go(1, true); hnd.postDelayed(this, 3600L) } } }

    private val del = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == RESULT_OK) removeCurrent()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        k = Skin(this)
        items = GalleryState.items
        if (items.isEmpty()) { finish(); return }
        index = intent.getIntExtra("index", 0).coerceIn(0, items.size - 1)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = Color.TRANSPARENT

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        iv = ZoomImageView(this)
        root.addView(iv, FrameLayout.LayoutParams(-1, -1))
        iv.onTap = { toggleBars() }
        iv.onSwipe = { d -> stopSlide(); go(d, false) }
        iv.onClose = { finish() }
        iv.onTouchStart = { if (slide) stopSlide() }

        spinner = ProgressBar(this).apply { visibility = View.GONE; indeterminateTintList = android.content.res.ColorStateList.valueOf(k.accent) }
        root.addView(spinner, FrameLayout.LayoutParams(k.dp(40), k.dp(40), Gravity.CENTER))

        playBig = IconBtn(this, IconBtn.PLAY).apply {
            color = k.accent; ring = true; visibility = View.GONE
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(130, 0, 0, 0)) }
            setOnClickListener { playVideo() }
        }
        root.addView(playBig, FrameLayout.LayoutParams(k.dp(84), k.dp(84), Gravity.CENTER))

        top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(6), k.dp(36), k.dp(10), k.dp(28))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(190, 0, 0, 0), 0))
        }
        top.addView(IconBtn(this, IconBtn.BACK).apply { color = Color.WHITE; setOnClickListener { finish() } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        val tcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        nameTv = k.tv("", 15f, Color.WHITE).apply { setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.END }
        dateTv = k.tv("", 11f, k.accent)
        tcol.addView(nameTv); tcol.addView(dateTv)
        top.addView(tcol, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(6) })
        top.addView(IconBtn(this, IconBtn.INFO).apply { color = Color.WHITE; setOnClickListener { info() } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        root.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        bottom = LinearLayout(this).apply {
            gravity = Gravity.CENTER; setPadding(k.dp(16), k.dp(30), k.dp(16), k.dp(26))
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.argb(200, 0, 0, 0), 0))
        }
        fun btn(b: IconBtn, tap: () -> Unit): IconBtn { b.setOnClickListener { tap() }; return b }
        heart = IconBtn(this, IconBtn.HEART).apply { color = Color.WHITE }
        slideBtn = IconBtn(this, IconBtn.PLAYSLIDE).apply { color = Color.WHITE }
        for (b in listOf(
            btn(IconBtn(this, IconBtn.SHARE).apply { color = Color.WHITE }) { share() },
            btn(heart) { toggleFav() },
            btn(slideBtn) { toggleSlide() },
            btn(IconBtn(this, IconBtn.TRASH).apply { color = k.red }) { delete() }
        )) bottom.addView(b, LinearLayout.LayoutParams(k.dp(56), k.dp(56)).apply { setMargins(k.dp(10), 0, k.dp(10), 0) })
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.navigationBars())
        show(index)
    }

    override fun onDestroy() { slide = false; hnd.removeCallbacksAndMessages(null); super.onDestroy() }

    private fun toggleBars() {
        barsOn = !barsOn
        for (b in listOf<View>(top, bottom)) b.animate().alpha(if (barsOn) 1f else 0f).setDuration(200L).withEndAction { b.visibility = if (barsOn) View.VISIBLE else View.INVISIBLE }.start()
        if (barsOn) { top.visibility = View.VISIBLE; bottom.visibility = View.VISIBLE }
    }

    private fun cur(): GItem = items[index]

    private fun show(i: Int) {
        index = i
        val it = cur()
        nameTv.text = it.name; dateTv.text = fmtDate.format(Date(it.date)) + "   •   " + (i + 1) + " / " + items.size
        heart.filled = GalleryFav.has(this, it.key); heart.color = if (heart.filled) k.accent else Color.WHITE; heart.invalidate()
        playBig.visibility = if (it.video) View.VISIBLE else View.GONE
        // pehle chhota thumbnail, phir poori photo
        val tb = Thumbs.peek(Thumbs.key(it.video, it.id, 360, 360))
        iv.setImageBitmap(tb)
        if (tb == null) Thumbs.load(this, it.uri, it.id, it.video, 360, 360) { b -> if (index == i && iv.drawable == null && b != null) iv.setImageBitmap(b) }
        if (!it.video) {
            spinner.visibility = View.VISIBLE
            val dm = resources.displayMetrics
            val maxDim = maxOf(dm.widthPixels, dm.heightPixels) * 2
            Thread {
                var b: Bitmap? = null
                try {
                    val src = ImageDecoder.createSource(contentResolver, it.uri)
                    b = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                        val s = maxOf(1, maxOf(info.size.width, info.size.height) / maxDim)
                        dec.setTargetSampleSize(s)
                    }
                } catch (e: Exception) { }
                runOnUiThread { if (index == i) { spinner.visibility = View.GONE; if (b != null) iv.setImageBitmap(b) } }
            }.start()
        } else spinner.visibility = View.GONE
    }

    private fun go(d: Int, wrap: Boolean) {
        var n = index + d
        if (n < 0 || n >= items.size) {
            if (!wrap) return
            n = if (n < 0) items.size - 1 else 0
        }
        if (busy) return
        busy = true
        val w = iv.width.toFloat() * 0.25f * (if (d > 0) -1f else 1f)
        iv.animate().translationX(w).alpha(0f).setDuration(140L).withEndAction {
            show(n)
            iv.translationX = -w
            iv.animate().translationX(0f).alpha(1f).setDuration(180L).withEndAction { busy = false }.start()
        }.start()
    }

    private fun toggleSlide() { if (slide) stopSlide() else startSlide() }

    private fun startSlide() {
        slide = true; slideBtn.color = k.accent; slideBtn.invalidate()
        if (barsOn) toggleBars()
        hnd.removeCallbacks(slideRun); hnd.postDelayed(slideRun, 2500L)
        Toast.makeText(this, "Slideshow chalu. Chhoone par ruk jayega", Toast.LENGTH_SHORT).show()
    }

    private fun stopSlide() { slide = false; hnd.removeCallbacks(slideRun); slideBtn.color = Color.WHITE; slideBtn.invalidate() }

    private fun playVideo() {
        val it = cur()
        startActivity(Intent(this, VideoPlayerActivity::class.java)
            .putExtra(VideoPlayerActivity.X_URIS, arrayOf(it.uri.toString()))
            .putExtra(VideoPlayerActivity.X_TITLES, arrayOf(it.name.substringBeforeLast('.')))
            .putExtra(VideoPlayerActivity.X_INDEX, 0))
    }

    private fun toggleFav() {
        val on = GalleryFav.toggle(this, cur().key)
        heart.filled = on; heart.color = if (on) k.accent else Color.WHITE; heart.invalidate()
    }

    private fun share() {
        val it = cur()
        val s = Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, it.uri)
        s.type = if (it.video) "video/*" else "image/*"; s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(s, "Share karo"))
    }

    private fun delete() {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Ye hatani hai?").setMessage("Phone se hamesha ke liye hat jayegi.")
            .setPositiveButton("Hatao") { _, _ ->
                try {
                    if (Build.VERSION.SDK_INT >= 30) {
                        val pi = MediaStore.createDeleteRequest(contentResolver, listOf(cur().uri))
                        del.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                    } else { if (contentResolver.delete(cur().uri, null, null) > 0) removeCurrent() }
                } catch (e: Exception) { Toast.makeText(this, "Phone delete nahi karne de raha", Toast.LENGTH_LONG).show() }
            }.setNegativeButton("Nahi", null).show()
    }

    private fun removeCurrent() {
        val list = items.toMutableList(); list.removeAt(index)
        items = list; GalleryState.items = list
        if (list.isEmpty()) { finish(); return }
        show(index.coerceAtMost(list.size - 1))
    }

    private fun info() {
        val it = cur()
        val sz = if (it.size > 1048576) "%.1f MB".format(it.size / 1048576f) else "%d KB".format(it.size / 1024)
        val txt = "Naam: ${it.name}\nTareekh: ${fmtDate.format(Date(it.date))}\nSize: $sz\n" +
            (if (it.w > 0) "Resolution: ${it.w} x ${it.h}\n" else "") + "Album: ${it.bucket}\nQism: " + (if (it.video) "Video" else "Photo")
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert).setTitle("Details").setMessage(txt)
            .setPositiveButton("Theek hai", null).show()
    }
}
