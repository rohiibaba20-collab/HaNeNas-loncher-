package com.example.classiclauncher

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.View
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Animations: ripple / glow / sparks, edge glow, volume bar aur selfie-camera ring */
class GoldFxView(ctx: Context) : View(ctx) {

    private class Ring(val x: Float, val y: Float, val t0: Long, val maxR: Float, val w: Float)

    // ---- Settings se aane wali cheezein ----
    var color = Color.parseColor("#D4AF37")
    var style = 0                 // 0 Rings, 1 Glow burst, 2 Sparks
    var fxEnabled = true
    var camRing = true

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rings = mutableListOf<Ring>()

    private var edgeActive = false
    private var edgeFade = 0f
    private var side = 1
    private var edgeY = 0f

    private var volLevel = 0f
    private var volT0 = 0L

    private var camX = 0f
    private var camY = 0f
    private var camR = 0f
    private var camBoost = 0f

    private val volH get() = 110f * d
    private val volHalfW get() = 7f * d
    private val volCenterY get() = height * 0.32f

    private fun gold(a: Float) =
        Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), Color.red(color), Color.green(color), Color.blue(color))

    fun setCamera(x: Float, y: Float, r: Float) { camX = x; camY = y; camR = r; postInvalidateOnAnimation() }

    fun pulse(x: Float, y: Float, maxR: Float = 170f, w: Float = 3f) {
        if (!fxEnabled) return
        rings.add(Ring(x, y, SystemClock.uptimeMillis(), maxR * d, w * d))
        camBoost = 1f
        postInvalidateOnAnimation()
    }

    fun setEdge(s: Int, y: Float) {
        if (!fxEnabled) return
        side = s; edgeY = y; edgeActive = true; postInvalidateOnAnimation()
    }

    fun releaseEdge() { edgeActive = false; postInvalidateOnAnimation() }

    fun showVolume(level: Float) {
        if (!fxEnabled) return
        volLevel = level.coerceIn(0f, 1f)
        volT0 = SystemClock.uptimeMillis()
        val top = volCenterY - volH / 2f
        pulse(width - 26 * d, top + volH * (1f - volLevel), 60f, 4f)
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) postInvalidateOnAnimation()
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        var again = false

        // ---- pulses ----
        val it = rings.iterator()
        while (it.hasNext()) {
            val r = it.next()
            val t = (now - r.t0) / 900f
            if (t >= 1f) { it.remove(); continue }
            again = true
            val e = 1f - (1f - t) * (1f - t)
            when (style) {
                1 -> {
                    val rad = e * r.maxR * 0.9f + 1f
                    p.style = Paint.Style.FILL
                    p.shader = RadialGradient(r.x, r.y, rad,
                        intArrayOf(gold(0f), gold(0f), gold((1f - t) * 0.55f)),
                        floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
                    c.drawCircle(r.x, r.y, rad, p)
                    p.shader = null
                }
                2 -> {
                    p.shader = null; p.style = Paint.Style.FILL; p.color = gold(1f - t)
                    for (j in 0 until 10) {
                        val ang = Math.toRadians(j * 36.0 + 12.0)
                        c.drawCircle(r.x + cos(ang).toFloat() * e * r.maxR,
                            r.y + sin(ang).toFloat() * e * r.maxR, r.w * (1f - t) * 0.9f + d, p)
                    }
                }
                else -> for (k in 0..1) {
                    val tt = t - k * 0.15f
                    if (tt <= 0f) continue
                    val ee = 1f - (1f - tt) * (1f - tt)
                    p.shader = null; p.style = Paint.Style.STROKE
                    p.strokeWidth = r.w * (1f - 0.65f * tt)
                    p.color = gold((1f - tt) * 0.8f)
                    c.drawCircle(r.x, r.y, ee * r.maxR, p)
                }
            }
        }

        // ---- edge glow ----
        edgeFade = if (edgeActive) min(1f, edgeFade + 0.15f) else max(0f, edgeFade - 0.05f)
        if (edgeFade > 0f) {
            again = true
            val ex = if (side == 1) width.toFloat() else 0f
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(ex, edgeY, 150f * d,
                intArrayOf(gold(0.55f * edgeFade), gold(0.18f * edgeFade), gold(0f)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(ex, edgeY, 150f * d, p)
            p.shader = LinearGradient(0f, edgeY - 200f * d, 0f, edgeY + 200f * d,
                intArrayOf(gold(0f), gold(edgeFade), gold(0f)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            val w = 3f * d
            val l = if (side == 1) width - w else 0f
            c.drawRect(l, edgeY - 200f * d, l + w, edgeY + 200f * d, p)
            p.shader = null
        }

        // ---- volume bar ----
        val vt = now - volT0
        if (volT0 > 0 && vt < 1800) {
            again = true
            val a = if (vt < 1400) 1f else 1f - (vt - 1400) / 400f
            val h = volH
            val cx = width - 26f * d
            val top = volCenterY - h / 2f
            val fillTop = top + h * (1f - volLevel)
            val hw = volHalfW
            p.shader = null; p.style = Paint.Style.FILL
            p.color = Color.argb((70 * a).toInt(), 255, 255, 255)
            c.drawRoundRect(cx - hw, top, cx + hw, top + h, hw, hw, p)
            p.color = gold(a)
            c.drawRoundRect(cx - hw, fillTop, cx + hw, top + h, hw, hw, p)
            p.shader = RadialGradient(cx, fillTop, 18f * d,
                intArrayOf(gold(0.6f * a), gold(0f)), null, Shader.TileMode.CLAMP)
            c.drawCircle(cx, fillTop, 18f * d, p)
            p.shader = null
        }

        // ---- selfie camera ring ----
        val cx = if (camR > 0f) camX else width / 2f
        val cy = if (camR > 0f) camY else 22f * d
        val r = (if (camR > 0f) camR else 9f * d) + 5f * d
        if (camRing) {
            camBoost = max(0f, camBoost - 0.015f)
            val a = min(1f, 0.45f + 0.15f * sin(now / 600.0).toFloat() + camBoost * 0.5f)
            p.shader = RadialGradient(cx, cy, r + 16f * d,
                intArrayOf(gold(0.30f * a), gold(0f)), null, Shader.TileMode.CLAMP)
            p.style = Paint.Style.FILL
            c.drawCircle(cx, cy, r + 16f * d, p)
            p.shader = null
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = 1.4f * d
            p.color = gold(a * 0.6f)
            c.drawCircle(cx, cy, r, p)
            p.strokeWidth = 2.6f * d
            p.color = gold(min(1f, a + 0.3f))
            c.drawArc(cx - r, cy - r, cx + r, cy + r, (now / 5L % 360L).toFloat(), 80f + camBoost * 120f, false, p)
            p.strokeCap = Paint.Cap.BUTT
        }

        if (again) postInvalidateOnAnimation()
        else if (camRing) {
            val m = r + 18f * d
            postInvalidateOnAnimation((cx - m).toInt(), (cy - m).toInt(), (cx + m).toInt(), (cy + m).toInt())
        }
    }
}
