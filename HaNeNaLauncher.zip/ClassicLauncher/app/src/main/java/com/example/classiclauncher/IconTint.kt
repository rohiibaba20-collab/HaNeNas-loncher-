package com.example.classiclauncher

import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.drawable.Drawable

/**
 * Icon ko ek hi rang (duotone) mein badalta hai.
 * Pehle andhere icons lagbhag kale ho jate the aur halke icons chamakte the, isliye har app ka rang alag lagta tha.
 * Ab sabse andhera hissa bhi rang ka ~22% rehta hai aur sabse halka hissa poora rang, to sab icons barabar dikhte hain.
 */
object IconTint {
    fun apply(d: Drawable, col: Int): Drawable {
        val r = Color.red(col) / 255f
        val g = Color.green(col) / 255f
        val b = Color.blue(col) / 255f
        val cm = ColorMatrix().apply { setSaturation(0f) }
        cm.postConcat(ColorMatrix(floatArrayOf(
            0.78f * r, 0f, 0f, 0f, 57f * r,
            0f, 0.78f * g, 0f, 0f, 57f * g,
            0f, 0f, 0.78f * b, 0f, 57f * b,
            0f, 0f, 0f, 1f, 0f)))
        // asli icon kabhi nahi dikhna chahiye: constantState na ho to usi drawable par filter lagao
        val copy = d.constantState?.newDrawable()?.mutate() ?: d.mutate()
        copy.colorFilter = ColorMatrixColorFilter(cm)
        return copy
    }
}
