package com.example.classiclauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.view.View
import androidx.core.graphics.ColorUtils

/** HaNeNa ke apne apps: Home / Saari apps mein dikhte hain aur favourite bhi ban sakte hain */
object Internal {
    class App(val pkg: String, val label: String, val shortLabel: String, val cls: Class<*>, val glyph: Int)

    val apps: List<App> = listOf(
        App(Prefs.MUSIC_PKG, "HaNeNa Music", "Music", MusicActivity::class.java, IconBtn.NOTE),
        App("hanena.video", "HaNeNa Video", "Video", VideoActivity::class.java, IconBtn.VIDEO),
        App("hanena.dialer", "HaNeNa Phone", "Phone", DialerActivity::class.java, IconBtn.CALL),
        App("hanena.sms", "HaNeNa Messages", "Messages", SmsActivity::class.java, IconBtn.MSG),
        App("hanena.gallery", "HaNeNa Gallery", "Gallery", GalleryActivity::class.java, IconBtn.PHOTO)
    )

    fun byPkg(p: String): App? = apps.firstOrNull { it.pkg == p }
    fun byClass(name: String): App? = apps.firstOrNull { it.cls.name == name }
    fun isInternal(p: String): Boolean = byPkg(p) != null

    /** Har app ka apna alag icon: gol kone wala gradient dabba aur uske beech nishan */
    fun icon(ctx: Context, app: App, accent: Int, px: Int = 176): Drawable {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val base = ColorUtils.blendARGB(Color.BLACK, accent, 0.34f)
        p.shader = LinearGradient(0f, 0f, px.toFloat(), px.toFloat(),
            ColorUtils.blendARGB(base, Color.WHITE, 0.16f), ColorUtils.blendARGB(base, Color.BLACK, 0.25f), Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(0f, 0f, px.toFloat(), px.toFloat()), px * 0.27f, px * 0.27f, p)
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = px * 0.02f; p.color = ColorUtils.setAlphaComponent(accent, 150)
        c.drawRoundRect(RectF(px * 0.02f, px * 0.02f, px * 0.98f, px * 0.98f), px * 0.26f, px * 0.26f, p)
        val g = IconBtn(ctx, app.glyph).apply { color = ColorUtils.blendARGB(accent, Color.WHITE, 0.55f) }
        g.measure(View.MeasureSpec.makeMeasureSpec(px, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(px, View.MeasureSpec.EXACTLY))
        g.layout(0, 0, px, px)
        g.draw(c)
        return BitmapDrawable(ctx.resources, bmp)
    }
}
