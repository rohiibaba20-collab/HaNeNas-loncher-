package com.example.classiclauncher

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.AudioManager
import android.media.ImageReader
import android.media.ToneGenerator
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Surface
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Galat finger / galat PIN par selfie camera se chupke photo leta hai, app ke andar save karta hai
 * (sirf HaNeNa ke paas, gallery mein nahi dikhti) aur notification bhejta hai.
 */
object IntruderCam {

    private val main = Handler(Looper.getMainLooper())
    private var busy = false

    fun enabled(c: Context): Boolean =
        Prefs.get(c, Prefs.INTRUDER) == 1 &&
            c.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    fun dir(c: Context): File = File(c.filesDir, "intruders").apply { mkdirs() }

    fun photos(c: Context): List<File> =
        (dir(c).listFiles { f -> f.extension == "jpg" } ?: emptyArray()).sortedByDescending { it.lastModified() }

    fun reasonOf(f: File): String = when {
        f.name.contains("_finger") -> "Galat fingerprint"
        f.name.contains("_pin") -> "Galat app lock PIN"
        else -> "Lock screen"
    }

    /** Photo le kar file deta hai (done(null) agar na le saka). Hamesha main thread par done aata hai. */
    @SuppressLint("MissingPermission")
    fun snap(ctx: Context, reason: String, done: (File?) -> Unit) {
        val app = ctx.applicationContext
        if (!enabled(app) || busy) { done(null); return }
        busy = true
        try {
            val cm = app.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
            }
            if (id == null) { busy = false; done(null); return }
            val ch = cm.getCameraCharacteristics(id)
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(ImageFormat.JPEG)
            if (sizes == null || sizes.isEmpty()) { busy = false; done(null); return }
            val size = sizes.filter { it.width <= 1280 }.maxByOrNull { it.width * it.height }
                ?: sizes.minByOrNull { it.width * it.height }!!
            val orient = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 270

            val thread = HandlerThread("hanena-intruder").apply { start() }
            val h = Handler(thread.looper)
            val reader = ImageReader.newInstance(size.width, size.height, ImageFormat.JPEG, 1)
            val tex = SurfaceTexture(11).apply { setDefaultBufferSize(640, 480) }
            val dummy = Surface(tex)
            var cam: CameraDevice? = null
            var finished = false

            fun finish(f: File?) {
                if (finished) return
                finished = true
                try { cam?.close() } catch (e: Exception) { }
                try { reader.close() } catch (e: Exception) { }
                try { dummy.release(); tex.release() } catch (e: Exception) { }
                thread.quitSafely()
                busy = false
                main.post { done(f) }
            }

            reader.setOnImageAvailableListener({ r ->
                val img = try { r.acquireLatestImage() } catch (e: Exception) { null }
                if (img != null) {
                    var out: File? = null
                    try {
                        val buf = img.planes[0].buffer
                        val bytes = ByteArray(buf.remaining()); buf.get(bytes)
                        val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + "_" + reason + ".jpg"
                        out = File(dir(app), name).also { it.writeBytes(bytes) }
                    } catch (e: Exception) { } finally { img.close() }
                    finish(out)
                }
            }, h)

            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(device: CameraDevice) {
                    cam = device
                    try {
                        device.createCaptureSession(listOf(dummy, reader.surface), object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                try {
                                    // thodi der preview chalao taake roshni / exposure set ho jaye, phir photo
                                    val pr = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                                    pr.addTarget(dummy)
                                    s.setRepeatingRequest(pr.build(), null, h)
                                    h.postDelayed({
                                        try {
                                            val cr = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                                            cr.addTarget(reader.surface)
                                            cr.set(CaptureRequest.JPEG_ORIENTATION, orient)
                                            s.capture(cr.build(), null, h)
                                        } catch (e: Exception) { finish(null) }
                                    }, 700L)
                                    h.postDelayed({ finish(null) }, 5000L)
                                } catch (e: Exception) { finish(null) }
                            }
                            override fun onConfigureFailed(s: CameraCaptureSession) { finish(null) }
                        }, h)
                    } catch (e: Exception) { finish(null) }
                }
                override fun onDisconnected(device: CameraDevice) { finish(null) }
                override fun onError(device: CameraDevice, error: Int) { finish(null) }
            }, h)
        } catch (e: CameraAccessException) { busy = false; done(null) }
        catch (e: Exception) { busy = false; done(null) }
    }

    // ------------------------------ alert: vibration + awaaz ------------------------------
    fun buzz(c: Context) {
        try {
            val v = c.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 140, 90, 140, 90, 320), -1))
        } catch (e: Exception) { }
        if (Prefs.get(c, Prefs.ALERTSND) == 1) {
            try {
                val tg = ToneGenerator(AudioManager.STREAM_ALARM, 70)
                tg.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 450)
                main.postDelayed({ try { tg.release() } catch (e: Exception) { } }, 900L)
            } catch (e: Exception) { }
        }
    }

    // ------------------------------ notification ------------------------------
    fun notifyAlert(c: Context, file: File?, title: String) {
        try {
            val app = c.applicationContext
            val nm = app.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("security", "HaNeNa Security", NotificationManager.IMPORTANCE_HIGH))
            val open = PendingIntent.getActivity(app, 21, Intent(app, SecurityActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val b = Notification.Builder(app, "security")
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle(title)
                .setContentText(if (file != null) "Selfie photo le li gayi. Dekhne ke liye dabao." else "Kisi ne lock screen kholne ki koshish ki.")
                .setContentIntent(open).setAutoCancel(true)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
            if (file != null) {
                val o = BitmapFactory.Options().apply { inSampleSize = 2 }
                BitmapFactory.decodeFile(file.absolutePath, o)?.let {
                    b.setLargeIcon(it)
                    b.setStyle(Notification.BigPictureStyle().bigPicture(it))
                }
            }
            nm.notify(31, b.build())
        } catch (e: Exception) { }
    }
}
