package com.example.classiclauncher

import android.app.KeyguardManager
import android.content.pm.PackageManager
import android.hardware.fingerprint.FingerprintManager
import android.os.CancellationSignal
import android.view.HapticFeedbackConstants
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat

/**
 * HaNeNa lock screen (fingerprint animation wali).
 * Neeche ka face-scan button hata diya gaya. Side ke fingerprint sensor par finger lagane par screen par animation chalti hai;
 * galat finger par alert + selfie (agar Settings, Security mein on ho). Upar swipe karne se phone ki apni lock screen khulti hai.
 *
 * Purani jankari: Asli suraksha Android ki apni lock hi rehti hai:
 * chehra/fingerprint phone ke biometric se check hota hai, aur PIN/pattern ho to
 * system ki lock screen hi khulti hai.
 */
@Suppress("DEPRECATION")
class LockActivity : AppCompatActivity() {

    private lateinit var fx: FingerprintFxView
    private lateinit var hint: TextView
    private var fpCancel: CancellationSignal? = null
    private var wrong = 0
    private var done = false
    private val handler = Handler(Looper.getMainLooper())
    private var prompt: BiometricPrompt? = null
    private var busy = false
    private var downY = 0f
    private var musicCard: MusicPanel? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // NOTE: turnScreenOn jaan boojh kar nahi lagaya, warna screen khud-ba-khud jag jati
        if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {}
        })
        buildUi()
    }

    private fun buildUi() {
        val accent = Prefs.get(this, Prefs.ACCENT)
        val textC = Prefs.get(this, Prefs.TEXT)
        val fs = Prefs.get(this, Prefs.SCALE) / 100f
        val tf = Prefs.typeface(this, Prefs.get(this, Prefs.FONT))
        val script = Prefs.typeface(this, 0)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val wall = Prefs.wallFile(this)
        if (wall.exists()) {
            val bmp = try {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(wall)) { dec, info, _ ->
                    var s = 1
                    while (info.size.width / (s * 2) >= 1080) s *= 2
                    dec.setTargetSampleSize(s); dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                }
            } catch (e: Exception) { null }
            if (bmp != null) root.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(bmp) }, -1, -1)
        }
        root.addView(View(this).apply {
            setBackgroundColor(Color.argb(Prefs.get(this@LockActivity, Prefs.DIM) * 255 / 100 + 40, 0, 0, 0)
                .let { if (Color.alpha(it) > 230) Color.argb(230, 0, 0, 0) else it })
        }, -1, -1)
        root.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.argb(150, 0, 0, 0)))
        }, -1, -1)

        fx = FingerprintFxView(this).apply {
            this.accent = Prefs.colorOr(this@LockActivity, Prefs.RINGC)
            this.tf = tf
            right = Prefs.get(this@LockActivity, Prefs.FPSIDE) == 0
            yFrac = Prefs.get(this@LockActivity, Prefs.FPY) / 100f
            style = Prefs.get(this@LockActivity, Prefs.FPSTYLE)
            idleGlow = Prefs.get(this@LockActivity, Prefs.FPIDLE) == 1
        }
        hint = TextView(this).apply {
            typeface = script; textSize = 21f * fs; setTextColor(textC); gravity = Gravity.CENTER
            text = idleText()
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(80), dp(20), dp(48))
        }
        col.addView(ClockFactory.build(this, tf, accent, textC, fs, Prefs.get(this, Prefs.CLOCK), Prefs.get(this, Prefs.CLOCKSZ) / 100f))
        col.addView(NameView(this).also {
            it.name = Prefs.name(this); it.nameStyle = Prefs.get(this, Prefs.NSTYLE)
            it.accent = accent; it.textColor = textC; it.scale = fs * 0.6f * Prefs.get(this, Prefs.NAMESZ) / 100f
            it.scriptTf = script; it.tf = tf
        })
        col.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        // lock screen par music player (gaana ho tabhi dikhta hai)
        if (Prefs.get(this, Prefs.MUSLOCK) == 1) {
            val mix = Prefs.get(this, Prefs.MIX) == 1
            musicCard = MusicPanel(this, Prefs.get(this, Prefs.MUSTYLE).coerceIn(0, Opts.musicStyles.size - 1), true,
                accent, if (mix) Prefs.get(this, Prefs.ACCENT2) else 0, textC, tf, script).also {
                it.visibility = if (MusicEngine.current != null) View.VISIBLE else View.GONE
                col.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
            }
        }
        col.addView(hint, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
        root.addView(col, -1, -1)
        root.addView(fx, -1, -1)          // animation sabse upar (touch nahi rokti)
        setContentView(root)

        // upar swipe karne se bhi khulta hai
        root.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> downY = e.y
                MotionEvent.ACTION_UP -> if (downY - e.y > dp(90)) dismissKeyguard()
            }
            true
        }
    }

    private fun fpAvailable(): Boolean {
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)) return false
        val fm = getSystemService(FingerprintManager::class.java) ?: return false
        return try { fm.isHardwareDetected && fm.hasEnrolledFingerprints() } catch (e: Exception) { false }
    }

    private fun idleText() = if (fpAvailable()) "Fingerprint lagao ya upar swipe karo" else "Upar swipe karo"

    override fun onResume() {
        super.onResume()
        busy = false; done = false; wrong = 0
        fx.reset(); hint.text = idleText()
        MusicEngine.listen(this) {
            musicCard?.visibility = if (MusicEngine.current != null) View.VISIBLE else View.GONE
        }
        musicCard?.visibility = if (MusicEngine.current != null) View.VISIBLE else View.GONE
        if (fpAvailable()) startFp()
        else if (Prefs.get(this, Prefs.AUTOSCAN) == 1) handler.postDelayed({ startUnlock() }, 700)
    }

    override fun onStop() {
        // screen band hone ya app badalne par sab roko, kuch peeche chalta nahi rahe
        handler.removeCallbacksAndMessages(null)
        MusicEngine.unlisten(this)
        stopFp()
        prompt?.cancelAuthentication()
        busy = false
        fx.reset()
        super.onStop()
    }

    // ------------------------------ fingerprint ------------------------------
    private fun stopFp() { try { fpCancel?.cancel() } catch (e: Exception) { }; fpCancel = null }

    private fun startFp() {
        stopFp()
        val fm = getSystemService(FingerprintManager::class.java) ?: return
        val cs = CancellationSignal()
        fpCancel = cs
        try {
            fm.authenticate(null, cs, 0, object : FingerprintManager.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: FingerprintManager.AuthenticationResult?) { fpOk() }
                override fun onAuthenticationFailed() { fpWrong() }
                override fun onAuthenticationHelp(helpCode: Int, helpString: CharSequence?) {
                    if (done) return
                    fx.scanning(); hint.text = helpString?.toString() ?: "Finger sahi se rakho"
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) { fpError(errorCode, errString?.toString()) }
            }, handler)
        } catch (e: Exception) { }
    }

    private fun fpOk() {
        if (done) return
        done = true
        hint.text = "Khul gaya"
        fx.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        fx.success { dismissKeyguard() }
    }

    private fun fpWrong() {
        if (done) return
        wrong++
        fx.fail()
        IntruderCam.buzz(this)
        hint.text = "Galat finger! Dobara koshish karo"
        selfie()
    }

    private fun fpError(code: Int, msg: String?) {
        if (done || code == FingerprintManager.FINGERPRINT_ERROR_CANCELED) return
        if (code == FingerprintManager.FINGERPRINT_ERROR_LOCKOUT || code == FingerprintManager.FINGERPRINT_ERROR_LOCKOUT_PERMANENT) {
            fx.fail(); IntruderCam.buzz(this)
            hint.text = "Bahut galat koshishen. Upar swipe karke PIN se kholo"
            wrong++; selfie()
        } else {
            hint.text = msg ?: idleText()
            handler.postDelayed({ if (!done) startFp() }, 900)     // time-out wagaira par dobara sunna shuru
        }
    }

    /** Galat finger par (agar Security mein on ho) selfie lo aur notification bhejo */
    private fun selfie() {
        if (wrong < Prefs.get(this, Prefs.INTRUDERN) || !IntruderCam.enabled(this)) return
        IntruderCam.snap(this, "finger") { f -> if (f != null) IntruderCam.notifyAlert(this, f, "Kisi ne galat fingerprint lagaya") }
    }

    // ------------------------------ face (jin phones mein fingerprint nahi) ------------------------------
    private fun startUnlock() {
        if (busy) return
        busy = true
        fx.scanning(); hint.text = "Scan ho raha hai..."
        val can = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        if (can == BiometricManager.BIOMETRIC_SUCCESS) {
            val info = BiometricPrompt.PromptInfo.Builder()
                .setTitle("HaNeNa Lock")
                .setSubtitle("Chehra ya fingerprint")
                .setNegativeButtonText("PIN / Swipe")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                .setConfirmationRequired(false)
                .build()
            prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = success()
                    override fun onAuthenticationFailed() { fpWrong() }
                    override fun onAuthenticationError(code: Int, msg: CharSequence) {
                        fx.reset(); busy = false; hint.text = idleText()
                        if (code == BiometricPrompt.ERROR_NEGATIVE_BUTTON) dismissKeyguard()
                    }
                })
            prompt?.authenticate(info)
        } else {
            // biometric nahi hai: system lock ke hawale
            handler.postDelayed({ success() }, 1200)
        }
    }

    private fun success() {
        if (done) return
        done = true
        hint.text = "Khul gaya"
        fx.success { dismissKeyguard() }
    }

    private fun dismissKeyguard() {
        val km = getSystemService(KeyguardManager::class.java)
        if (km == null || !km.isKeyguardLocked) { finishAndRemoveTask(); return }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { finishAndRemoveTask() }
            override fun onDismissCancelled() { busy = false; done = false; fx.reset(); hint.text = idleText(); if (fpAvailable()) startFp() }
            override fun onDismissError() { finishAndRemoveTask() }
        })
    }
}
