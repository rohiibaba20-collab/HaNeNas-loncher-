package com.example.classiclauncher

import android.app.KeyguardManager
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat

/**
 * HaNeNa lock screen. Asli suraksha Android ki apni lock hi rehti hai:
 * chehra/fingerprint phone ke biometric se check hota hai, aur PIN/pattern ho to
 * system ki lock screen hi khulti hai.
 */
class LockActivity : AppCompatActivity() {

    private lateinit var scan: FaceScanView
    private lateinit var hint: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var prompt: BiometricPrompt? = null
    private var busy = false
    private var downY = 0f

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // NOTE: turnScreenOn jaan boojh kar nahi lagaya, warna screen khud-ba-khud jag jati
        if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {}
        })
        buildUi()
    }

    private fun buildUi() {
        val accent = Prefs.get(this, Prefs.ACCENT)
        val textC = Prefs.get(this, Prefs.TEXT)
        val fs = Prefs.get(this, Prefs.SCALE) / 100f
        val tf = Prefs.typeface(this, Prefs.get(this, Prefs.FONT))
        val script = Prefs.typeface(this, 0)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val wall = Prefs.wallFile(this)
        if (wall.exists()) {
            val bmp = try {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(wall)) { dec, info, _ ->
                    var s = 1
                    while (info.size.width / (s * 2) >= 1080) s *= 2
                    dec.setTargetSampleSize(s); dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                }
            } catch (e: Exception) { null }
            if (bmp != null) root.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(bmp) }, -1, -1)
        }
        root.addView(View(this).apply {
            setBackgroundColor(Color.argb(Prefs.get(this@LockActivity, Prefs.DIM) * 255 / 100 + 40, 0, 0, 0)
                .let { if (Color.alpha(it) > 230) Color.argb(230, 0, 0, 0) else it })
        }, -1, -1)
        root.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.argb(150, 0, 0, 0)))
        }, -1, -1)

        scan = FaceScanView(this).also { it.accent = Prefs.colorOr(this, Prefs.RINGC); it.setOnClickListener { startUnlock() } }
        hint = TextView(this).apply {
            typeface = script; textSize = 21f * fs; setTextColor(textC); gravity = Gravity.CENTER
            text = idleText()
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(80), dp(20), dp(48))
        }
        col.addView(ClockFactory.build(this, tf, accent, textC, fs, Prefs.get(this, Prefs.CLOCK), Prefs.get(this, Prefs.CLOCKSZ) / 100f))
        col.addView(NameView(this).also {
            it.name = Prefs.name(this); it.nameStyle = Prefs.get(this, Prefs.NSTYLE)
            it.accent = accent; it.textColor = textC; it.scale = fs * 0.6f * Prefs.get(this, Prefs.NAMESZ) / 100f
            it.scriptTf = script; it.tf = tf
        })
        col.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        col.addView(scan)
        col.addView(hint, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(14) })
        root.addView(col, -1, -1)
        setContentView(root)

        // upar swipe karne se bhi khulta hai
        root.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> downY = e.y
                MotionEvent.ACTION_UP -> if (downY - e.y > dp(90)) startUnlock()
            }
            true
        }
    }

    private fun idleText() = "Chehra dikhao ya upar swipe karo"

    override fun onResume() {
        super.onResume()
        busy = false; scan.reset(); hint.text = idleText()
        if (Prefs.get(this, Prefs.AUTOSCAN) == 1) handler.postDelayed({ startUnlock() }, 700)
    }

    override fun onStop() {
        // screen band hone ya app badalne par sab roko, kuch peeche chalta nahi rahe
        handler.removeCallbacksAndMessages(null)
        prompt?.cancelAuthentication()
        busy = false
        scan.reset()
        super.onStop()
    }

    private fun startUnlock() {
        if (busy) return
        busy = true
        scan.startScan(); hint.text = "Scan ho raha hai..."
        val can = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK)
        if (can == BiometricManager.BIOMETRIC_SUCCESS) {
            val info = BiometricPrompt.PromptInfo.Builder()
                .setTitle("HaNeNa Lock")
                .setSubtitle("Chehra ya fingerprint")
                .setNegativeButtonText("PIN / Swipe")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                .setConfirmationRequired(false)
                .build()
            prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = success()
                    override fun onAuthenticationFailed() { scan.fail(); hint.text = "Dobara koshish karo" }
                    override fun onAuthenticationError(code: Int, msg: CharSequence) {
                        scan.reset(); busy = false; hint.text = idleText()
                        if (code == BiometricPrompt.ERROR_NEGATIVE_BUTTON) dismissKeyguard()
                    }
                })
            prompt?.authenticate(info)
        } else {
            // biometric nahi hai: animation dikha kar system lock ke hawale
            handler.postDelayed({ success() }, 1500)
        }
    }

    private fun success() {
        hint.text = "Khul gaya"
        scan.success { dismissKeyguard() }
    }

    private fun dismissKeyguard() {
        val km = getSystemService(KeyguardManager::class.java)
        if (km == null || !km.isKeyguardLocked) { finishAndRemoveTask(); return }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { finishAndRemoveTask() }
            override fun onDismissCancelled() { busy = false; scan.reset(); hint.text = idleText() }
            override fun onDismissError() { finishAndRemoveTask() }
        })
    }
}
