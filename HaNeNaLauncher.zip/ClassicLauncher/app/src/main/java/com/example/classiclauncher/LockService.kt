package com.example.classiclauncher

import android.app.*
import android.content.*
import android.media.AudioManager
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings

/** Bahut halki service: sirf "screen band hui" ka ishara sunti hai aur lock screen kholti hai */
class LockService : Service() {

    private var last = 0L
    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action != Intent.ACTION_SCREEN_OFF) return
            if (Prefs.get(c, Prefs.LOCK) != 1 || !Settings.canDrawOverlays(c)) return
            val now = SystemClock.elapsedRealtime()
            if (now - last < 2000) return          // baar-baar na khule
            last = now
            // call / alarm ke dauran lock screen na kholo
            val mode = (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).mode
            if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_RINGTONE ||
                mode == AudioManager.MODE_IN_COMMUNICATION) return
            try {
                c.startActivity(Intent(c, LockActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            } catch (e: Exception) { /* chup chaap chhod do */ }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("lock", "HaNeNa Lock", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "lock")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("HaNeNa Lock chalu hai")
            .setOngoing(true)
            .build()
        startForeground(1, n)
        registerReceiver(rx, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { try { unregisterReceiver(rx) } catch (e: Exception) {}; super.onDestroy() }
}
