package com.example.classiclauncher

import android.app.*
import android.content.*
import android.media.AudioManager
import android.os.BatteryManager
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings

/** Halki service: screen band hone aur charger lagne ka ishara sunti hai */
class LockService : Service() {

    companion object {
        /** Lock screen ya charging clock mein se koi bhi on ho to service chahiye */
        fun wanted(c: Context) = Prefs.get(c, Prefs.LOCK) == 1 || Prefs.get(c, Prefs.CHARGE) == 1
    }

    private var last = 0L

    private fun plugged(c: Context): Boolean =
        (c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0

    private fun openClock(c: Context, wake: Boolean) {
        try {
            c.startActivity(Intent(c, ChargeClockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("wake", wake))
        } catch (e: Exception) { }
    }

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val canDraw = Settings.canDrawOverlays(c)
            when (i.action) {
                Intent.ACTION_POWER_CONNECTED -> {
                    if (Prefs.get(c, Prefs.CHARGE) == 1 && canDraw)
                        openClock(c, Prefs.get(c, Prefs.CHWAKE) == 1)
                }
                Intent.ACTION_SCREEN_OFF -> {
                    if (!canDraw) return
                    val now = SystemClock.elapsedRealtime()
                    if (now - last < 2000) return          // baar-baar na khule
                    // call / alarm ke dauran kuch na kholo
                    val mode = (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).mode
                    if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_RINGTONE ||
                        mode == AudioManager.MODE_IN_COMMUNICATION) return
                    // charging + screen lock: clock dikhao (par power button se clock band hui ho to nahi)
                    if (Prefs.get(c, Prefs.CHARGE) == 1 && Prefs.get(c, Prefs.CHLOCK) == 1 && plugged(c)) {
                        if (ChargeClockActivity.visible) return
                        last = now; openClock(c, true); return
                    }
                    if (Prefs.get(c, Prefs.LOCK) != 1) return
                    last = now
                    try {
                        c.startActivity(Intent(c, LockActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                    } catch (e: Exception) { /* chup chaap chhod do */ }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("lock", "HaNeNa Lock", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "lock")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("HaNeNa chalu hai")
            .setOngoing(true)
            .build()
        startForeground(1, n)
        registerReceiver(rx, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_POWER_CONNECTED)
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { try { unregisterReceiver(rx) } catch (e: Exception) {}; super.onDestroy() }
}
