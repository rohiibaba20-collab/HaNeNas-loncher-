package com.example.classiclauncher

import android.animation.ValueAnimator
import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.graphics.ImageDecoder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private var fx: GoldFxView? = null
    private val rows = mutableListOf<View>()
    private var edgeActive = false
    private var waveAnim: ValueAnimator? = null
    private var lastRev = -1
    private var cam: FloatArray? = null
    private var wheel: WheelView? = null
    private var colRef: LinearLayout? = null
    private var navB = 0
    private var favSig = ""
    private var floatAnim: ValueAnimator? = null
    private var mixN = 6
    private var askedNotif = false
    private var clockHolder: FrameLayout? = null
    private var shownClock = -1
    private var chip: LinearLayout? = null
    private var chipText: TextView? = null
    private var chipBtn: IconBtn? = null
    private val tickH = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { autoTick(); tickH.postDelayed(this, 15000L) }
    }

    private var accent = 0
    private var textC = 0
    private var fs = 1f
    private var iconC = 0
    private var ringC = 0
    private var iconK = 1f
    private var clockK = 1f
    private var nameK = 1f
    private val locA = IntArray(2)
    private val locB = IntArray(2)
    private var waveAmp = 0f
    private var fxOn = true
    private lateinit var tf: Typeface

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let {
                if (!Prefs.saveWallpaper(this, it))
                    Toast.makeText(this, "Wallpaper set nahi hua", Toast.LENGTH_SHORT).show()
                refresh()
            }
        }

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val swipe by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null || Prefs.get(this@MainActivity, Prefs.SWIPEUP) != 1) return false
                val wheelLayout = Prefs.get(this@MainActivity, Prefs.LAYOUT) in 5..7
                val zone = resources.displayMetrics.heightPixels * (if (wheelLayout) 0.93f else 0.82f)
                if (e1.y > zone && vy < -1200 && abs(vx) < abs(vy)) { showAllApps(); return true }
                return false
            }
        })
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); clipChildren = false }
        setContentView(root)

        // selfie camera (punch-hole / ring) ki jagah system se pooch lo
        root.setOnApplyWindowInsetsListener { v, ins ->
            navB = ins.systemWindowInsetBottom
            colRef?.setPadding(dp(20), dp(70), dp(20), dp(16) + navB)
            if (Build.VERSION.SDK_INT >= 28) {
                ins.displayCutout?.boundingRects?.firstOrNull { it.top < dp(80) }?.let {
                    cam = floatArrayOf(it.exactCenterX(), it.exactCenterY(), maxOf(it.width(), it.height()) / 2f)
                    fx?.setCamera(cam!![0], cam!![1], cam!![2])
                }
            }
            v.onApplyWindowInsets(ins)
        }
        root.setOnLongClickListener { showMenu(); true }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* home screen: kuch nahi */ }
        })
    }

    override fun onPause() {
        floatAnim?.pause()
        tickH.removeCallbacks(tick)
        MusicEngine.unlisten(this)
        super.onPause()
    }

    override fun onResume() {
        super.onResume(); refresh()
        floatAnim?.let { if (it.isPaused) it.resume() }
        MusicEngine.listen(this) { updateChip() }
        updateChip()
        tickH.removeCallbacks(tick)
        if (Prefs.raw(this, Prefs.AUTO) == 1) tickH.postDelayed(tick, 15000L)
        WindowInsetsControllerCompat(window, root).let { c ->
            if (Prefs.get(this, Prefs.HIDESB) == 1) {
                c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                c.hide(WindowInsetsCompat.Type.statusBars())
            } else c.show(WindowInsetsCompat.Type.statusBars())
        }
        if (Build.VERSION.SDK_INT >= 33 && LockService.wanted(this) && !askedNotif &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askedNotif = true
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (LockService.wanted(this) && Settings.canDrawOverlays(this)) {
            try { androidx.core.content.ContextCompat.startForegroundService(this, Intent(this, LockService::class.java)) }
            catch (e: Exception) { }
        }
    }

    private fun refresh() {
        val r = Prefs.rev(this)
        val sig = favourites().joinToString("|") { it.first } + "#" + Auto.sig(this)   // app install/uninstall aur auto look badalna pakadne ke liye
        if (r != lastRev || sig != favSig) { lastRev = r; favSig = sig; buildUi() }
    }

    /** Auto mode: din / hafta badalne par look, aur clock ka style khud badlo */
    private fun autoTick() {
        if (Prefs.raw(this, Prefs.AUTO) != 1) return
        refresh()                                   // look badla ho to poora UI naya banta hai
        val ck = Prefs.get(this, Prefs.CLOCK)
        if (ck != shownClock) swapClock(ck)
    }

    private fun swapClock(ck: Int) {
        val h = clockHolder ?: return
        shownClock = ck
        h.animate().alpha(0f).setDuration(350L).withEndAction {
            h.removeAllViews()
            h.addView(buildClock(), FrameLayout.LayoutParams(-1, -2))
            h.animate().alpha(1f).setDuration(450L).start()
        }.start()
    }

    // ---------------- chhota music bar (gaana chalte waqt clock ke neeche) ----------------
    private fun buildChip(): View {
        val rc = ringC
        val note = IconBtn(this, IconBtn.NOTE).apply { color = accent }
        val txt = TextView(this).apply {
            typeface = tf; setTextColor(textC); textSize = 13f * fs
            setSingleLine(true); ellipsize = TextUtils.TruncateAt.MARQUEE; marqueeRepeatLimit = -1; isSelected = true
        }
        val btn = IconBtn(this, IconBtn.PLAY).apply { color = accent; setOnClickListener { MusicEngine.toggle() } }
        chipText = txt; chipBtn = btn
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(5), dp(6), dp(5))
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat(); setColor(Color.argb(110, 0, 0, 0))
                setStroke(dp(1), Color.argb(140, Color.red(rc), Color.green(rc), Color.blue(rc)))
            }
            addView(note, LinearLayout.LayoutParams(dp(18), dp(18)))
            addView(txt, LinearLayout.LayoutParams(dp(170), -2).apply { marginStart = dp(8) })
            addView(btn, LinearLayout.LayoutParams(dp(32), dp(32)))
            setOnClickListener { startActivity(Intent(this@MainActivity, MusicActivity::class.java)) }
            visibility = View.GONE
        }.also { chip = it }
    }

    private fun updateChip() {
        val c = chip ?: return
        val t = MusicEngine.current
        if (t == null || Prefs.get(this, Prefs.MUSCHIP) != 1) { c.visibility = View.GONE; return }
        c.visibility = View.VISIBLE
        chipText?.text = "${t.title}  •  ${t.artist}"
        chipBtn?.let { it.kind = if (MusicEngine.isPlaying) IconBtn.PAUSE else IconBtn.PLAY; it.invalidate() }
    }

    // ============================== UI ==============================
    private fun buildUi() {
        waveAnim?.cancel(); floatAnim?.cancel(); floatAnim = null; edgeActive = false
        root.removeAllViews(); rows.clear(); wheel = null; chip = null; chipText = null; chipBtn = null
        accent = Prefs.get(this, Prefs.ACCENT)
        textC = Prefs.get(this, Prefs.TEXT)
        iconC = Prefs.colorOr(this, Prefs.ICONC)
        ringC = Prefs.colorOr(this, Prefs.RINGC)
        iconK = Prefs.get(this, Prefs.ICONSZ) / 100f
        clockK = Prefs.get(this, Prefs.CLOCKSZ) / 100f
        nameK = Prefs.get(this, Prefs.NAMESZ) / 100f
        fs = Prefs.get(this, Prefs.SCALE) / 100f
        waveAmp = dp(Prefs.get(this, Prefs.WAVE)).toFloat()
        fxOn = Prefs.get(this, Prefs.FXON) == 1
        tf = Prefs.typeface(this, Prefs.get(this, Prefs.FONT))
        val layout = Prefs.get(this, Prefs.LAYOUT).let { if (it > 11) 6 else it }
        val wall = Prefs.wallFile(this)
        val hasWall = wall.exists()

        // wallpaper
        val bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        if (hasWall) Thread { decode(wall)?.let { b -> bg.post { bg.setImageBitmap(b) } } }.start()
        root.addView(bg, -1, -1)
        root.addView(View(this).apply {
            setBackgroundColor(Color.argb(Prefs.get(this@MainActivity, Prefs.DIM) * 255 / 100, 0, 0, 0))
        }, -1, -1)
        if (hasWall) root.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(170, 0, 0, 0)))
        }, -1, -1)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            clipChildren = false
            setPadding(dp(20), dp(70), dp(20), dp(16) + navB)
        }
        shownClock = Prefs.get(this, Prefs.CLOCK)
        val holder = FrameLayout(this).apply { clipChildren = false }
        holder.addView(buildClock(), FrameLayout.LayoutParams(-1, -2))
        clockHolder = holder
        col.addView(holder, LinearLayout.LayoutParams(-1, -2))
        col.addView(buildChip(), LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) })
        if (Prefs.get(this, Prefs.ALPHA) == 1)
            col.addView(alphabetBar(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(28) })

        val showName = hasWall || Prefs.get(this, Prefs.ALWAYS) == 1
        fun nameView(k: Float) = NameView(this).also {
            it.name = Prefs.name(this); it.nameStyle = Prefs.get(this, Prefs.NSTYLE)
            it.accent = accent; it.textColor = textC
            it.accent2 = if (Prefs.mixOn(this, Prefs.MIXNAME)) Prefs.get(this, Prefs.ACCENT2) else 0; it.scale = fs * k * nameK
            it.scriptTf = Prefs.typeface(this, 0); it.tf = tf
        }
        if (layout in 5..7) {
            // gol wheel layouts
            val area = FrameLayout(this).apply { clipChildren = false }
            if (showName) {
                val lp = when (layout) {
                    5 -> FrameLayout.LayoutParams(-2, -2, Gravity.CENTER)
                    6 -> FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL or Gravity.START)
                    else -> FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.TOP)
                        .apply { topMargin = dp(4) }
                }
                area.addView(nameView(if (layout == 5) 0.7f else 0.55f), lp)
            }
            val w = WheelView(this).also { v ->
                v.mode = layout - 5
                val fav = favourites(); mixN = fav.size
                v.items = fav.mapIndexed { idx, pr -> WheelView.Item(pr.first, tint(iconOf(pr.second), iconCol(idx)), pr.second) }
                v.ringColor = ringC; v.textColor = textC; v.tf = tf; v.fs = fs
                v.tapToCenter = Prefs.get(this, Prefs.SNAPTAP) == 1
                v.sizeScale = Prefs.get(this, Prefs.WHEELSZ) / 100f; v.iconScale = iconK
                v.onSpin = { dlt, wx, wy, wr ->
                    val f = fx
                    if (f != null) {
                        v.getLocationOnScreen(locA); f.getLocationOnScreen(locB)
                        f.spin(dlt, wx + locA[0] - locB[0], wy + locA[1] - locB[1], wr)
                    }
                }
                v.onOpen = { launch(it.intent) }
                v.onLong = { showMenu() }
                v.setup()
            }
            area.addView(w, -1, -1)
            wheel = w
            col.addView(area, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            val nameBox = FrameLayout(this).apply { clipChildren = false }
            if (showName) nameBox.addView(nameView(1f), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            col.addView(nameBox, LinearLayout.LayoutParams(-1, 0, 1f))
            col.addView(buildApps(layout), LinearLayout.LayoutParams(if (layout >= 3 && layout != 9) -1 else -2, -2).apply {
                gravity = when (layout) { 0, 9 -> Gravity.END; 1 -> Gravity.START; else -> Gravity.CENTER_HORIZONTAL }
                if (layout == 0) marginEnd = dp(24)
                if (layout == 1) marginStart = dp(24)
                if (layout == 9) marginEnd = dp(8)
                if (layout == 11) { marginStart = -dp(20); marginEnd = -dp(20) }   // poori chaudai
                bottomMargin = dp(24)
            })
        }
        colRef = col
        root.addView(col, -1, -1)

        val fxView = GoldFxView(this).apply {
            color = ringC; style = Prefs.get(this@MainActivity, Prefs.FX)
            camScale = Prefs.get(this@MainActivity, Prefs.RINGSZ) / 100f
            volScale = Prefs.get(this@MainActivity, Prefs.VOLSZ) / 100f
            fxEnabled = fxOn; camRing = Prefs.get(this@MainActivity, Prefs.CAM) == 1
            cam?.let { setCamera(it[0], it[1], it[2]) }
        }
        fx = fxView
        root.addView(fxView, -1, -1)
        root.requestApplyInsets()
        updateChip()
    }

    private fun decode(f: File): Bitmap? = try {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(f)) { dec, info, _ ->
            var s = 1
            while (info.size.width / (s * 2) >= 1080) s *= 2
            dec.setTargetSampleSize(s)
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    } catch (e: Exception) { null }

    private fun buildClock(): View =
        ClockFactory.build(this, tf, accent, textC, fs, Prefs.get(this, Prefs.CLOCK), clockK)

    // ----------------------------- Apps -----------------------------
    private fun favourites(): List<Pair<String, Intent?>> {
        val pm = packageManager
        fun pkg(p: String) = pm.getLaunchIntentForPackage(p)
        fun sel(cat: String) = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, cat)
        val chosen = Prefs.favs(this).mapNotNull { p ->
            if (p == Prefs.MUSIC_PKG) return@mapNotNull "Music" to (Intent(this, MusicActivity::class.java) as Intent?)
            val li = pkg(p) ?: return@mapNotNull null
            val label = try { pm.getApplicationInfo(p, 0).loadLabel(pm).toString() } catch (e: Exception) { p }
            label to (li as Intent?)
        }
        if (chosen.isNotEmpty()) return chosen
        val base = listOf(
            "Music" to Intent(this, MusicActivity::class.java),
            "Gmail" to pkg("com.google.android.gm"),
            "Camera" to Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            "Spotify" to pkg("com.spotify.music"),
            "YouTube" to pkg("com.google.android.youtube"),
            "Chrome" to pkg("com.android.chrome"),
            "Settings" to Intent(Settings.ACTION_SETTINGS)
        ).filter { it.second != null }
        // gol wheel mein zyada apps achhe lagte hain
        val extra = listOf(
            "Phone" to Intent(Intent.ACTION_DIAL),
            "Messages" to sel(Intent.CATEGORY_APP_MESSAGING),
            "Gallery" to sel(Intent.CATEGORY_APP_GALLERY),
            "Maps" to pkg("com.google.android.apps.maps")
        ).filter { e -> e.second?.let { pm.resolveActivity(it, 0) != null } == true }
        return base + extra
    }

    private fun iconOf(i: Intent?): Drawable {
        val pm = packageManager
        return i?.let { pm.resolveActivity(it, 0)?.loadIcon(pm) } ?: pm.defaultActivityIcon
    }

    private fun launch(i: Intent?) {
        if (i == null) return
        try { startActivity(Intent(i).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(this, "App khul nahi saka", Toast.LENGTH_SHORT).show() }
    }

    private fun buildApps(layout: Int): View {
        val favs = favourites().take(Prefs.get(this, Prefs.APPS).coerceIn(2, 12))
        mixN = favs.size
        fun item(l: String, i: Intent?) = appItem(l, i, layout).also { rows.add(it) }
        val labels = Prefs.get(this, Prefs.LABELS) == 1
        fun ti(l: String, i: Intent?, icon: Int, sp: Float) = tile(l, i, icon, sp, labels).also { rows.add(it) }
        return when (layout) {
            8 -> LinearLayout(this).apply {   // Glass dock
                gravity = Gravity.CENTER; background = glass(34); setPadding(dp(8), dp(10), dp(8), dp(10))
                favs.forEach { (l, i) -> addView(ti(l, i, 46, 11f), LinearLayout.LayoutParams(0, -2, 1f)) }
            }
            9 -> LinearLayout(this).apply {   // Side rail
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                background = glass(30); setPadding(dp(6), dp(8), dp(6), dp(8))
                favs.forEach { (l, i) -> addView(ti(l, i, 40, 10f)) }
            }
            10 -> bubbles(favs, labels)
            11 -> coverflow(favs, labels)
            3 -> LinearLayout(this).apply {
                gravity = Gravity.CENTER
                favs.forEach { (l, i) -> addView(item(l, i), LinearLayout.LayoutParams(0, -2, 1f)) }
            }
            4 -> LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                favs.chunked(3).forEach { part ->
                    addView(LinearLayout(context).apply {
                        part.forEach { (l, i) ->
                            addView(item(l, i), LinearLayout.LayoutParams(0, -2, 1f).apply {
                                setMargins(dp(5), dp(5), dp(5), dp(5)) })
                        }
                    })
                }
            }
            else -> LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = when (layout) { 0 -> Gravity.END; 1 -> Gravity.START; else -> Gravity.CENTER_HORIZONTAL }
                favs.forEach { (l, i) -> addView(item(l, i)) }
            }
        }
    }

    // ---------------- Bubbles: tairte hue gol bubbles ----------------
    private fun bubble(label: String, intent: Intent?, showLabel: Boolean, idx: Int): LinearLayout {
        val sz = (dp(30) * iconK).toInt()
        val rc = ringC
        val fill = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = dp(44).toFloat(); setGradientCenter(0.32f, 0.28f)
            colors = intArrayOf(Color.argb(150, Color.red(rc), Color.green(rc), Color.blue(rc)), Color.argb(150, 0, 0, 0))
            setStroke(dp(1), Color.argb(150, Color.red(rc), Color.green(rc), Color.blue(rc)))
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; clipChildren = false
            addView(FrameLayout(context).apply {
                background = fill
                addView(ImageView(context).apply { setImageDrawable(tint(iconOf(intent), iconCol(idx))) },
                    FrameLayout.LayoutParams(sz, sz, Gravity.CENTER))
            }, LinearLayout.LayoutParams(dp(64), dp(64)))
            if (showLabel) addView(TextView(context).apply {
                text = label; typeface = tf; setTextColor(textC); textSize = 11f * fs; maxLines = 1
            }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(3) })
            setOnClickListener { launch(intent) }
        }
    }

    private fun bubbles(favs: List<Pair<String, Intent?>>, labels: Boolean): View {
        val items = mutableListOf<View>()
        val per = if (favs.size <= 4) 2 else 3
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false }
        favs.chunked(per).forEachIndexed { ri, part ->
            box.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER; clipChildren = false
                part.forEachIndexed { ci, (l, i) ->
                    val b = bubble(l, i, labels, ri * per + ci); items.add(b)
                    addView(b, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(8), dp(5), dp(8), dp(5)) })
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { if (ri % 2 == 1) marginStart = dp(44) })   // honeycomb jaisa hat kar
        }
        floatAnim = ValueAnimator.ofFloat(0f, 6.2831855f).apply {
            duration = 9000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                items.forEachIndexed { n, v ->
                    val ph = n * 1.3f
                    v.translationY = sin(t + ph) * dp(7)
                    v.translationX = cos(t + ph * 0.7f) * dp(5)
                    val sc = 1f + 0.035f * sin(2f * t + ph)
                    v.scaleX = sc; v.scaleY = sc
                }
            }
            start()
        }
        return box
    }

    // ---------------- Coverflow: smooth snap carousel ----------------
    private inner class SnapScroll(ctx: android.content.Context, val step: Int) : HorizontalScrollView(ctx) {
        private var last = -1
        private val check = object : Runnable {
            override fun run() {
                if (scrollX == last) { smoothScrollTo(Math.round(scrollX / step.toFloat()) * step, 0); last = -1 }
                else { last = scrollX; postDelayed(this, 60) }
            }
        }
        override fun onTouchEvent(ev: MotionEvent): Boolean {
            val r = super.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                last = -1; removeCallbacks(check); postDelayed(check, 60)
            }
            return r
        }
    }

    private fun coverflow(favs: List<Pair<String, Intent?>>, labels: Boolean): View {
        val itemW = dp(124)
        val sw = resources.displayMetrics.widthPixels
        val pad = (sw - itemW) / 2
        val scroll = SnapScroll(this, itemW).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val strip = LinearLayout(this).apply { setPadding(pad, dp(10), pad, dp(10)); clipChildren = false; clipToPadding = false }
        val cards = ArrayList<View>()
        favs.forEachIndexed { idx, (l, i) ->
            val card = tile(l, i, 60, 14f, labels, idx).apply {
                background = glass(26); setPadding(dp(8), dp(20), dp(8), dp(20))
                cameraDistance = 14000f * resources.displayMetrics.density
            }
            card.setOnClickListener {
                val cur = Math.round(scroll.scrollX / itemW.toFloat())
                if (cur == idx) launch(i) else scroll.smoothScrollTo(idx * itemW, 0)
            }
            cards.add(card); strip.addView(card, LinearLayout.LayoutParams(itemW, -2))
        }
        fun update() {
            val c = scroll.scrollX + sw / 2f
            cards.forEachIndexed { n, v ->
                val d = (pad + n * itemW + itemW / 2f - c) / itemW
                val a = abs(d)
                val sc = (1f - 0.26f * a).coerceAtLeast(0.6f)
                v.scaleX = sc; v.scaleY = sc
                v.alpha = (1f - 0.45f * a).coerceIn(0.3f, 1f)
                v.rotationY = (-d * 28f).coerceIn(-50f, 50f)
            }
        }
        scroll.setOnScrollChangeListener { _, _, _, _, _ -> update() }
        scroll.addView(strip)
        scroll.post { scroll.scrollTo(itemW * (cards.size / 2), 0); update() }
        return scroll
    }

    private fun iconCol(idx: Int): Int =
        if (Prefs.mixOn(this, Prefs.MIXICON) && mixN > 1)
            ColorUtils.blendARGB(iconC, Prefs.get(this, Prefs.ACCENT2), (idx.toFloat() / (mixN - 1)).coerceIn(0f, 1f))
        else iconC

    private fun glass(radius: Int) = GradientDrawable().apply {
        cornerRadius = dp(radius).toFloat(); setColor(Color.argb(95, 0, 0, 0))
        setStroke(dp(1), Color.argb(120, Color.red(ringC), Color.green(ringC), Color.blue(ringC)))
    }

    private fun tile(label: String, intent: Intent?, iconDp: Int, textSp: Float, showLabel: Boolean, idx: Int = rows.size): LinearLayout {
        val sz = (dp(iconDp) * iconK).toInt()
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(6), dp(8), dp(6), dp(8))
            addView(ImageView(context).apply { setImageDrawable(tint(iconOf(intent), iconCol(idx))) }, LinearLayout.LayoutParams(sz, sz))
            if (showLabel) addView(TextView(context).apply {
                text = label; typeface = tf; setTextColor(textC); textSize = textSp * fs
                gravity = Gravity.CENTER; maxLines = 1
            }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })
            setOnClickListener { launch(intent) }
        }
    }

    private fun appItem(label: String, intent: Intent?, layout: Int): View {
        val ic = iconCol(rows.size)
        val iv = ImageView(this).apply { setImageDrawable(tint(iconOf(intent), ic)) }
        val tv = TextView(this).apply { text = label; typeface = tf; setTextColor(textC) }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER
            if (layout >= 3) {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), dp(10), dp(4), dp(10))
                addView(iv, LinearLayout.LayoutParams((dp(40) * iconK).toInt(), (dp(40) * iconK).toInt()))
                tv.textSize = (if (layout == 3) 15f else 17f) * fs; tv.gravity = Gravity.CENTER
                addView(tv, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })
                if (layout == 4) background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat()
                    setColor(Color.argb(70, 0, 0, 0))
                    setStroke(dp(1), Color.argb(110, Color.red(ringC), Color.green(ringC), Color.blue(ringC)))
                }
            } else {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(7), 0, dp(7))
                addView(iv, LinearLayout.LayoutParams((dp(34) * iconK).toInt(), (dp(34) * iconK).toInt()))
                tv.textSize = (if (layout == 2) 26f else 24f) * fs
                tv.minWidth = dp(120); tv.setPadding(dp(12), 0, 0, 0)
                tv.gravity = if (layout == 0) Gravity.END else Gravity.START
                addView(tv)
            }
            setOnClickListener { launch(intent) }
        }
    }

    /** Icon ko grayscale karke accent rang deta hai */
    private fun tint(d: Drawable, col: Int = iconC): Drawable {
        val r = Color.red(col) / 255f; val g = Color.green(col) / 255f; val b = Color.blue(col) / 255f
        val cm = ColorMatrix().apply { setSaturation(0f) }
        cm.postConcat(ColorMatrix(floatArrayOf(
            1.25f * r, 0f, 0f, 0f, 18f * r,
            0f, 1.25f * g, 0f, 0f, 18f * g,
            0f, 0f, 1.25f * b, 0f, 18f * b,
            0f, 0f, 0f, 1f, 0f)))
        return d.constantState?.newDrawable()?.mutate()?.apply {
            colorFilter = ColorMatrixColorFilter(cm)
        } ?: d
    }

    private fun alphabetBar(): View {
        val letters = LinearLayout(this).apply { setPadding(dp(8), 0, dp(8), 0) }
        ('A'..'Z').forEach { ch ->
            letters.addView(TextView(this).apply {
                text = ch.toString(); typeface = tf; textSize = 21f * fs
                setTextColor(textC); setPadding(dp(10), dp(6), dp(10), dp(6))
                setOnClickListener { showAppsFor(ch) }
            })
        }
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(letters) }
    }

    private fun showAppsFor(letter: Char) =
        startActivity(Intent(this, DrawerActivity::class.java).putExtra("q", letter.toString()))

    private fun showAllApps() = startActivity(Intent(this, DrawerActivity::class.java))

    private fun showMenu() {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("HaNeNa Launcher")
            .setItems(arrayOf("Launcher settings", "Music player", "Saari apps", "Wallpaper chuno", "Wallpaper hatao")) { _, i ->
                when (i) {
                    0 -> startActivity(Intent(this, SettingsActivity::class.java))
                    1 -> startActivity(Intent(this, MusicActivity::class.java))
                    2 -> showAllApps()
                    3 -> pickImage.launch("image/*")
                    else -> { Prefs.removeWallpaper(this); refresh() }
                }
            }.show()
    }

    // ----------------------- Animations (touch / volume) -----------------------
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        swipe.onTouchEvent(ev)
        val f = fx
        if (f != null && fxOn) {
            val w = resources.displayMetrics.widthPixels
            val edge = dp(28)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    val left = ev.x < edge
                    val right = ev.x > w - edge
                    if (left || right) {
                        if (!edgeActive) {
                            edgeActive = true
                            f.pulse(if (right) w.toFloat() else 0f, ev.y)
                            f.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                            waveAnim?.cancel()
                        }
                        f.setEdge(if (right) 1 else 0, ev.y)
                        pullRows(ev.y)
                    } else if (edgeActive) releaseEdge()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (edgeActive) releaseEdge()
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun pullRows(fingerY: Float) {
        val loc = IntArray(2)
        rows.forEach { r ->
            r.getLocationOnScreen(loc)
            val dist = (loc[1] + r.height / 2f - fingerY) / dp(90)
            r.translationX = -waveAmp * exp(-dist * dist)
        }
    }

    private fun releaseEdge() {
        edgeActive = false
        fx?.releaseEdge()
        val list = rows.toList()
        val start = list.map { it.translationX }
        waveAnim?.cancel()
        waveAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1100
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                val k = exp(-4f * t) * cos(10f * t)
                list.forEachIndexed { i, r -> r.translationX = start[i] * k }
            }
            start()
        }
    }

    private fun volumeWave() {
        val list = rows.toList()
        waveAnim?.cancel()
        waveAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                val amp = waveAmp * 0.7f * (1f - t)
                list.forEachIndexed { i, r -> r.translationX = amp * sin(t * 12.566f - i * 0.8f) }
            }
            start()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val f = fx
        val isVol = keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
        if (f != null && fxOn && isVol && event.repeatCount == 0) {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            f.postDelayed({ f.showVolume(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max) }, 60)
            val w = wheel
            if (w != null) w.kick(if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) 1 else -1) else volumeWave()
        }
        return super.onKeyDown(keyCode, event)
    }
}
