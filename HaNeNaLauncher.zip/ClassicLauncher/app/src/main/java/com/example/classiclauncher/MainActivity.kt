package com.example.classiclauncher

import android.animation.ValueAnimator
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.graphics.ImageDecoder
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import java.io.File
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private var fx: GoldFxView? = null
    private val rows = mutableListOf<View>()
    private var edgeActive = false
    private var waveAnim: ValueAnimator? = null
    private var lastRev = -1
    private var cam: FloatArray? = null
    private var wheel: WheelView? = null
    private var colRef: LinearLayout? = null
    private var navB = 0

    private var accent = 0
    private var textC = 0
    private var fs = 1f
    private var waveAmp = 0f
    private var fxOn = true
    private lateinit var tf: Typeface

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let {
                if (!Prefs.saveWallpaper(this, it))
                    Toast.makeText(this, "Wallpaper set nahi hua", Toast.LENGTH_SHORT).show()
                refresh()
            }
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.BLACK

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(root)

        // selfie camera (punch-hole / ring) ki jagah system se pooch lo
        root.setOnApplyWindowInsetsListener { v, ins ->
            navB = ins.systemWindowInsetBottom
            colRef?.setPadding(dp(20), dp(70), dp(20), dp(16) + navB)
            if (Build.VERSION.SDK_INT >= 28) {
                ins.displayCutout?.boundingRects?.firstOrNull { it.top < dp(80) }?.let {
                    cam = floatArrayOf(it.exactCenterX(), it.exactCenterY(), maxOf(it.width(), it.height()) / 2f)
                    fx?.setCamera(cam!![0], cam!![1], cam!![2])
                }
            }
            v.onApplyWindowInsets(ins)
        }
        root.setOnLongClickListener { showMenu(); true }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { /* home screen: kuch nahi */ }
        })
    }

    override fun onResume() {
        super.onResume(); refresh()
        if (Prefs.get(this, Prefs.LOCK) == 1 && Settings.canDrawOverlays(this)) {
            try { androidx.core.content.ContextCompat.startForegroundService(this, Intent(this, LockService::class.java)) }
            catch (e: Exception) { }
        }
    }

    private fun refresh() {
        val r = Prefs.rev(this)
        if (r != lastRev) { lastRev = r; buildUi() }
    }

    // ============================== UI ==============================
    private fun buildUi() {
        waveAnim?.cancel(); edgeActive = false
        root.removeAllViews(); rows.clear(); wheel = null
        accent = Prefs.get(this, Prefs.ACCENT)
        textC = Prefs.get(this, Prefs.TEXT)
        fs = Prefs.get(this, Prefs.SCALE) / 100f
        waveAmp = dp(Prefs.get(this, Prefs.WAVE)).toFloat()
        fxOn = Prefs.get(this, Prefs.FXON) == 1
        tf = Prefs.typeface(this, Prefs.get(this, Prefs.FONT))
        val layout = Prefs.get(this, Prefs.LAYOUT)
        val wall = Prefs.wallFile(this)
        val hasWall = wall.exists()

        // wallpaper
        val bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        if (hasWall) decode(wall)?.let { bg.setImageBitmap(it) }
        root.addView(bg, -1, -1)
        root.addView(View(this).apply {
            setBackgroundColor(Color.argb(Prefs.get(this@MainActivity, Prefs.DIM) * 255 / 100, 0, 0, 0))
        }, -1, -1)
        if (hasWall) root.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(170, 0, 0, 0)))
        }, -1, -1)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(70), dp(20), dp(16) + navB)
        }
        col.addView(buildClock())
        col.addView(alphabetBar(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(28) })

        val showName = hasWall || Prefs.get(this, Prefs.ALWAYS) == 1
        fun nameView(k: Float) = NameView(this).also {
            it.name = Prefs.name(this); it.nameStyle = Prefs.get(this, Prefs.NSTYLE)
            it.accent = accent; it.textColor = textC; it.scale = fs * k
            it.scriptTf = Prefs.typeface(this, 0); it.tf = tf
        }
        if (layout >= 5) {
            // gol wheel layouts
            val area = FrameLayout(this)
            if (showName) {
                val lp = when (layout) {
                    5 -> FrameLayout.LayoutParams(-2, -2, Gravity.CENTER)
                    6 -> FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL or Gravity.START)
                    else -> FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.TOP)
                        .apply { topMargin = dp(4) }
                }
                area.addView(nameView(if (layout == 5) 0.7f else 0.55f), lp)
            }
            val w = WheelView(this).also { v ->
                v.mode = layout - 5
                v.items = favourites().map { (l, i) -> WheelView.Item(l, tint(iconOf(i)), i) }
                v.accent = accent; v.textColor = textC; v.tf = tf; v.fs = fs
                v.onOpen = { launch(it.intent) }
                v.onLong = { showMenu() }
                v.setup()
            }
            area.addView(w, -1, -1)
            wheel = w
            col.addView(area, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            val nameBox = FrameLayout(this)
            if (showName) nameBox.addView(nameView(1f), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            col.addView(nameBox, LinearLayout.LayoutParams(-1, 0, 1f))
            col.addView(buildApps(layout), LinearLayout.LayoutParams(if (layout >= 3) -1 else -2, -2).apply {
                gravity = when (layout) { 0 -> Gravity.END; 1 -> Gravity.START; else -> Gravity.CENTER_HORIZONTAL }
                if (layout == 0) marginEnd = dp(24)
                if (layout == 1) marginStart = dp(24)
                bottomMargin = dp(24)
            })
        }
        colRef = col
        root.addView(col, -1, -1)

        val fxView = GoldFxView(this).apply {
            color = accent; style = Prefs.get(this@MainActivity, Prefs.FX)
            fxEnabled = fxOn; camRing = Prefs.get(this@MainActivity, Prefs.CAM) == 1
            cam?.let { setCamera(it[0], it[1], it[2]) }
        }
        fx = fxView
        root.addView(fxView, -1, -1)
        root.requestApplyInsets()
    }

    private fun decode(f: File): Bitmap? = try {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(f)) { dec, info, _ ->
            var s = 1
            while (info.size.width / (s * 2) >= 1080) s *= 2
            dec.setTargetSampleSize(s)
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    } catch (e: Exception) { null }

    private fun buildClock(): View =
        ClockFactory.build(this, tf, accent, textC, fs, Prefs.get(this, Prefs.CLOCK))

    private fun alphabetBar(): View {
        val letters = LinearLayout(this).apply { setPadding(dp(8), 0, dp(8), 0) }
        ('A'..'Z').forEach { ch ->
            letters.addView(TextView(this).apply {
                text = ch.toString(); typeface = tf; textSize = 21f * fs
                setTextColor(textC); setPadding(dp(10), dp(6), dp(10), dp(6))
                setOnClickListener { showAppsFor(ch) }
            })
        }
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(letters) }
    }

    // ----------------------------- Apps -----------------------------
    private fun favourites(): List<Pair<String, Intent?>> {
        val pm = packageManager
        fun pkg(p: String) = pm.getLaunchIntentForPackage(p)
        fun sel(cat: String) = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, cat)
        val base = listOf(
            "Gmail" to pkg("com.google.android.gm"),
            "Camera" to Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            "Spotify" to pkg("com.spotify.music"),
            "YouTube" to pkg("com.google.android.youtube"),
            "Chrome" to pkg("com.android.chrome"),
            "Settings" to Intent(Settings.ACTION_SETTINGS)
        ).filter { it.second != null }
        // gol wheel mein zyada apps achhe lagte hain
        val extra = listOf(
            "Phone" to Intent(Intent.ACTION_DIAL),
            "Messages" to sel(Intent.CATEGORY_APP_MESSAGING),
            "Gallery" to sel(Intent.CATEGORY_APP_GALLERY),
            "Maps" to pkg("com.google.android.apps.maps")
        ).filter { e -> e.second?.let { pm.resolveActivity(it, 0) != null } == true }
        return base + extra
    }

    private fun iconOf(i: Intent?): Drawable {
        val pm = packageManager
        return i?.let { pm.resolveActivity(it, 0)?.loadIcon(pm) } ?: pm.defaultActivityIcon
    }

    private fun launch(i: Intent?) {
        if (i == null) return
        try { startActivity(Intent(i).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(this, "App khul nahi saka", Toast.LENGTH_SHORT).show() }
    }

    private fun buildApps(layout: Int): View {
        val favs = favourites().take(6)
        fun item(l: String, i: Intent?) = appItem(l, i, layout).also { rows.add(it) }
        return when (layout) {
            3 -> LinearLayout(this).apply {
                gravity = Gravity.CENTER
                favs.forEach { (l, i) -> addView(item(l, i), LinearLayout.LayoutParams(0, -2, 1f)) }
            }
            4 -> LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                favs.chunked(3).forEach { part ->
                    addView(LinearLayout(context).apply {
                        part.forEach { (l, i) ->
                            addView(item(l, i), LinearLayout.LayoutParams(0, -2, 1f).apply {
                                setMargins(dp(5), dp(5), dp(5), dp(5)) })
                        }
                    })
                }
            }
            else -> LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = when (layout) { 0 -> Gravity.END; 1 -> Gravity.START; else -> Gravity.CENTER_HORIZONTAL }
                favs.forEach { (l, i) -> addView(item(l, i)) }
            }
        }
    }

    private fun appItem(label: String, intent: Intent?, layout: Int): View {
        val iv = ImageView(this).apply { setImageDrawable(tint(iconOf(intent))) }
        val tv = TextView(this).apply { text = label; typeface = tf; setTextColor(textC) }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER
            if (layout >= 3) {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), dp(10), dp(4), dp(10))
                addView(iv, LinearLayout.LayoutParams(dp(40), dp(40)))
                tv.textSize = (if (layout == 3) 15f else 17f) * fs; tv.gravity = Gravity.CENTER
                addView(tv, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })
                if (layout == 4) background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat()
                    setColor(Color.argb(70, 0, 0, 0))
                    setStroke(dp(1), Color.argb(110, Color.red(accent), Color.green(accent), Color.blue(accent)))
                }
            } else {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(7), 0, dp(7))
                addView(iv, LinearLayout.LayoutParams(dp(34), dp(34)))
                tv.textSize = (if (layout == 2) 26f else 24f) * fs
                tv.minWidth = dp(120); tv.setPadding(dp(12), 0, 0, 0)
                tv.gravity = if (layout == 0) Gravity.END else Gravity.START
                addView(tv)
            }
            setOnClickListener { launch(intent) }
        }
    }

    /** Icon ko grayscale karke accent rang deta hai */
    private fun tint(d: Drawable): Drawable {
        val r = Color.red(accent) / 255f; val g = Color.green(accent) / 255f; val b = Color.blue(accent) / 255f
        val cm = ColorMatrix().apply { setSaturation(0f) }
        cm.postConcat(ColorMatrix(floatArrayOf(
            1.25f * r, 0f, 0f, 0f, 18f * r,
            0f, 1.25f * g, 0f, 0f, 18f * g,
            0f, 0f, 1.25f * b, 0f, 18f * b,
            0f, 0f, 0f, 1f, 0f)))
        return d.constantState?.newDrawable()?.mutate()?.apply {
            colorFilter = ColorMatrixColorFilter(cm)
        } ?: d
    }

    private fun showAppsFor(letter: Char) {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, PackageManager.MATCH_ALL)
            .map { it.loadLabel(pm).toString() to it }
            .filter { it.first.startsWith(letter, ignoreCase = true) }
            .sortedBy { it.first.lowercase() }
        if (apps.isEmpty()) {
            Toast.makeText(this, "$letter se koi app nahi", Toast.LENGTH_SHORT).show(); return
        }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(letter.toString())
            .setItems(apps.map { it.first }.toTypedArray()) { _, i ->
                val ai = apps[i].second.activityInfo
                startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setClassName(ai.packageName, ai.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }.show()
    }

    private fun showMenu() {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("HaNeNa Launcher")
            .setItems(arrayOf("Launcher settings", "Wallpaper chuno", "Wallpaper hatao")) { _, i ->
                when (i) {
                    0 -> startActivity(Intent(this, SettingsActivity::class.java))
                    1 -> pickImage.launch("image/*")
                    else -> { Prefs.removeWallpaper(this); refresh() }
                }
            }.show()
    }

    // ----------------------- Animations (touch / volume) -----------------------
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        val f = fx
        if (f != null && fxOn) {
            val w = resources.displayMetrics.widthPixels
            val edge = dp(28)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    val left = ev.x < edge
                    val right = ev.x > w - edge
                    if (left || right) {
                        if (!edgeActive) {
                            edgeActive = true
                            f.pulse(if (right) w.toFloat() else 0f, ev.y)
                            f.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                            waveAnim?.cancel()
                        }
                        f.setEdge(if (right) 1 else 0, ev.y)
                        pullRows(ev.y)
                    } else if (edgeActive) releaseEdge()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (edgeActive) releaseEdge()
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun pullRows(fingerY: Float) {
        val loc = IntArray(2)
        rows.forEach { r ->
            r.getLocationOnScreen(loc)
            val dist = (loc[1] + r.height / 2f - fingerY) / dp(90)
            r.translationX = -waveAmp * exp(-dist * dist)
        }
    }

    private fun releaseEdge() {
        edgeActive = false
        fx?.releaseEdge()
        val list = rows.toList()
        val start = list.map { it.translationX }
        waveAnim?.cancel()
        waveAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1100
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                val k = exp(-4f * t) * cos(10f * t)
                list.forEachIndexed { i, r -> r.translationX = start[i] * k }
            }
            start()
        }
    }

    private fun volumeWave() {
        val list = rows.toList()
        waveAnim?.cancel()
        waveAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                val amp = waveAmp * 0.7f * (1f - t)
                list.forEachIndexed { i, r -> r.translationX = amp * sin(t * 12.566f - i * 0.8f) }
            }
            start()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val f = fx
        val isVol = keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
        if (f != null && fxOn && isVol && event.repeatCount == 0) {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            f.postDelayed({ f.showVolume(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max) }, 60)
            val w = wheel
            if (w != null) w.kick(if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) 1 else -1) else volumeWave()
        }
        return super.onKeyDown(keyCode, event)
    }
}
