package com.example.classiclauncher

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat

/** HaNeNa Music: stylish player + phone ke saare gaano ki list */
class MusicActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var holder: FrameLayout          // player yahan lagta hai
    private lateinit var listBox: LinearLayout
    private lateinit var listView: ListView
    private lateinit var search: EditText
    private lateinit var msg: TextView
    private lateinit var permBtn: TextView
    private var panel: MusicPanel? = null
    private var shown: List<MusicEngine.Track> = emptyList()
    private var styleBtn: IconBtn? = null

    private var accent = 0
    private var accent2 = 0
    private var textC = 0
    private lateinit var tf: android.graphics.Typeface
    private lateinit var script: android.graphics.Typeface

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val perm: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private val askPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) loadSongs() else showPermNeeded()
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int) = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val row = (cv as? LinearLayout) ?: LinearLayout(this@MusicActivity).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(10), dp(16), dp(10))
                addView(IconBtn(context, IconBtn.NOTE), LinearLayout.LayoutParams(dp(22), dp(22)))
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(TextView(context).apply { textSize = 16f; setSingleLine(true) })
                    addView(TextView(context).apply { textSize = 12f; setSingleLine(true) })
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(14) })
                addView(TextView(context).apply { textSize = 12f; setTextColor(Color.argb(150, 255, 255, 255)) })
            }
            val t = shown[p]
            val isCur = MusicEngine.current?.id == t.id
            (row.getChildAt(0) as IconBtn).apply { color = if (isCur) accent else Color.argb(110, 255, 255, 255); invalidate() }
            val col = row.getChildAt(1) as LinearLayout
            (col.getChildAt(0) as TextView).apply { text = t.title; typeface = tf; setTextColor(if (isCur) accent else textC) }
            (col.getChildAt(1) as TextView).apply { text = t.artist; typeface = tf; setTextColor(Color.argb(150, 255, 255, 255)) }
            (row.getChildAt(2) as TextView).text = MusicEngine.fmt(t.dur.toInt())
            return row
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        accent = Prefs.get(this, Prefs.ACCENT)
        accent2 = if (Prefs.get(this, Prefs.MIX) == 1) Prefs.get(this, Prefs.ACCENT2) else 0
        textC = Prefs.get(this, Prefs.TEXT)
        tf = Prefs.typeface(this, Prefs.get(this, Prefs.FONT))
        script = Prefs.typeface(this, 0)

        val bgTop = ColorUtils.blendARGB(Color.BLACK, accent, 0.22f)
        window.statusBarColor = bgTop
        window.navigationBarColor = Color.BLACK

        root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bgTop, Color.BLACK, Color.BLACK))
            fitsSystemWindows = true
        }

        // ---- upar ki patti ----
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        top.addView(IconBtn(this, IconBtn.BACK).apply { color = accent; setOnClickListener { finish() } },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        top.addView(TextView(this).apply {
            text = "HaNeNa Music"; typeface = script; textSize = 24f; setTextColor(textC); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val sb = IconBtn(this, IconBtn.STYLE).apply { color = accent; setOnClickListener { cycleStyle() } }
        styleBtn = sb
        top.addView(sb, LinearLayout.LayoutParams(dp(44), dp(44)))
        top.addView(IconBtn(this, IconBtn.LIST).apply { color = accent; setOnClickListener { toggleList() } },
            LinearLayout.LayoutParams(dp(44), dp(44)))

        holder = FrameLayout(this)
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(holder, -1, -2) }

        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(top, LinearLayout.LayoutParams(-1, -2))
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(page, -1, -1)

        // ---- gaano ki list (upar se dhakti hai) ----
        search = EditText(this).apply {
            hint = "Gaana ya artist dhundo..."; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            setSingleLine(true); setPadding(dp(16), dp(12), dp(16), dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { filter(s?.toString().orEmpty()) }
            })
        }
        listView = ListView(this).apply {
            divider = null; this.adapter = this@MusicActivity.adapter
            setOnItemClickListener { _, _, p, _ ->
                MusicEngine.play(this@MusicActivity, shown, p)
                toggleList(false)
            }
        }
        msg = TextView(this).apply { textSize = 15f; setTextColor(Color.argb(190, 255, 255, 255)); gravity = Gravity.CENTER; setPadding(dp(24), dp(24), dp(24), dp(12)) }
        permBtn = TextView(this).apply {
            text = "Ijazat do"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(accent)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setStroke(dp(1), accent) }
            setOnClickListener { askPerm.launch(perm) }
        }
        listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setBackgroundColor(Color.argb(245, 8, 8, 10))
            addView(search, LinearLayout.LayoutParams(-1, -2))
            addView(msg, LinearLayout.LayoutParams(-1, -2))
            addView(permBtn, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
            addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        root.addView(listBox, -1, -1)
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (listBox.visibility == View.VISIBLE) toggleList(false) else finish() }
        })

        mountPanel()
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) loadSongs()
        else { toggleList(true); showPermNeeded(); askPerm.launch(perm) }
    }

    override fun onResume() {
        super.onResume()
        MusicEngine.listen(this) { adapter.notifyDataSetChanged() }
    }

    override fun onPause() { MusicEngine.unlisten(this); super.onPause() }

    private fun mountPanel() {
        holder.removeAllViews()
        val st = Prefs.get(this, Prefs.MUSTYLE).coerceIn(0, Opts.musicStyles.size - 1)
        panel = MusicPanel(this, st, false, accent, accent2, textC, tf, script)
        holder.addView(panel, FrameLayout.LayoutParams(-1, -2))
    }

    private fun cycleStyle() {
        if (Prefs.raw(this, Prefs.AUTO) == 1) {
            Toast.makeText(this, "Auto mode on hai, music style khud badal raha hai. Settings, Auto mode se badlo.", Toast.LENGTH_LONG).show()
            return
        }
        val next = (Prefs.get(this, Prefs.MUSTYLE) + 1) % Opts.musicStyles.size
        Prefs.put(this, Prefs.MUSTYLE, next)
        Toast.makeText(this, "Style: ${Opts.musicStyles[next]}", Toast.LENGTH_SHORT).show()
        mountPanel()
    }

    private fun toggleList(show: Boolean = listBox.visibility != View.VISIBLE) {
        listBox.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) {
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .hideSoftInputFromWindow(search.windowToken, 0)
        }
    }

    private fun showPermNeeded() {
        msg.text = "Phone ke gaane dikhane ke liye music ki ijazat chahiye."
        permBtn.visibility = View.VISIBLE
    }

    private fun loadSongs() {
        permBtn.visibility = View.GONE
        msg.text = "Gaane dhoondh raha hoon..."
        MusicEngine.scan(this) {
            filter(search.text.toString())
            msg.text = if (MusicEngine.tracks.isEmpty()) "Phone mein koi gaana nahi mila." else ""
            msg.visibility = if (msg.text.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun filter(q: String) {
        val t = q.trim()
        shown = if (t.isEmpty()) MusicEngine.tracks
        else MusicEngine.tracks.filter { it.title.contains(t, true) || it.artist.contains(t, true) }
        adapter.notifyDataSetChanged()
    }
}
