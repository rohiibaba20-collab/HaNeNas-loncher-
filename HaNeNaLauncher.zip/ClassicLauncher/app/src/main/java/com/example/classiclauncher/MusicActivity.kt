package com.example.classiclauncher

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat

/** HaNeNa Music: stylish player + gaano ki khoobsurat library (art, A-Z sections, search, mini player) */
class MusicActivity : AppCompatActivity() {

    /** header != null to A, B, C... wali patti; warna ek gaana (idx = shown list mein uski jagah) */
    private class Row(val header: String?, val track: MusicEngine.Track?, val idx: Int)

    private lateinit var root: FrameLayout
    private lateinit var holder: FrameLayout          // player yahan lagta hai
    private lateinit var listBox: LinearLayout
    private lateinit var listView: ListView
    private lateinit var search: EditText
    private lateinit var msg: TextView
    private lateinit var permBtn: TextView
    private lateinit var countTv: TextView
    private var mini: MusicPanel? = null
    private var favTab = false
    private lateinit var tabHolder: FrameLayout
    private val skin by lazy { Skin(this) }
    private var panel: MusicPanel? = null
    private var shown: List<MusicEngine.Track> = emptyList()
    private var rows: List<Row> = emptyList()

    private var accent = 0
    private var accent2 = 0
    private var textC = 0
    private var bgTop = 0
    private lateinit var tf: Typeface
    private lateinit var script: Typeface

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun al(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private val perm: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    private val askPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) loadSongs() else showPermNeeded()
    }

    // ------------------------------ list adapter ------------------------------
    private val adapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(p: Int) = rows[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(p: Int) = if (rows[p].header != null) 0 else 1
        override fun isEnabled(p: Int) = rows[p].header == null
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val r = rows[p]
            val h = r.header
            return if (h != null) headerView(h, cv) else trackView(r.track!!, cv)
        }
    }

    private fun headerView(letter: String, cv: View?): View {
        val v = (cv as? LinearLayout) ?: LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), dp(16), dp(24), dp(4))
            addView(TextView(context).apply { typeface = script; textSize = 24f; setTextColor(accent) })
            addView(View(context).apply { setBackgroundColor(Color.argb(38, 255, 255, 255)) },
                LinearLayout.LayoutParams(0, dp(1), 1f).apply { marginStart = dp(14) })
        }
        (v.getChildAt(0) as TextView).text = letter
        return v
    }

    private fun trackView(t: MusicEngine.Track, cv: View?): View {
        val outer = (cv as? FrameLayout) ?: FrameLayout(this).apply {
            setPadding(dp(12), dp(3), dp(12), dp(3))
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(14), dp(8))
                addView(ThumbView(context), LinearLayout.LayoutParams(dp(54), dp(54)))
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(TextView(context).apply { textSize = 16f; setSingleLine(true); ellipsize = TextUtils.TruncateAt.END })
                    addView(TextView(context).apply { textSize = 12.5f; setSingleLine(true); ellipsize = TextUtils.TruncateAt.END },
                        LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(14); marginEnd = dp(8) })
                addView(TextView(context).apply { textSize = 12f })
                addView(IconBtn(context, IconBtn.HEART), LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginStart = dp(6) })
            }, FrameLayout.LayoutParams(-1, -2))
        }
        val card = outer.getChildAt(0) as LinearLayout
        val cur = MusicEngine.current?.id == t.id
        card.background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(if (cur) al(accent, 42) else Color.argb(24, 255, 255, 255))
            setStroke(dp(1), if (cur) al(accent, 170) else Color.argb(20, 255, 255, 255))
        }
        val th = card.getChildAt(0) as ThumbView
        th.accent = accent; th.current = cur; th.playing = cur && MusicEngine.isPlaying
        th.tag = t.id
        val have = MusicEngine.cachedThumb(t.id)
        th.setBmp(have)
        if (have == null) MusicEngine.thumb(this, t, 160) { b -> if (th.tag == t.id) th.setBmp(b) }
        val col = card.getChildAt(1) as LinearLayout
        (col.getChildAt(0) as TextView).apply { text = t.title; typeface = tf; setTextColor(if (cur) accent else textC) }
        (col.getChildAt(1) as TextView).apply { text = t.artist; typeface = tf; setTextColor(Color.argb(150, 255, 255, 255)) }
        (card.getChildAt(2) as TextView).apply { text = MusicEngine.fmt(t.dur.toInt()); typeface = tf; setTextColor(Color.argb(130, 255, 255, 255)) }
        val hb = card.getChildAt(3) as IconBtn
        val fav = MusicEngine.isFav(this, t.id)
        hb.filled = fav; hb.color = if (fav) accent else Color.argb(150, 255, 255, 255); hb.invalidate()
        hb.setOnClickListener {
            MusicEngine.toggleFav(this@MusicActivity, t.id)
            if (favTab) filter(search.text.toString()) else adapter.notifyDataSetChanged()
        }
        return outer
    }

    // ------------------------------ screen ------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        accent = Prefs.get(this, Prefs.ACCENT)
        accent2 = if (Prefs.get(this, Prefs.MIX) == 1) Prefs.get(this, Prefs.ACCENT2) else 0
        textC = Prefs.get(this, Prefs.TEXT)
        tf = Prefs.typeface(this, Prefs.get(this, Prefs.FONT))
        script = Prefs.typeface(this, 0)

        bgTop = ColorUtils.blendARGB(Color.BLACK, accent, 0.22f)
        window.statusBarColor = bgTop
        window.navigationBarColor = Color.BLACK

        root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bgTop, Color.BLACK, Color.BLACK))
            fitsSystemWindows = true
        }

        // ---- upar ki patti ----
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        top.addView(IconBtn(this, IconBtn.BACK).apply { color = accent; setOnClickListener { finish() } },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        top.addView(TextView(this).apply {
            text = "HaNeNa Music"; typeface = script; textSize = 24f; setTextColor(textC); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(IconBtn(this, IconBtn.STYLE).apply { color = accent; setOnClickListener { cycleStyle() } },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        top.addView(IconBtn(this, IconBtn.LIST).apply { color = accent; setOnClickListener { toggleList() } },
            LinearLayout.LayoutParams(dp(44), dp(44)))

        holder = FrameLayout(this)
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(holder, -1, -2) }

        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(top, LinearLayout.LayoutParams(-1, -2))
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(page, -1, -1)

        // ---- library (upar se dhakti hai) ----
        val libTop = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(18), dp(0))
        }
        libTop.addView(IconBtn(this, IconBtn.BACK).apply { color = accent; setOnClickListener { toggleList(false) } },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        libTop.addView(TextView(this).apply {
            text = "Library"; typeface = script; textSize = 28f; setTextColor(textC)
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        countTv = TextView(this).apply { textSize = 13f; setTextColor(accent) }
        libTop.addView(countTv, LinearLayout.LayoutParams(-2, -2))

        search = EditText(this).apply {
            hint = "Gaana ya artist dhundo"; setHintTextColor(Color.argb(120, 255, 255, 255)); setTextColor(Color.WHITE)
            textSize = 15f; setSingleLine(true); background = null
            setPadding(dp(20), dp(12), dp(20), dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { filter(s?.toString().orEmpty()) }
            })
        }
        val searchPill = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(26).toFloat(); setColor(Color.argb(34, 255, 255, 255)); setStroke(dp(1), al(accent, 110))
            }
            addView(search, FrameLayout.LayoutParams(-1, -2))
        }

        tabHolder = FrameLayout(this)
        fillTabs()
        listView = ListView(this).apply {
            divider = null; selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            isFastScrollEnabled = true; clipToPadding = false; setPadding(0, dp(4), 0, dp(10))
            this.adapter = this@MusicActivity.adapter
            setOnItemClickListener { _, _, p, _ ->
                val r = rows[p]
                if (r.track != null) { MusicEngine.play(this@MusicActivity, shown, r.idx); toggleList(false) }
            }
        }
        msg = TextView(this).apply {
            textSize = 15f; setTextColor(Color.argb(190, 255, 255, 255)); gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(12))
        }
        permBtn = TextView(this).apply {
            text = "Ijazat do"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(accent)
            setPadding(dp(22), dp(12), dp(22), dp(12))
            background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setStroke(dp(1), accent) }
            setOnClickListener { askPerm.launch(perm) }
        }

        // chhota player: library mein bhi gaana control karo
        val st = Prefs.get(this, Prefs.MUSTYLE).coerceIn(0, Opts.musicStyles.size - 1)
        val miniP = MusicPanel(this, st, true, accent, accent2, textC, tf, script)
        miniP.visibility = if (MusicEngine.current != null) View.VISIBLE else View.GONE
        mini = miniP

        listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bgTop, Color.BLACK, Color.BLACK))
            addView(libTop, LinearLayout.LayoutParams(-1, -2))
            addView(searchPill, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(10), dp(16), dp(6)) })
            addView(tabHolder, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(2), dp(12), dp(4)) })
            addView(msg, LinearLayout.LayoutParams(-1, -2))
            addView(permBtn, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
            addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(miniP, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(4), dp(12), dp(10)) })
        }
        root.addView(listBox, -1, -1)
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (listBox.visibility == View.VISIBLE) toggleList(false) else finish() }
        })

        mountPanel()
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) loadSongs()
        else { toggleList(true); showPermNeeded(); askPerm.launch(perm) }
    }

    override fun onResume() {
        super.onResume()
        MusicEngine.listen(this) {
            mini?.visibility = if (MusicEngine.current != null) View.VISIBLE else View.GONE
            if (favTab) filter(search.text.toString()) else adapter.notifyDataSetChanged()
        }
    }

    override fun onPause() { MusicEngine.unlisten(this); super.onPause() }

    private fun mountPanel() {
        holder.removeAllViews()
        val st = Prefs.get(this, Prefs.MUSTYLE).coerceIn(0, Opts.musicStyles.size - 1)
        panel = MusicPanel(this, st, false, accent, accent2, textC, tf, script)
        holder.addView(panel, FrameLayout.LayoutParams(-1, -2))
    }

    private fun cycleStyle() {
        if (Prefs.raw(this, Prefs.AUTO) == 1) {
            Toast.makeText(this, "Auto mode on hai, music style khud badal raha hai. Settings, Auto mode se badlo.", Toast.LENGTH_LONG).show()
            return
        }
        val next = (Prefs.get(this, Prefs.MUSTYLE) + 1) % Opts.musicStyles.size
        Prefs.put(this, Prefs.MUSTYLE, next)
        Toast.makeText(this, "Style: ${Opts.musicStyles[next]}", Toast.LENGTH_SHORT).show()
        mountPanel()
    }

    private fun toggleList(show: Boolean = listBox.visibility != View.VISIBLE) {
        listBox.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) {
            (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .hideSoftInputFromWindow(search.windowToken, 0)
        }
    }

    private fun showPermNeeded() {
        msg.text = "Phone ke gaane dikhane ke liye music ki ijazat chahiye."
        msg.visibility = View.VISIBLE
        permBtn.visibility = View.VISIBLE
    }

    private fun loadSongs() {
        permBtn.visibility = View.GONE
        msg.visibility = View.VISIBLE
        msg.text = "Gaane dhoondh raha hoon..."
        MusicEngine.scan(this) {
            filter(search.text.toString())
            msg.text = if (MusicEngine.tracks.isEmpty()) "Phone mein koi gaana nahi mila." else ""
            msg.visibility = if (msg.text.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun fillTabs() {
        tabHolder.removeAllViews()
        tabHolder.addView(skin.chips(listOf("Sab gaane", "Favourites"), if (favTab) 1 else 0) {
            favTab = it == 1; fillTabs(); filter(search.text.toString())
        })
    }

    private fun filter(q: String) {
        val t = q.trim()
        val base = if (favTab) { val f = MusicEngine.favs(this); MusicEngine.tracks.filter { f.contains(it.id) } } else MusicEngine.tracks
        shown = if (t.isEmpty()) base
        else base.filter { it.title.contains(t, true) || it.artist.contains(t, true) }
        val out = ArrayList<Row>()
        var last = ""
        shown.forEachIndexed { i, tr ->
            if (t.isEmpty()) {
                val c = tr.title.trim().firstOrNull()?.uppercaseChar()
                val key = if (c != null && c.isLetter()) c.toString() else "#"
                if (key != last) { out.add(Row(key, null, -1)); last = key }
            }
            out.add(Row(null, tr, i))
        }
        rows = out
        countTv.text = if (favTab) "${shown.size} favourite" else "${shown.size} gaane"
        adapter.notifyDataSetChanged()
    }
}
