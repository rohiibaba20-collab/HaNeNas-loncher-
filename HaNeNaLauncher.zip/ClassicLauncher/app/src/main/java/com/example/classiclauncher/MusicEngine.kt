package com.example.classiclauncher

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.util.Size
import androidx.core.content.ContextCompat

/**
 * HaNeNa Music: phone ke gaane chalane wala engine. Poori app ke liye ek hi hai,
 * isliye Home, Music screen aur Lock screen teeno ek hi gaane ki halat dekhte hain.
 * Sab kuch main thread par chalta hai.
 */
object MusicEngine {

    class Track(
        val id: Long, val title: String, val artist: String, val album: String,
        val albumId: Long, val dur: Long, val uri: Uri
    )

    var tracks: List<Track> = emptyList(); private set      // phone ke saare gaane
    var queue: List<Track> = emptyList(); private set       // abhi ki playlist
    var index = -1; private set
    var shuffle = false
    var repeat = 0                                           // 0 band, 1 sab, 2 ek hi
    var isPlaying = false; private set
    var art: Bitmap? = null; private set

    val current: Track? get() = queue.getOrNull(index)

    private var mp: MediaPlayer? = null
    private var prepared = false
    private var appCtx: Context? = null
    private val main = Handler(Looper.getMainLooper())
    private val listeners = LinkedHashMap<Any, () -> Unit>()
    private var focusReq: AudioFocusRequest? = null
    private var resumeOnFocus = false
    private var artFor = -1L

    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()

    // ------------------------- listeners -------------------------
    fun listen(owner: Any, fn: () -> Unit) { listeners[owner] = fn }
    fun unlisten(owner: Any) { listeners.remove(owner) }
    private fun changed() { for (f in listeners.values.toList()) f() }

    // ------------------------- gaane dhundo -------------------------
    fun scan(ctx: Context, done: () -> Unit) {
        val app = ctx.applicationContext
        appCtx = app
        Thread {
            val out = ArrayList<Track>()
            try {
                val a = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                val proj = arrayOf(
                    MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION
                )
                val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 30000"
                app.contentResolver.query(a, proj, sel, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        val artist = c.getString(2)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Unknown artist"
                        out.add(Track(id, c.getString(1) ?: "Unknown", artist, c.getString(3) ?: "",
                            c.getLong(4), c.getLong(5), ContentUris.withAppendedId(a, id)))
                    }
                }
            } catch (e: Exception) { }
            out.sortBy { it.title.lowercase() }
            main.post {
                tracks = out
                if (queue.isEmpty()) queue = out
                changed(); done()
            }
        }.start()
    }

    // ------------------------- chalao / roko -------------------------
    fun play(ctx: Context, list: List<Track>, idx: Int) {
        if (idx !in list.indices) return
        appCtx = ctx.applicationContext
        queue = list; index = idx
        start()
    }

    private fun start() {
        val ctx = appCtx ?: return
        val t = current ?: return
        release()
        requestFocus(ctx)
        try {
            val m = MediaPlayer()
            m.setAudioAttributes(attrs)
            m.setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK)
            m.setDataSource(ctx, t.uri)
            m.setOnPreparedListener { it.start(); prepared = true; isPlaying = true; changed() }
            m.setOnCompletionListener { onDone() }
            m.setOnErrorListener { _, _, _ -> prepared = false; isPlaying = false; changed(); true }
            m.prepareAsync()
            mp = m
        } catch (e: Exception) { isPlaying = false; prepared = false }
        loadArtAsync(ctx, t)
        try { ContextCompat.startForegroundService(ctx, Intent(ctx, MusicService::class.java)) } catch (e: Exception) { }
        changed()
    }

    private fun release() {
        prepared = false
        try { mp?.release() } catch (e: Exception) { }
        mp = null
    }

    fun pause() {
        try { if (prepared) mp?.pause() } catch (e: Exception) { }
        isPlaying = false; changed()
    }

    fun resume() {
        val ctx = appCtx ?: return
        if (!prepared) { start(); return }
        requestFocus(ctx)
        try { mp?.start() } catch (e: Exception) { }
        isPlaying = true; changed()
    }

    fun toggle() {
        if (queue.isEmpty() && tracks.isNotEmpty()) queue = tracks
        if (current == null) { if (queue.isNotEmpty()) { index = 0; start() }; return }
        if (isPlaying) pause() else resume()
    }

    /** Headset / bluetooth ke play-pause button ke liye */
    fun toggleTo(play: Boolean) { if (play != isPlaying) toggle() }

    fun next() {
        if (queue.isEmpty()) return
        index = if (shuffle && queue.size > 1) {
            var r = queue.indices.random()
            while (r == index) r = queue.indices.random()
            r
        } else (index + 1) % queue.size
        start()
    }

    fun prev() {
        if (queue.isEmpty()) return
        if (position() > 3000) { seekTo(0); return }
        index = if (index - 1 < 0) queue.size - 1 else index - 1
        start()
    }

    private fun onDone() {
        when {
            repeat == 2 -> start()
            repeat == 0 && !shuffle && index >= queue.size - 1 -> {
                // playlist khatam
                isPlaying = false; prepared = false; changed()
            }
            else -> next()
        }
    }

    fun seekTo(ms: Int) {
        try { if (prepared) mp?.seekTo(ms) } catch (e: Exception) { }
        changed()
    }

    fun position(): Int = try { if (prepared) mp?.currentPosition ?: 0 else 0 } catch (e: Exception) { 0 }

    fun stopAll() {
        release(); isPlaying = false
        try {
            val am = appCtx?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            focusReq?.let { am?.abandonAudioFocusRequest(it) }
        } catch (e: Exception) { }
        changed()
    }

    // ------------------------- audio focus -------------------------
    private fun requestFocus(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val req = focusReq ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(attrs)
                .setOnAudioFocusChangeListener({ change ->
                    when (change) {
                        AudioManager.AUDIOFOCUS_LOSS -> { resumeOnFocus = false; pause() }
                        AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> { resumeOnFocus = isPlaying; pause() }
                        AudioManager.AUDIOFOCUS_GAIN -> { if (resumeOnFocus) { resumeOnFocus = false; resume() } }
                        else -> { }
                    }
                }, main)
                .build().also { focusReq = it }
            am.requestAudioFocus(req)
        } catch (e: Exception) { }
    }

    // ------------------------- album art -------------------------
    private fun loadArtAsync(ctx: Context, t: Track) {
        if (artFor == t.id) return
        artFor = t.id; art = null
        Thread {
            val b = loadArt(ctx, t, 600)
            main.post { if (current?.id == t.id) { art = b; changed() } }
        }.start()
    }

    // ------------------------- favourites (dil wale gaane) -------------------------
    private var favCache: MutableSet<Long>? = null
    private fun favPrefs(c: Context) = c.applicationContext.getSharedPreferences("music", Context.MODE_PRIVATE)
    private fun favSet(c: Context): MutableSet<Long> {
        favCache?.let { return it }
        val s = (favPrefs(c).getString("favs", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }.toMutableSet()
        favCache = s
        return s
    }
    fun favs(c: Context): Set<Long> = favSet(c)
    fun isFav(c: Context, id: Long): Boolean = favSet(c).contains(id)
    /** true = ab favourite hai */
    fun toggleFav(c: Context, id: Long): Boolean {
        val s = favSet(c)
        val now = if (s.contains(id)) { s.remove(id); false } else { s.add(id); true }
        favPrefs(c).edit().putString("favs", s.joinToString(",")).apply()
        changed()
        return now
    }

    // ------------------------- list ke chhote thumbnails -------------------------
    private val thumbCache = android.util.LruCache<Long, Bitmap>(90)
    private val noArt = HashSet<Long>()                       // jin gaano mein art hai hi nahi
    private val thumbPool = java.util.concurrent.Executors.newFixedThreadPool(2)

    fun cachedThumb(id: Long): Bitmap? = thumbCache.get(id)

    /** Chhota album art (cache ke saath). cb main thread par aata hai; art na ho to null */
    fun thumb(ctx: Context, t: Track, px: Int, cb: (Bitmap?) -> Unit) {
        thumbCache.get(t.id)?.let { cb(it); return }
        if (noArt.contains(t.id)) { cb(null); return }
        val app = ctx.applicationContext
        thumbPool.execute {
            val b = loadArt(app, t, px)
            main.post {
                if (b != null) thumbCache.put(t.id, b) else noArt.add(t.id)
                cb(b)
            }
        }
    }

    fun loadArt(ctx: Context, t: Track, px: Int): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(t.uri, Size(px, px), null)
        else {
            val u = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), t.albumId)
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) }
        }
    } catch (e: Exception) { null }

    fun fmt(ms: Int): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(s / 60, s % 60)
    }
}
