package com.example.classiclauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.IBinder

/**
 * Gaana chalte waqt notification + lock screen / headset / bluetooth ke buttons (play, pause, next, prev).
 */
class MusicService : Service() {

    companion object {
        const val A_TOGGLE = "hanena.music.TOGGLE"
        const val A_NEXT = "hanena.music.NEXT"
        const val A_PREV = "hanena.music.PREV"
        const val A_STOP = "hanena.music.STOP"
    }

    private var session: MediaSession? = null

    private fun pi(action: String, code: Int): PendingIntent =
        PendingIntent.getService(this, code, Intent(this, MusicService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun build(): Notification {
        val t = MusicEngine.current
        val open = PendingIntent.getActivity(this, 9,
            Intent(this, MusicActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val playing = MusicEngine.isPlaying
        val b = Notification.Builder(this, "music")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(t?.title ?: "HaNeNa Music")
            .setContentText(t?.artist ?: "")
            .setContentIntent(open)
            .setDeleteIntent(pi(A_STOP, 4))
            .setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
        MusicEngine.art?.let { b.setLargeIcon(it) }
        b.addAction(Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_previous), "Peeche", pi(A_PREV, 1)).build())
        b.addAction(Notification.Action.Builder(
            Icon.createWithResource(this, if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play),
            if (playing) "Roko" else "Chalao", pi(A_TOGGLE, 2)).build())
        b.addAction(Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_next), "Aage", pi(A_NEXT, 3)).build())
        session?.let { s ->
            b.setStyle(Notification.MediaStyle().setMediaSession(s.sessionToken).setShowActionsInCompactView(0, 1, 2))
        }
        return b.build()
    }

    private fun refresh() {
        val t = MusicEngine.current
        val playing = MusicEngine.isPlaying
        session?.setMetadata(MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, t?.title ?: "")
            .putString(MediaMetadata.METADATA_KEY_ARTIST, t?.artist ?: "")
            .putLong(MediaMetadata.METADATA_KEY_DURATION, t?.dur ?: 0L)
            .apply { MusicEngine.art?.let { putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, it) } }
            .build())
        session?.setPlaybackState(PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO)
            .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                MusicEngine.position().toLong(), if (playing) 1f else 0f)
            .build())
        val n = build()
        var fg = false
        if (playing) { try { startForeground(2, n); fg = true } catch (e: Exception) { } }
        if (!fg) {
            stopForeground(STOP_FOREGROUND_DETACH)      // ruke hue gaane ki notification swipe se hat sakti hai
            getSystemService(NotificationManager::class.java).notify(2, n)
        }
    }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("music", "HaNeNa Music", NotificationManager.IMPORTANCE_LOW))
        session = MediaSession(this, "HaNeNaMusic").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() { MusicEngine.toggleTo(true) }
                override fun onPause() { MusicEngine.toggleTo(false) }
                override fun onSkipToNext() { MusicEngine.next() }
                override fun onSkipToPrevious() { MusicEngine.prev() }
                override fun onSeekTo(pos: Long) { MusicEngine.seekTo(pos.toInt()) }
            })
            isActive = true
        }
        startForeground(2, build())
        MusicEngine.listen(this) { refresh() }
        refresh()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            A_TOGGLE -> MusicEngine.toggle()
            A_NEXT -> MusicEngine.next()
            A_PREV -> MusicEngine.prev()
            A_STOP -> {
                MusicEngine.unlisten(this)
                MusicEngine.stopAll()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
            else -> startForeground(2, build())   // startForegroundService ka wada poora karo
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        MusicEngine.unlisten(this)
        try { session?.release() } catch (e: Exception) { }
        super.onDestroy()
    }
}
