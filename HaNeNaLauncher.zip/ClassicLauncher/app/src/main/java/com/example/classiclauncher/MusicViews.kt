package com.example.classiclauncher

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import kotlin.math.min
import kotlin.math.sin

private fun withAlpha(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

/** Canvas se bane chhote icons (play, pause, next...), koi image file nahi chahiye */
class IconBtn(ctx: Context, var kind: Int) : View(ctx) {
    companion object {
        const val PLAY = 0; const val PAUSE = 1; const val NEXT = 2; const val PREV = 3
        const val SHUFFLE = 4; const val REPEAT = 5; const val REPEAT_ONE = 6; const val LIST = 7
        const val BACK = 8; const val NOTE = 9; const val STYLE = 10; const val DEL = 11; const val LOCK = 12
        const val GEAR = 13; const val REW = 14; const val FWD = 15; const val ROTATE = 16; const val CALL = 17
        const val MSG = 18; const val SEND = 19; const val VIDEO = 20; const val PERSON = 21; const val CLOCKI = 22
        const val CLOSE = 23; const val DIALPAD = 24; const val FIT = 25
    }

    var color = Color.WHITE
    var ring = false
    var dim = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rf = RectF()

    init { isClickable = true }

    override fun setPressed(pressed: Boolean) {
        super.setPressed(pressed)
        val k = if (pressed) 0.86f else 1f
        scaleX = k; scaleY = k
    }

    private fun tri(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float, c: Canvas) {
        path.reset(); path.moveTo(x1, y1); path.lineTo(x2, y2); path.lineTo(x3, y3); path.close()
        c.drawPath(path, p)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = min(w, h); val cx = w / 2f; val cy = h / 2f
        p.shader = null; p.color = color; p.alpha = if (dim) 100 else 255
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        if (ring) {
            p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.045f
            c.drawCircle(cx, cy, s / 2f - s * 0.03f, p)
        }
        p.style = Paint.Style.FILL
        val u = s * (if (ring) 0.2f else 0.28f)
        val sw = s * 0.075f
        when (kind) {
            PLAY -> tri(cx - u * 0.6f, cy - u, cx + u * 0.95f, cy, cx - u * 0.6f, cy + u, c)
            PAUSE -> {
                val bw = u * 0.62f
                rf.set(cx - u * 0.8f, cy - u, cx - u * 0.8f + bw, cy + u); c.drawRoundRect(rf, bw / 3f, bw / 3f, p)
                rf.set(cx + u * 0.8f - bw, cy - u, cx + u * 0.8f, cy + u); c.drawRoundRect(rf, bw / 3f, bw / 3f, p)
            }
            NEXT -> {
                tri(cx - u, cy - u * 0.9f, cx + u * 0.45f, cy, cx - u, cy + u * 0.9f, c)
                rf.set(cx + u * 0.62f, cy - u * 0.9f, cx + u * 0.96f, cy + u * 0.9f); c.drawRoundRect(rf, u * 0.12f, u * 0.12f, p)
            }
            PREV -> {
                tri(cx + u, cy - u * 0.9f, cx - u * 0.45f, cy, cx + u, cy + u * 0.9f, c)
                rf.set(cx - u * 0.96f, cy - u * 0.9f, cx - u * 0.62f, cy + u * 0.9f); c.drawRoundRect(rf, u * 0.12f, u * 0.12f, p)
            }
            SHUFFLE -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw
                c.drawLine(cx - u, cy - u * 0.6f, cx + u * 0.5f, cy + u * 0.6f, p)
                c.drawLine(cx - u, cy + u * 0.6f, cx + u * 0.5f, cy - u * 0.6f, p)
                p.style = Paint.Style.FILL
                tri(cx + u * 0.35f, cy - u * 1.05f, cx + u, cy - u * 0.6f, cx + u * 0.35f, cy - u * 0.15f, c)
                tri(cx + u * 0.35f, cy + u * 0.15f, cx + u, cy + u * 0.6f, cx + u * 0.35f, cy + u * 1.05f, c)
            }
            REPEAT, REPEAT_ONE -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw
                rf.set(cx - u, cy - u * 0.55f, cx + u, cy + u * 0.55f); c.drawRoundRect(rf, u * 0.5f, u * 0.5f, p)
                p.style = Paint.Style.FILL
                tri(cx + u * 0.2f, cy - u * 0.93f, cx + u * 0.7f, cy - u * 0.55f, cx + u * 0.2f, cy - u * 0.17f, c)
                if (kind == REPEAT_ONE) {
                    p.textAlign = Paint.Align.CENTER; p.textSize = u * 1.0f; p.typeface = Typeface.DEFAULT_BOLD
                    c.drawText("1", cx, cy + u * 0.35f, p)
                }
            }
            LIST -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw
                for (k in -1..1) c.drawLine(cx - u, cy + k * u * 0.7f, cx + u, cy + k * u * 0.7f, p)
            }
            BACK -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw * 1.2f
                path.reset(); path.moveTo(cx + u * 0.4f, cy - u); path.lineTo(cx - u * 0.4f, cy); path.lineTo(cx + u * 0.4f, cy + u)
                c.drawPath(path, p)
            }
            NOTE -> {
                c.drawCircle(cx - u * 0.35f, cy + u * 0.55f, u * 0.45f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.09f
                c.drawLine(cx + u * 0.08f, cy + u * 0.5f, cx + u * 0.08f, cy - u * 0.9f, p)
                c.drawLine(cx + u * 0.08f, cy - u * 0.9f, cx + u * 0.75f, cy - u * 0.35f, p)
            }
            DEL -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw
                path.reset(); path.moveTo(cx - u, cy); path.lineTo(cx - u * 0.35f, cy - u * 0.8f); path.lineTo(cx + u, cy - u * 0.8f)
                path.lineTo(cx + u, cy + u * 0.8f); path.lineTo(cx - u * 0.35f, cy + u * 0.8f); path.close()
                c.drawPath(path, p)
                c.drawLine(cx + u * 0.05f, cy - u * 0.28f, cx + u * 0.6f, cy + u * 0.28f, p)
                c.drawLine(cx + u * 0.05f, cy + u * 0.28f, cx + u * 0.6f, cy - u * 0.28f, p)
            }
            LOCK -> {
                rf.set(cx - u * 0.8f, cy - u * 0.05f, cx + u * 0.8f, cy + u * 0.95f)
                c.drawRoundRect(rf, u * 0.22f, u * 0.22f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = sw
                rf.set(cx - u * 0.5f, cy - u * 1.0f, cx + u * 0.5f, cy + u * 0.1f)
                c.drawArc(rf, 180f, 180f, false, p)
                p.style = Paint.Style.FILL; p.color = Color.BLACK; p.alpha = 220
                c.drawCircle(cx, cy + u * 0.4f, u * 0.14f, p)
            }
            GEAR -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw
                c.drawCircle(cx, cy, u * 0.55f, p)
                for (k in 0 until 8) {
                    val a = Math.toRadians(k * 45.0)
                    c.drawLine(cx + (u * 0.8f * Math.cos(a)).toFloat(), cy + (u * 0.8f * Math.sin(a)).toFloat(),
                        cx + (u * 1.05f * Math.cos(a)).toFloat(), cy + (u * 1.05f * Math.sin(a)).toFloat(), p)
                }
            }
            REW, FWD, ROTATE -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw
                val dirn = if (kind == REW) -1f else 1f
                c.save(); c.scale(dirn, 1f, cx, cy)
                rf.set(cx - u, cy - u, cx + u, cy + u)
                c.drawArc(rf, -60f, 280f, false, p)
                p.style = Paint.Style.FILL
                tri(cx + u * 0.15f, cy - u * 1.45f, cx + u * 0.15f, cy - u * 0.55f, cx + u * 0.95f, cy - u, c)
                c.restore()
                if (kind != ROTATE) {
                    p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER; p.textSize = u * 0.9f
                    p.typeface = Typeface.DEFAULT_BOLD
                    c.drawText("10", cx, cy + u * 0.32f, p)
                }
            }
            CALL -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = u * 0.62f
                rf.set(cx - u * 0.95f, cy - u * 0.95f, cx + u * 0.95f, cy + u * 0.95f)
                c.drawArc(rf, 102f, 66f, false, p)
            }
            MSG -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw
                rf.set(cx - u, cy - u * 0.8f, cx + u, cy + u * 0.55f); c.drawRoundRect(rf, u * 0.4f, u * 0.4f, p)
                p.style = Paint.Style.FILL
                tri(cx - u * 0.5f, cy + u * 0.5f, cx - u * 0.5f, cy + u * 1.05f, cx + u * 0.05f, cy + u * 0.5f, c)
                for (k in -1..1) c.drawCircle(cx + k * u * 0.5f, cy - u * 0.12f, u * 0.1f, p)
            }
            SEND -> {
                path.reset(); path.moveTo(cx - u, cy - u * 0.85f); path.lineTo(cx + u, cy)
                path.lineTo(cx - u, cy + u * 0.85f); path.lineTo(cx - u * 0.4f, cy); path.close()
                c.drawPath(path, p)
            }
            VIDEO -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw
                rf.set(cx - u, cy - u * 0.75f, cx + u, cy + u * 0.75f); c.drawRoundRect(rf, u * 0.3f, u * 0.3f, p)
                p.style = Paint.Style.FILL
                tri(cx - u * 0.25f, cy - u * 0.38f, cx + u * 0.42f, cy, cx - u * 0.25f, cy + u * 0.38f, c)
            }
            PERSON -> {
                c.drawCircle(cx, cy - u * 0.4f, u * 0.38f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = sw
                rf.set(cx - u * 0.8f, cy + u * 0.1f, cx + u * 0.8f, cy + u * 1.6f); c.drawArc(rf, 180f, 180f, false, p)
            }
            CLOCKI -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw
                c.drawCircle(cx, cy, u, p)
                c.drawLine(cx, cy, cx, cy - u * 0.62f, p); c.drawLine(cx, cy, cx + u * 0.45f, cy + u * 0.2f, p)
            }
            CLOSE -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw * 1.2f
                c.drawLine(cx - u * 0.8f, cy - u * 0.8f, cx + u * 0.8f, cy + u * 0.8f, p)
                c.drawLine(cx - u * 0.8f, cy + u * 0.8f, cx + u * 0.8f, cy - u * 0.8f, p)
            }
            DIALPAD -> {
                for (r in -1..1) for (q in -1..1) c.drawCircle(cx + q * u * 0.7f, cy + r * u * 0.7f, u * 0.17f, p)
            }
            FIT -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw
                rf.set(cx - u, cy - u * 0.7f, cx + u, cy + u * 0.7f); c.drawRoundRect(rf, u * 0.18f, u * 0.18f, p)
                c.drawLine(cx - u * 0.45f, cy, cx + u * 0.45f, cy, p)
            }
            else -> {   // STYLE: equalizer jaisi teen patti
                val bw = u * 0.5f
                rf.set(cx - u * 0.95f, cy - u * 0.2f, cx - u * 0.95f + bw, cy + u); c.drawRoundRect(rf, bw / 2f, bw / 2f, p)
                rf.set(cx - bw / 2f, cy - u, cx + bw / 2f, cy + u); c.drawRoundRect(rf, bw / 2f, bw / 2f, p)
                rf.set(cx + u * 0.95f - bw, cy - u * 0.5f, cx + u * 0.95f, cy + u); c.drawRoundRect(rf, bw / 2f, bw / 2f, p)
            }
        }
    }
}

/** Gaana chalte waqt naachti equalizer patti (asli awaaz nahi, sirf animation) */
class BarsView(ctx: Context) : View(ctx) {
    var color = Color.WHITE
    var color2 = 0
    var mirror = false
    var active = false
        set(v) { field = v; invalidate() }

    private val n = 28
    private val sp = FloatArray(n) { 0.0016f + 0.0011f * ((it * 37) % 11) / 11f }
    private val ph = FloatArray(n) { it * 0.9f }
    private var level = 0f
    private var lastT = 0L
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private val d = resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastT == 0L) 16L else min(now - lastT, 64L)
        lastT = now
        level += ((if (active) 1f else 0f) - level) * min(1f, dt / 180f)
        val w = width.toFloat(); val h = height.toFloat()
        val gap = w / n; val bw = gap * 0.56f
        for (i in 0 until n) {
            val v = 0.5f + 0.5f * sin(now * sp[i] + ph[i]) * (0.55f + 0.45f * sin(now * 0.0009f + i * 0.4f))
            val bh = (h * (0.08f + 0.92f * v * level)).coerceAtLeast(3f * d)
            val x = gap * i + (gap - bw) / 2f
            p.color = if (color2 != 0) ColorUtils.blendARGB(color, color2, i / (n - 1f)) else color
            p.alpha = (140 + 115 * v).toInt()
            if (mirror) rf.set(x, (h - bh) / 2f, x + bw, (h + bh) / 2f) else rf.set(x, h - bh, x + bw, h)
            c.drawRoundRect(rf, bw / 2f, bw / 2f, p)
        }
        if (active || level > 0.02f) postInvalidateOnAnimation() else lastT = 0L
    }
}

/**
 * Album art ke 3 style: 0 = ghoomta vinyl record, 1 = neon glow wala card, 2 = saaf glass card.
 */
class ArtView(ctx: Context) : View(ctx) {
    var style = 0
        set(v) { field = v; shader = null; invalidate() }
    var accent = Color.WHITE
    var accent2 = 0
    var playing = false
        set(v) { field = v; invalidate() }

    private var bmp: Bitmap? = null
    private var shader: BitmapShader? = null
    private val m = Matrix()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private val path = Path()
    private val d = resources.displayMetrics.density
    private var spin = 0f
    private var lastT = 0L

    fun setArt(b: Bitmap?) { if (b === bmp) return; bmp = b; shader = null; invalidate() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { shader = null }

    private fun tone(): Int = accent

    private fun makeShader(left: Float, top: Float, size: Float) {
        val b = bmp ?: return
        val sh = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val sc = size / min(b.width, b.height).toFloat()
        m.reset(); m.setScale(sc, sc)
        m.postTranslate(left - (b.width * sc - size) / 2f, top - (b.height * sc - size) / 2f)
        sh.setLocalMatrix(m)
        shader = sh
    }

    /** Art ko shape mein bharo (circle ya rounded square); art na ho to saada placeholder */
    private fun fillArt(c: Canvas, left: Float, top: Float, size: Float, corner: Float, circle: Boolean) {
        if (bmp != null && shader == null) makeShader(left, top, size)
        p.style = Paint.Style.FILL
        if (shader != null) { p.shader = shader }
        else { p.shader = null; p.color = Color.argb(255, 24, 24, 28) }
        if (circle) c.drawCircle(left + size / 2f, top + size / 2f, size / 2f, p)
        else { rf.set(left, top, left + size, top + size); c.drawRoundRect(rf, corner, corner, p) }
        p.shader = null
        if (bmp == null) {   // placeholder par sunehri note
            val u = size * 0.16f; val cx = left + size / 2f; val cy = top + size / 2f
            p.color = withAlpha(tone(), 200); p.style = Paint.Style.FILL
            c.drawCircle(cx - u * 0.35f, cy + u * 0.55f, u * 0.45f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = size * 0.035f; p.strokeCap = Paint.Cap.ROUND
            c.drawLine(cx + u * 0.08f, cy + u * 0.5f, cx + u * 0.08f, cy - u * 0.9f, p)
            c.drawLine(cx + u * 0.08f, cy - u * 0.9f, cx + u * 0.75f, cy - u * 0.35f, p)
            p.style = Paint.Style.FILL
        }
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastT == 0L) 0L else min(now - lastT, 64L)
        lastT = if (playing) now else 0L
        val w = width.toFloat(); val h = height.toFloat()
        val s = min(w, h); val cx = w / 2f; val cy = h / 2f

        when (style) {
            0 -> {
                if (playing) spin = (spin + dt * 0.032f) % 360f
                val dd = s * 0.96f; val a = dd * 0.58f
                c.save(); c.rotate(spin, cx, cy)
                p.shader = null; p.style = Paint.Style.FILL; p.color = Color.rgb(11, 11, 13)
                c.drawCircle(cx, cy, dd / 2f, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 1f * d; p.color = Color.argb(26, 255, 255, 255)
                var r = a / 2f + 5f * d
                while (r < dd / 2f - 4f * d) { c.drawCircle(cx, cy, r, p); r += 6f * d }
                p.strokeWidth = 9f * d; p.color = Color.argb(16, 255, 255, 255)
                rf.set(cx - dd * 0.36f, cy - dd * 0.36f, cx + dd * 0.36f, cy + dd * 0.36f)
                c.drawArc(rf, 200f, 42f, false, p); c.drawArc(rf, 20f, 42f, false, p)
                p.strokeWidth = 2f * d; p.color = withAlpha(tone(), 210)
                c.drawCircle(cx, cy, dd / 2f - 1f * d, p)
                fillArt(c, cx - a / 2f, cy - a / 2f, a, 0f, true)
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f * d; p.color = withAlpha(tone(), 160)
                c.drawCircle(cx, cy, a / 2f, p)
                p.style = Paint.Style.FILL; p.color = Color.BLACK
                c.drawCircle(cx, cy, a * 0.07f, p)
                c.restore()
                if (playing) postInvalidateOnAnimation()
            }
            1 -> {
                val side = s * 0.88f; val l = cx - side / 2f; val t = cy - side / 2f; val corner = side * 0.14f
                val pulse = if (playing) 0.55f + 0.45f * sin(now / 420f) else 0.45f
                val glow = if (accent2 != 0) ColorUtils.blendARGB(accent, accent2, 0.5f + 0.5f * sin(now / 1500f)) else accent
                p.shader = null; p.style = Paint.Style.STROKE
                for (k in 3 downTo 0) {
                    p.strokeWidth = (3f + k * 5f) * d
                    p.color = withAlpha(glow, ((70 - k * 14) * pulse).toInt())
                    rf.set(l, t, l + side, t + side); c.drawRoundRect(rf, corner, corner, p)
                }
                fillArt(c, l, t, side, corner, false)
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f * d; p.color = withAlpha(glow, 235)
                rf.set(l, t, l + side, t + side); c.drawRoundRect(rf, corner, corner, p)
                if (playing) postInvalidateOnAnimation()
            }
            else -> {
                val side = s * 0.94f; val l = cx - side / 2f; val t = cy - side / 2f; val corner = side * 0.1f
                fillArt(c, l, t, side, corner, false)
                p.style = Paint.Style.STROKE; p.strokeWidth = 1f * d; p.color = Color.argb(70, 255, 255, 255)
                rf.set(l, t, l + side, t + side); c.drawRoundRect(rf, corner, corner, p)
            }
        }
    }
}

/** Lock screen ke chhote card ke liye patli progress line */
class ThinProgress(ctx: Context) : View(ctx) {
    var frac = 0f
        set(v) { field = v; invalidate() }
    var color = Color.WHITE
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.color = Color.argb(60, 255, 255, 255); rf.set(0f, 0f, w, h); c.drawRoundRect(rf, h / 2f, h / 2f, p)
        p.color = color; rf.set(0f, 0f, (w * frac).coerceAtLeast(h), h); c.drawRoundRect(rf, h / 2f, h / 2f, p)
    }
}

/**
 * Music player ka dil. compact = false: poori screen ka player. compact = true: lock screen ka chhota card.
 * style 0 = Vinyl, 1 = Neon bars, 2 = Glass card.
 */
class MusicPanel(
    ctx: Context, private val style: Int, private val compact: Boolean,
    private val accent: Int, private val accent2: Int, private val textC: Int,
    private val tf: Typeface, private val script: Typeface
) : LinearLayout(ctx) {

    private val d = resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    private val art = ArtView(ctx)
    private val bars = BarsView(ctx)
    private val title = TextView(ctx)
    private val artist = TextView(ctx)
    private val play = IconBtn(ctx, IconBtn.PLAY)
    private val prev = IconBtn(ctx, IconBtn.PREV)
    private val next = IconBtn(ctx, IconBtn.NEXT)
    private val shuf = IconBtn(ctx, IconBtn.SHUFFLE)
    private val rep = IconBtn(ctx, IconBtn.REPEAT)
    private val seekBar = SeekBar(ctx)
    private val thin = ThinProgress(ctx)
    private val cur = TextView(ctx)
    private val tot = TextView(ctx)
    private var seeking = false
    private val hnd = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable { override fun run() { tick(); hnd.postDelayed(this, 500) } }

    init {
        art.style = style; art.accent = accent; art.accent2 = accent2
        bars.color = accent; bars.color2 = accent2; bars.mirror = style == 1
        thin.color = accent
        listOf(prev, next, shuf, rep).forEach { it.color = textC }
        play.color = accent; play.ring = true
        play.setOnClickListener { MusicEngine.toggle() }
        prev.setOnClickListener { MusicEngine.prev() }
        next.setOnClickListener { MusicEngine.next() }
        shuf.setOnClickListener { MusicEngine.shuffle = !MusicEngine.shuffle; bind() }
        rep.setOnClickListener { MusicEngine.repeat = (MusicEngine.repeat + 1) % 3; bind() }
        for (t in listOf(title, artist)) {
            t.setSingleLine(true); t.ellipsize = TextUtils.TruncateAt.MARQUEE
            t.marqueeRepeatLimit = -1; t.isSelected = true
        }
        if (compact) buildCompact() else buildFull()
        bind()
    }

    private fun lp(w: Int, h: Int) = LayoutParams(w, h)

    private fun buildFull() {
        orientation = VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        val sw = resources.displayMetrics.widthPixels
        val artSize = (sw * 0.76f).toInt()
        addView(art, lp(artSize, artSize))

        val barH = when (style) { 0 -> dp(30); 1 -> dp(70); else -> 0 }
        if (barH > 0) addView(bars, lp(artSize, barH).apply { topMargin = dp(12) })

        title.typeface = script; title.textSize = 28f; title.setTextColor(textC); title.gravity = Gravity.CENTER
        artist.typeface = tf; artist.textSize = 15f; artist.setTextColor(accent); artist.gravity = Gravity.CENTER
        artist.letterSpacing = 0.05f
        addView(title, lp(-1, -2).apply { topMargin = dp(14); marginStart = dp(26); marginEnd = dp(26) })
        addView(artist, lp(-1, -2).apply { topMargin = dp(2); marginStart = dp(26); marginEnd = dp(26) })

        for (t in listOf(cur, tot)) { t.textSize = 12f; t.setTextColor(Color.argb(190, 255, 255, 255)); t.typeface = tf }
        cur.text = "0:00"
        seekBar.max = 1000
        seekBar.progressTintList = ColorStateList.valueOf(accent)
        seekBar.thumbTintList = ColorStateList.valueOf(accent)
        seekBar.progressBackgroundTintList = ColorStateList.valueOf(Color.argb(70, 255, 255, 255))
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, pr: Int, user: Boolean) {
                if (user) cur.text = MusicEngine.fmt((pr / 1000f * (MusicEngine.current?.dur ?: 0L)).toInt())
            }
            override fun onStartTrackingTouch(s: SeekBar?) { seeking = true }
            override fun onStopTrackingTouch(s: SeekBar?) {
                seeking = false
                val dur = MusicEngine.current?.dur ?: 0L
                MusicEngine.seekTo(((s?.progress ?: 0) / 1000f * dur).toInt())
            }
        })
        val row = LinearLayout(context).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(cur, LinearLayout.LayoutParams(-2, -2))
            addView(seekBar, LinearLayout.LayoutParams(0, -2, 1f))
            addView(tot, LinearLayout.LayoutParams(-2, -2))
        }
        addView(row, lp(-1, -2).apply { topMargin = dp(12); marginStart = dp(22); marginEnd = dp(22) })

        val ctl = LinearLayout(context).apply {
            gravity = Gravity.CENTER
            addView(shuf, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(prev, LinearLayout.LayoutParams(dp(56), dp(56)))
            addView(play, LinearLayout.LayoutParams(dp(76), dp(76)).apply { marginStart = dp(10); marginEnd = dp(10) })
            addView(next, LinearLayout.LayoutParams(dp(56), dp(56)))
            addView(rep, LinearLayout.LayoutParams(dp(44), dp(44)))
        }
        addView(ctl, lp(-1, -2).apply { topMargin = dp(6) })
    }

    private fun buildCompact() {
        orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), dp(10), dp(8), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(24).toFloat()
            setColor(Color.argb(if (style == 2) 120 else 150, 0, 0, 0))
            setStroke(dp(if (style == 1) 2 else 1), withAlpha(accent, if (style == 1) 210 else 95))
        }
        addView(art, lp(dp(58), dp(58)))
        title.typeface = tf; title.textSize = 15f; title.setTextColor(textC)
        artist.typeface = tf; artist.textSize = 12f; artist.setTextColor(accent)
        val mid = LinearLayout(context).apply {
            orientation = VERTICAL
            addView(title, LinearLayout.LayoutParams(-1, -2))
            addView(artist, LinearLayout.LayoutParams(-1, -2))
            addView(thin, LinearLayout.LayoutParams(-1, dp(3)).apply { topMargin = dp(7) })
            if (style == 1) addView(bars, LinearLayout.LayoutParams(-1, dp(14)).apply { topMargin = dp(6) })
        }
        addView(mid, lp(0, -2).apply { weight = 1f; marginStart = dp(12); marginEnd = dp(6) })
        addView(prev, lp(dp(36), dp(36)))
        addView(play, lp(dp(46), dp(46)))
        addView(next, lp(dp(36), dp(36)))
    }

    /** Engine ki halat ke hisab se sab kuch naya dikhao */
    fun bind() {
        val t = MusicEngine.current
        val on = MusicEngine.isPlaying
        title.text = t?.title ?: "Koi gaana nahi chal raha"
        artist.text = t?.artist ?: "List se gaana chuno"
        art.setArt(MusicEngine.art); art.playing = on
        bars.active = on
        play.kind = if (on) IconBtn.PAUSE else IconBtn.PLAY; play.invalidate()
        shuf.dim = !MusicEngine.shuffle; shuf.invalidate()
        rep.kind = if (MusicEngine.repeat == 2) IconBtn.REPEAT_ONE else IconBtn.REPEAT
        rep.dim = MusicEngine.repeat == 0; rep.invalidate()
        tot.text = MusicEngine.fmt((t?.dur ?: 0L).toInt())
        tick()
    }

    private fun tick() {
        val dur = (MusicEngine.current?.dur ?: 0L).toInt().coerceAtLeast(1)
        val pos = MusicEngine.position()
        val f = (pos.toFloat() / dur).coerceIn(0f, 1f)
        if (compact) thin.frac = f
        else if (!seeking) { seekBar.progress = (f * 1000).toInt(); cur.text = MusicEngine.fmt(pos) }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        MusicEngine.listen(this) { bind() }
        bind()
        hnd.removeCallbacks(ticker); hnd.postDelayed(ticker, 500)
    }

    override fun onDetachedFromWindow() {
        MusicEngine.unlisten(this)
        hnd.removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }
}

/** Gaano ki list ke liye chhota rounded album art; abhi chalta gaana ho to upar naachti patti */
class ThumbView(ctx: Context) : View(ctx) {
    var accent = Color.WHITE
    var current = false
    var playing = false

    private var bmp: Bitmap? = null
    private var shader: BitmapShader? = null
    private val m = Matrix()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private val d = resources.displayMetrics.density

    fun setBmp(b: Bitmap?) { if (b !== bmp) { bmp = b; shader = null }; invalidate() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { shader = null }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val rad = min(w, h) * 0.26f
        rf.set(0f, 0f, w, h)
        val b = bmp
        p.style = Paint.Style.FILL
        if (b != null) {
            if (shader == null) {
                val sh = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                val sc = maxOf(w / b.width, h / b.height)
                m.reset(); m.setScale(sc, sc); m.postTranslate((w - b.width * sc) / 2f, (h - b.height * sc) / 2f)
                sh.setLocalMatrix(m); shader = sh
            }
            p.shader = shader; c.drawRoundRect(rf, rad, rad, p); p.shader = null
        } else {
            p.shader = null; p.color = Color.rgb(30, 30, 36); c.drawRoundRect(rf, rad, rad, p)
            val u = w * 0.17f; val cx = w / 2f; val cy = h / 2f
            p.color = withAlpha(accent, 190)
            c.drawCircle(cx - u * 0.35f, cy + u * 0.55f, u * 0.45f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = w * 0.045f; p.strokeCap = Paint.Cap.ROUND
            c.drawLine(cx + u * 0.08f, cy + u * 0.5f, cx + u * 0.08f, cy - u * 0.9f, p)
            c.drawLine(cx + u * 0.08f, cy - u * 0.9f, cx + u * 0.75f, cy - u * 0.35f, p)
            p.style = Paint.Style.FILL
        }
        if (current) {
            p.color = Color.argb(150, 0, 0, 0); c.drawRoundRect(rf, rad, rad, p)
            val now = SystemClock.uptimeMillis()
            p.color = accent
            for (i in 0..2) {
                val v = if (playing) 0.3f + 0.7f * kotlin.math.abs(sin(now * (0.004f + 0.0016f * i) + i * 1.7f)) else 0.4f
                val bh = h * 0.40f * v
                val x = w * 0.5f + (i - 1) * w * 0.17f - w * 0.04f
                rf.set(x, h * 0.70f - bh, x + w * 0.08f, h * 0.70f)
                c.drawRoundRect(rf, w * 0.04f, w * 0.04f, p)
            }
            if (playing) postInvalidateOnAnimation()
        }
    }
}
