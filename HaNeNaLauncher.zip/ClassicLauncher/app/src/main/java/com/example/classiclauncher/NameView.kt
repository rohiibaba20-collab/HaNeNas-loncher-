package com.example.classiclauncher

import android.content.Context
import android.graphics.*
import android.view.View
import androidx.core.graphics.ColorUtils
import kotlin.math.max
import kotlin.math.sin

/** Naam (HaNeNa) ko wallpaper par khobsurat andaz mein dikhata hai */
class NameView(ctx: Context) : View(ctx) {
    var name = "HaNeNa"
    var nameStyle = 0
    var accent = Color.parseColor("#D4AF37")
    var accent2 = 0   // 0 = mix band; warna dono rang aapas mein dheere dheere badalte hain
    var textColor = Color.WHITE
    var scriptTf: Typeface = Typeface.DEFAULT
    var tf: Typeface = Typeface.DEFAULT
    var scale = 1f

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var fit = 1f      // jagah kam ho to naam khud chhota ho jata hai

    private fun txt() = if (nameStyle == 2 || nameStyle == 4) name.uppercase() else name

    private fun setup(): Float {
        p.reset(); p.isAntiAlias = true
        when (nameStyle) {
            0, 1, 3 -> { p.typeface = scriptTf; p.textSize = 52 * d * scale * fit }
            2 -> { p.typeface = tf; p.textSize = 22 * d * scale * fit; p.letterSpacing = 0.35f }
            else -> { p.typeface = tf; p.textSize = 20 * d * scale * fit; p.letterSpacing = 0.25f }
        }
        return p.measureText(txt())
    }

    private fun padX() = when (nameStyle) { 2 -> 130; 4 -> 50; 1 -> 70; 3 -> 50; else -> 40 } * d

    override fun onMeasure(w: Int, h: Int) {
        val mode = MeasureSpec.getMode(w)
        val maxW = if (mode == MeasureSpec.UNSPECIFIED) Int.MAX_VALUE else MeasureSpec.getSize(w)
        fit = 1f
        var tw = setup()
        val need = tw + padX()
        if (maxW in 1 until Int.MAX_VALUE && need > maxW) { fit = maxW / need; tw = setup() }
        val fm = p.fontMetrics
        // lambai font ke hisab se: upar-neeche glow aur ornament ke liye bhi jagah
        val extra = when (nameStyle) { 0 -> 30; 1 -> 76; 3 -> 44; 4 -> 40; else -> 34 } * d
        setMeasuredDimension((tw + padX()).toInt(), (fm.descent - fm.ascent + extra).toInt())
    }

    private fun a(c: Int, al: Int) = Color.argb(al, Color.red(c), Color.green(c), Color.blue(c))

    override fun onDraw(c: Canvas) {
        val accent = if (accent2 != 0)
            ColorUtils.blendARGB(this.accent, accent2, 0.5f + 0.5f * sin(System.nanoTime() / 1.4e9).toFloat())
        else this.accent
        val tw = setup(); val t = txt()
        val cx = width / 2f; val cy = height / 2f
        val fm = p.fontMetrics
        val base = cy - (fm.ascent + fm.descent) / 2f
        val x = cx - tw / 2f
        when (nameStyle) {
            0 -> {
                p.style = Paint.Style.FILL
                p.shader = LinearGradient(0f, base + fm.ascent, 0f, base + fm.descent,
                    intArrayOf(ColorUtils.blendARGB(accent, Color.WHITE, 0.55f), accent,
                        ColorUtils.blendARGB(accent, Color.BLACK, 0.35f)), null, Shader.TileMode.CLAMP)
                p.setShadowLayer(10 * d, 0f, 3 * d, Color.argb(170, 0, 0, 0))
                c.drawText(t, x, base, p)
                p.shader = null; p.clearShadowLayer()
                val ly = base + fm.descent + 4 * d
                p.strokeWidth = 1.5f * d
                p.shader = LinearGradient(cx - tw * 0.4f, 0f, cx + tw * 0.4f, 0f,
                    intArrayOf(a(accent, 0), accent, a(accent, 0)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
                c.drawLine(cx - tw * 0.4f, ly, cx + tw * 0.4f, ly, p)
                p.shader = null; p.color = accent; p.style = Paint.Style.FILL
                c.save(); c.rotate(45f, cx, ly)
                c.drawRect(cx - 3 * d, ly - 3 * d, cx + 3 * d, ly + 3 * d, p); c.restore()
            }
            1 -> {
                p.style = Paint.Style.FILL; p.color = accent
                p.setShadowLayer(28 * d, 0f, 0f, accent); c.drawText(t, x, base, p)
                p.setShadowLayer(12 * d, 0f, 0f, accent); c.drawText(t, x, base, p)
                p.clearShadowLayer(); p.color = ColorUtils.blendARGB(accent, Color.WHITE, 0.8f)
                c.drawText(t, x, base, p)
            }
            2 -> {
                p.style = Paint.Style.FILL; p.color = accent
                p.setShadowLayer(6 * d, 0f, 2 * d, Color.argb(160, 0, 0, 0))
                c.drawText(t, x, base, p); p.clearShadowLayer()
                p.strokeWidth = 1.5f * d
                c.drawLine(x - 16 * d, cy, x - 58 * d, cy, p)
                c.drawLine(x + tw + 16 * d, cy, x + tw + 58 * d, cy, p)
                c.drawCircle(x - 62 * d, cy, 2.5f * d, p)
                c.drawCircle(x + tw + 62 * d, cy, 2.5f * d, p)
            }
            3 -> {
                p.style = Paint.Style.FILL; p.color = a(accent, 45); c.drawText(t, x, base, p)
                p.style = Paint.Style.STROKE; p.strokeWidth = 1.8f * d; p.color = accent
                p.setShadowLayer(10 * d, 0f, 0f, a(accent, 200)); c.drawText(t, x, base, p)
            }
            else -> {
                val hh = (fm.descent - fm.ascent) / 2f
                val r = RectF(cx - tw / 2f - 20 * d, cy - hh - 10 * d, cx + tw / 2f + 20 * d, cy + hh + 10 * d)
                val s = Paint(Paint.ANTI_ALIAS_FLAG)
                s.style = Paint.Style.FILL; s.color = Color.argb(120, 0, 0, 0)
                c.drawRoundRect(r, 10 * d, 10 * d, s)
                s.style = Paint.Style.STROKE; s.strokeWidth = 1.6f * d; s.color = accent
                c.drawRoundRect(r, 10 * d, 10 * d, s)
                s.strokeWidth = d; s.color = a(accent, 110)
                r.inset(4 * d, 4 * d); c.drawRoundRect(r, 7 * d, 7 * d, s)
                p.style = Paint.Style.FILL; p.color = textColor
                c.drawText(t, x, base, p)
            }
        }
        if (accent2 != 0) postInvalidateDelayed(40)
    }
}
