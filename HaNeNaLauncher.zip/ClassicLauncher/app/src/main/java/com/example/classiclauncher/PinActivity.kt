package com.example.classiclauncher

import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.core.graphics.ColorUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * PIN screen. Time wala PIN: PIN = samay + secret (AppLock dekho).
 * Locked app kholne par aati hai (sahi PIN ke baad wahi app khulti hai), ya settings kholne se pehle (verify mode).
 * 5 galat koshishon ke baad kuch der ruk jata hai. PIN bhool jao to phone ka fingerprint / lock bhi chalta hai.
 */
class PinActivity : AppCompatActivity() {

    private var target: Intent? = null
    private var pkg = ""
    private var verify = false
    private val sb = StringBuilder()
    private val dots = ArrayList<View>()
    private lateinit var dotsRow: LinearLayout
    private lateinit var status: TextView
    private lateinit var timeTv: TextView
    private lateinit var tf: Typeface
    private lateinit var script: Typeface
    private var accent = 0
    private var textC = 0
    private var busy = false
    private var done = false
    private var lockShown = false
    private var wrongPins = 0
    private val red = Color.parseColor("#FF6B6B")
    private val hnd = Handler(Looper.getMainLooper())
    private val clock = object : Runnable { override fun run() { tickUi(); hnd.postDelayed(this, 500L) } }
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun al(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun dot(filled: Boolean, color: Int = accent) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(if (filled) color else Color.TRANSPARENT)
        setStroke(dp(2), color)
    }

    private fun key(txt: String, onTap: () -> Unit): View = TextView(this).apply {
        text = txt; textSize = 26f; typeface = tf; setTextColor(textC); gravity = Gravity.CENTER
        background = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(al(accent, 90)); setStroke(dp(1), accent)
            })
            addState(intArrayOf(), GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(Color.argb(28, 255, 255, 255)); setStroke(dp(1), al(accent, 90))
            })
        }
        isClickable = true
        setOnClickListener { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); onTap() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        accent = Prefs.get(this, Prefs.ACCENT)
        textC = Prefs.get(this, Prefs.TEXT)
        tf = Prefs.typeface(this, Prefs.get(this, Prefs.FONT))
        script = Prefs.typeface(this, 0)
        target = IntentCompat.getParcelableExtra(intent, AppLock.X_TARGET, Intent::class.java)
        pkg = intent.getStringExtra(AppLock.X_PKG) ?: ""
        verify = intent.getBooleanExtra(AppLock.X_VERIFY, false)
        var label = intent.getStringExtra(AppLock.X_LABEL) ?: ""
        if (label.isBlank() && pkg.isNotEmpty()) {
            label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() }
            catch (e: Exception) { "" }
        }
        val appIcon = if (pkg.isNotEmpty()) try { packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null } else null

        val bgTop = ColorUtils.blendARGB(Color.BLACK, accent, 0.22f)
        window.statusBarColor = bgTop
        window.navigationBarColor = Color.BLACK

        val keySz = (resources.displayMetrics.heightPixels * 0.092f).toInt().coerceIn(dp(56), dp(78))
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
        }

        // ---- upar: lock ya app ka icon ----
        if (appIcon != null) {
            body.addView(ImageView(this).apply { setImageDrawable(appIcon) }, LinearLayout.LayoutParams(dp(56), dp(56)))
        } else {
            body.addView(IconBtn(this, IconBtn.LOCK).apply { color = accent; ring = true; isClickable = false },
                LinearLayout.LayoutParams(dp(60), dp(60)))
        }
        body.addView(TextView(this).apply {
            text = if (label.isNotBlank()) label else "App lock"; typeface = script; textSize = 28f
            setTextColor(textC); gravity = Gravity.CENTER; setSingleLine(true)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        body.addView(TextView(this).apply {
            text = "Time wala PIN daalo"; typeface = tf; textSize = 14f; setTextColor(al(textC, 170)); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })

        // ---- 4 dots ----
        dotsRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        for (i in 0 until 4) {
            val v = View(this).apply { background = dot(false) }
            dots.add(v)
            dotsRow.addView(v, LinearLayout.LayoutParams(dp(16), dp(16)).apply { setMargins(dp(10), 0, dp(10), 0) })
        }
        body.addView(dotsRow, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(22) })

        status = TextView(this).apply { typeface = tf; textSize = 13f; gravity = Gravity.CENTER; setTextColor(red) }
        body.addView(status, LinearLayout.LayoutParams(-1, dp(22)).apply { topMargin = dp(10) })
        timeTv = TextView(this).apply { typeface = tf; textSize = 12f; gravity = Gravity.CENTER; setTextColor(al(textC, 120)) }
        body.addView(timeTv, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        // ---- keypad ----
        fun row(vararg v: View): LinearLayout = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            for (x in v) addView(x, LinearLayout.LayoutParams(keySz, keySz).apply { setMargins(dp(10), dp(6), dp(10), dp(6)) })
        }
        for (r in listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))) {
            body.addView(row(*r.map { d -> key(d) { tap(d) } }.toTypedArray()))
        }
        val phone = TextView(this).apply {
            text = "Phone\nlock"; typeface = tf; textSize = 12f; gravity = Gravity.CENTER; setTextColor(accent)
            isClickable = true; setOnClickListener { phoneLock() }
            visibility = if (canPhone()) View.VISIBLE else View.INVISIBLE
        }
        val del = IconBtn(this, IconBtn.DEL).apply {
            color = textC
            setOnClickListener {
                if (!busy && sb.isNotEmpty()) { sb.setLength(sb.length - 1); refreshDots(false) }
            }
            setOnLongClickListener { if (!busy) { sb.setLength(0); refreshDots(false) }; true }
        }
        body.addView(row(phone, key("0") { tap("0") }, del))

        val scroll = ScrollView(this).apply {
            isFillViewport = true; isVerticalScrollBarEnabled = false
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bgTop, Color.BLACK, Color.BLACK))
            fitsSystemWindows = true
            addView(body, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        }
        setContentView(scroll)
    }

    override fun onResume() { super.onResume(); hnd.removeCallbacks(clock); hnd.post(clock) }

    override fun onPause() { hnd.removeCallbacks(clock); super.onPause() }

    private fun tickUi() {
        timeTv.text = "Abhi ka samay  " + fmt.format(Date())
        val ms = AppLock.lockedOutMs(this)
        if (ms > 0L) {
            status.setTextColor(red)
            status.text = "Bahut galat koshishen. ${ms / 1000 + 1} second ruko"
            lockShown = true
        } else if (lockShown) { lockShown = false; status.text = "" }
    }

    private fun tap(d: String) {
        if (busy || done || sb.length >= 4 || AppLock.lockedOutMs(this) > 0L) return
        sb.append(d)
        refreshDots(true)
        if (sb.length == 4) { busy = true; hnd.postDelayed({ evaluate() }, 140L) }
    }

    private fun refreshDots(pop: Boolean) {
        for (i in 0 until 4) {
            val v = dots[i]
            v.background = dot(i < sb.length)
            if (pop && i == sb.length - 1) {
                v.scaleX = 0.5f; v.scaleY = 0.5f
                v.animate().scaleX(1f).scaleY(1f).setDuration(170L).start()
            }
        }
    }

    private fun evaluate() {
        if (AppLock.check(this, sb.toString())) success() else wrong()
    }

    private fun wrong() {
        AppLock.fail(this)
        wrongPins++
        if (wrongPins >= 2 && Prefs.get(this, Prefs.INTRUDERPIN) == 1 && IntruderCam.enabled(this)) {
            IntruderCam.snap(this, "pin") { f -> if (f != null) IntruderCam.notifyAlert(this, f, "Kisi ne galat app lock PIN daala") }
        }
        status.setTextColor(red); status.text = "Galat PIN"
        for (v in dots) v.background = dot(true, red)
        window.decorView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val s = dp(22).toFloat()
        ObjectAnimator.ofFloat(dotsRow, "translationX", 0f, -s, s, -s * 0.6f, s * 0.6f, -s * 0.25f, 0f)
            .setDuration(420L).start()
        hnd.postDelayed({
            sb.setLength(0); refreshDots(false); busy = false
            if (AppLock.lockedOutMs(this) == 0L) status.text = ""
        }, 520L)
    }

    private fun success() {
        if (done) return
        done = true
        AppLock.success(this)
        if (!verify && pkg.isNotEmpty()) AppLock.markUnlocked(this, pkg)
        for (v in dots) v.background = dot(true)
        status.setTextColor(accent); status.text = "Khul gaya"
        hnd.postDelayed({
            if (verify) setResult(RESULT_OK)
            else target?.let {
                try { startActivity(Intent(it).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (e: Exception) { Toast.makeText(this, "App khul nahi saki", Toast.LENGTH_SHORT).show() }
            }
            finish()
            overridePendingTransition(0, 0)
        }, 160L)
    }

    // ------------------------------ PIN bhool gaye: phone ka lock ------------------------------
    private fun phoneAuth(): Int =
        if (Build.VERSION.SDK_INT >= 30)
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        else BiometricManager.Authenticators.BIOMETRIC_WEAK

    private fun canPhone(): Boolean =
        AppLock.fallback(this) && BiometricManager.from(this).canAuthenticate(phoneAuth()) == BiometricManager.BIOMETRIC_SUCCESS

    private fun phoneLock() {
        if (busy || done) return
        val b = BiometricPrompt.PromptInfo.Builder()
            .setTitle("App lock")
            .setSubtitle("Phone ke fingerprint ya lock se kholo")
            .setAllowedAuthenticators(phoneAuth())
        if (Build.VERSION.SDK_INT < 30) b.setNegativeButtonText("Wapas")
        BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { success() }
            }).authenticate(b.build())
    }
}
