package com.example.classiclauncher

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import androidx.core.content.res.ResourcesCompat
import java.io.File

class Preset(
    val title: String, val accent: String, val text: String,
    val font: Int, val clock: Int, val layout: Int, val fx: Int, val nameStyle: Int
)

object Opts {
    val fonts = listOf("Script", "Elegant", "Modern", "Mono", "Condensed", "Casual")
    val clocks = listOf("Classic", "Stacked", "Script", "Digital", "Minimal", "Analog")
    val layouts = listOf("Right list", "Left list", "Center", "Dock row", "Grid", "Circle", "Arc wheel", "Bottom wheel")
    val fxs = listOf("Rings", "Glow burst", "Sparks")
    val nameStyles = listOf("Gold script", "Neon", "Royal lines", "Outline", "Badge")
    val accents = listOf("#D4AF37", "#F4A6B8", "#CFE8FF", "#4DA3FF", "#39FF88", "#2ECC9A",
        "#FF3B30", "#FF8A3D", "#B06BFF", "#FF4FD8", "#FFE14D", "#FFFFFF").map { Color.parseColor(it) }
    val texts = listOf("#E8E8E8", "#FFFFFF", "#FFF1E0", "#D4AF37", "#CFE8FF", "#BDBDBD", "#F4A6B8", "#9BE7FF")
        .map { Color.parseColor(it) }
    val presets = listOf(
        Preset("Classic Gold", "#D4AF37", "#E8E8E8", 0, 0, 0, 0, 0),
        Preset("Royal Blue", "#4DA3FF", "#EAF4FF", 1, 3, 1, 1, 2),
        Preset("Neon Night", "#39FF88", "#E6FFF0", 3, 3, 5, 2, 1),
        Preset("Rose Luxe", "#F4A6B8", "#FFF0F5", 0, 2, 2, 1, 0),
        Preset("Racing Red", "#FF3B30", "#F2F2F2", 4, 1, 6, 0, 3),
        Preset("Ice Silver", "#CFE8FF", "#FFFFFF", 2, 4, 2, 1, 4),
        Preset("Sunset", "#FF8A3D", "#FFF1E0", 5, 5, 7, 2, 0),
        Preset("Emerald", "#2ECC9A", "#E8FFF6", 1, 0, 1, 0, 2)
    )
}

object Prefs {
    const val ACCENT = "accent"; const val TEXT = "text"; const val FONT = "font"
    const val CLOCK = "clock"; const val LAYOUT = "layout"; const val FX = "fx"
    const val NSTYLE = "nstyle"; const val SCALE = "scale"; const val WAVE = "wave"
    const val FXON = "fxon"; const val CAM = "cam"; const val DIM = "dim"
    const val ALWAYS = "always"; const val LOCK = "lock"; const val ALPHA = "alpha"; const val ICONC = "iconc"; const val RINGC = "ringc"; const val ICONSZ = "iconsz"; const val CLOCKSZ = "clocksz"; const val NAMESZ = "namesz"; const val WHEELSZ = "wheelsz"; const val RINGSZ = "ringsz"; const val VOLSZ = "volsz"; const val AUTOSCAN = "autoscan"; const val NAME = "name"; const val REV = "rev"

    private val defaults = mapOf(
        ACCENT to Color.parseColor("#D4AF37"), TEXT to Color.parseColor("#E8E8E8"),
        FONT to 0, CLOCK to 0, LAYOUT to 6, ALPHA to 0, ICONC to 0, RINGC to 0, ICONSZ to 100, CLOCKSZ to 100, NAMESZ to 100, WHEELSZ to 100, RINGSZ to 100, VOLSZ to 100, FX to 0, NSTYLE to 0, SCALE to 100,
        WAVE to 26, FXON to 1, CAM to 1, DIM to 53, ALWAYS to 0, LOCK to 0, AUTOSCAN to 1
    )

    private fun sp(c: Context) = c.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    fun get(c: Context, k: String): Int = sp(c).getInt(k, defaults[k] ?: 0)
    /** 0 ka matlab 'accent jaisa' */
    fun colorOr(c: Context, k: String): Int { val v = get(c, k); return if (v == 0) get(c, ACCENT) else v }
    fun rev(c: Context) = sp(c).getInt(REV, 0)
    private fun bump(c: Context) = sp(c).edit().putInt(REV, (System.nanoTime() / 1000).toInt()).commit()

    fun put(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply(); bump(c) }
    fun name(c: Context): String = sp(c).getString(NAME, "HaNeNa") ?: "HaNeNa"
    fun putName(c: Context, v: String) { sp(c).edit().putString(NAME, v).apply(); bump(c) }
    fun reset(c: Context) { sp(c).edit().clear().apply(); bump(c) }

    fun apply(c: Context, p: Preset) {
        sp(c).edit().putInt(ACCENT, Color.parseColor(p.accent)).putInt(TEXT, Color.parseColor(p.text))
            .putInt(FONT, p.font).putInt(CLOCK, p.clock).putInt(LAYOUT, p.layout)
            .putInt(FX, p.fx).putInt(NSTYLE, p.nameStyle).apply()
        bump(c)
    }

    fun wallFile(c: Context) = File(c.filesDir, "wallpaper.jpg")

    fun saveWallpaper(c: Context, uri: Uri): Boolean = try {
        c.contentResolver.openInputStream(uri)?.use { i -> wallFile(c).outputStream().use { i.copyTo(it) } }
        bump(c); true
    } catch (e: Exception) { false }

    fun removeWallpaper(c: Context) { wallFile(c).delete(); bump(c) }

    fun typeface(c: Context, i: Int): Typeface {
        val id = c.resources.getIdentifier("script", "font", c.packageName)
        return when (i) {
            0 -> (if (id != 0) ResourcesCompat.getFont(c, id) else null) ?: Typeface.create("cursive", Typeface.NORMAL)
            1 -> Typeface.create("serif", Typeface.ITALIC)
            2 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
            3 -> Typeface.create("monospace", Typeface.NORMAL)
            4 -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
            else -> Typeface.create("casual", Typeface.NORMAL)
        }
    }
}
