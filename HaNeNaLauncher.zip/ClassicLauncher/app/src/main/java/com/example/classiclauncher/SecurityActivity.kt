package com.example.classiclauncher

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Lock screen ki suraksha: intruder selfie, alert, fingerprint animation ki jagah, aur pakde gaye logon ki photos */
class SecurityActivity : AppCompatActivity() {

    private lateinit var k: Skin
    private lateinit var list: ListView
    private lateinit var headerBox: LinearLayout
    private var preview: FingerprintFxView? = null
    private var photos: List<File> = emptyList()
    private var started = false
    private val df = SimpleDateFormat("dd MMM yyyy, HH:mm:ss", Locale.getDefault())
    private val thumbs = android.util.LruCache<String, android.graphics.Bitmap>(40)

    private val verify = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) start() else finish()
    }

    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) Prefs.put(this, Prefs.INTRUDER, 1)
        else { Prefs.put(this, Prefs.INTRUDER, 0); Toast.makeText(this, "Selfie ke liye camera ki ijazat chahiye", Toast.LENGTH_LONG).show() }
        fillHeader()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        k = Skin(this)
        if (AppLock.enabled(this)) {
            verify.launch(Intent(this, PinActivity::class.java)
                .putExtra(AppLock.X_VERIFY, true).putExtra(AppLock.X_LABEL, "Security"))
        } else start()
    }

    override fun onResume() { super.onResume(); if (started) loadPhotos() }

    private fun start() {
        if (started) return
        started = true
        window.statusBarColor = k.bgTop(); window.navigationBarColor = Color.BLACK
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true; background = k.gradient() }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(8), k.dp(4), k.dp(20), 0) }
        head.addView(IconBtn(this, IconBtn.BACK).apply { color = k.accent; setOnClickListener { finish() } },
            LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        head.addView(k.tv("Security", 28f, k.textC, true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(6) })
        root.addView(head, k.lp())

        headerBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(k.dp(16), k.dp(4), k.dp(16), k.dp(8)) }
        list = ListView(this).apply {
            divider = null; selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false; setPadding(0, 0, 0, k.dp(16))
            addHeaderView(headerBox, null, false)
            this.adapter = this@SecurityActivity.adapter
            setOnItemClickListener { _, _, p, _ -> photos.getOrNull(p - headerViewsCount)?.let { show(it) } }
            setOnItemLongClickListener { _, _, p, _ -> photos.getOrNull(p - headerViewsCount)?.let { confirmDelete(it) }; true }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        fillHeader()
        loadPhotos()
    }

    private fun fillHeader() {
        headerBox.removeAllViews()
        val camOk = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val on = Prefs.raw(this, Prefs.INTRUDER) == 1 && camOk

        val c1 = k.card()
        c1.addView(k.tv("Intruder selfie", 20f, k.accent, true))
        c1.addView(k.tv("Koi galat finger lagaye ya galat PIN daale to selfie camera se chupke photo li jati hai, sirf HaNeNa ke andar save hoti hai, aur notification milti hai.",
            12f, k.dim(160)), k.lp(4))
        c1.addView(k.switchRow("Intruder selfie on", on) { v ->
            if (v && !camOk) camPerm.launch(Manifest.permission.CAMERA)
            else { Prefs.put(this, Prefs.INTRUDER, if (v) 1 else 0); fillHeader() }
        }, k.lp(12))
        c1.addView(k.tv("Kitni galat koshishon ke baad photo lein", 14f), k.lp(14))
        c1.addView(k.chips(listOf("1 baar", "2 baar", "3 baar"), (Prefs.raw(this, Prefs.INTRUDERN) - 1).coerceIn(0, 2)) {
            Prefs.put(this, Prefs.INTRUDERN, it + 1); fillHeader()
        }, k.lp(8))
        c1.addView(k.switchRow("App lock ka galat PIN par bhi photo", Prefs.raw(this, Prefs.INTRUDERPIN) == 1) {
            Prefs.put(this, Prefs.INTRUDERPIN, if (it) 1 else 0)
        }, k.lp(14))
        c1.addView(k.switchRow("Alert awaaz (vibration hamesha chalti hai)", Prefs.raw(this, Prefs.ALERTSND) == 1) {
            Prefs.put(this, Prefs.ALERTSND, if (it) 1 else 0)
        }, k.lp(10))
        headerBox.addView(c1, k.lp(12))

        val c2 = k.card()
        c2.addView(k.tv("Fingerprint animation", 20f, k.accent, true))
        c2.addView(k.tv("Side ka fingerprint sensor jahan ho wahan sirf animation dikhegi (koi nishan nahi). Style chuno aur jagah set karo.", 12f, k.dim(160)), k.lp(4))
        c2.addView(k.chips(listOf("Lehar", "Edge", "Orb", "Radar"), Prefs.raw(this, Prefs.FPSTYLE).coerceIn(0, 3)) {
            Prefs.put(this, Prefs.FPSTYLE, it); preview?.style = it; fillHeader()
        }, k.lp(12))
        c2.addView(k.switchRow("Idle mein bhi halki roshni", Prefs.raw(this, Prefs.FPIDLE) == 1) {
            Prefs.put(this, Prefs.FPIDLE, if (it) 1 else 0); preview?.idleGlow = it; preview?.invalidate()
        }, k.lp(10))
        c2.addView(k.chips(listOf("Sensor daayein", "Sensor baayein"), Prefs.raw(this, Prefs.FPSIDE)) {
            Prefs.put(this, Prefs.FPSIDE, it); preview?.onRight = it == 0; fillHeader()
        }, k.lp(12))
        val box = FrameLayout(this).apply { background = k.glass(18, 10, 90) }
        val fx = FingerprintFxView(this).apply {
            accent = k.accent; tf = k.tf
            onRight = Prefs.raw(this@SecurityActivity, Prefs.FPSIDE) == 0
            yFrac = Prefs.raw(this@SecurityActivity, Prefs.FPY) / 100f
            style = Prefs.raw(this@SecurityActivity, Prefs.FPSTYLE).coerceIn(0, 3)
            idleGlow = Prefs.raw(this@SecurityActivity, Prefs.FPIDLE) == 1
        }
        preview = fx
        box.addView(fx, FrameLayout.LayoutParams(-1, -1))
        c2.addView(box, k.lp(12, -1, k.dp(210)))
        val sb = SeekBar(this).apply {
            max = 70; progress = (Prefs.raw(this@SecurityActivity, Prefs.FPY) - 15).coerceIn(0, 70)
            progressTintList = android.content.res.ColorStateList.valueOf(k.accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(k.accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, pr: Int, user: Boolean) {
                    fx.yFrac = (pr + 15) / 100f
                    if (user) Prefs.put(this@SecurityActivity, Prefs.FPY, pr + 15)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        c2.addView(k.tv("Sensor ki oonchai (upar-neeche)", 13f, k.dim(180)), k.lp(10))
        c2.addView(sb, k.lp(2))
        val tests = LinearLayout(this)
        tests.addView(k.button("Scan") { fx.scanning() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = k.dp(6) })
        tests.addView(k.button("Sahi") { fx.success { } }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = k.dp(6) })
        tests.addView(k.button("Galat") { fx.fail(); IntruderCam.buzz(this) }, LinearLayout.LayoutParams(0, -2, 1f))
        c2.addView(tests, k.lp(12))
        headerBox.addView(c2, k.lp(12))

        headerBox.addView(k.tv("Pakde gaye log", 22f, k.accent, true), k.lp(20))
        headerBox.addView(k.tv(if (photos.isEmpty()) "Abhi koi photo nahi." else "${photos.size} photo. Dabao to bada dikhega, lamba dabao to hat jayegi.",
            12f, k.dim(150)), k.lp(2))
    }

    private fun loadPhotos() {
        photos = IntruderCam.photos(this)
        adapter.notifyDataSetChanged()
        if (started) fillHeaderKeepPreview()
    }

    /** Photo ginti badalne par sirf neeche ka text naya karo (preview na toote) */
    private fun fillHeaderKeepPreview() {
        val n = headerBox.childCount
        if (n >= 2) {
            (headerBox.getChildAt(n - 1) as? TextView)?.text =
                if (photos.isEmpty()) "Abhi koi photo nahi." else "${photos.size} photo. Dabao to bada dikhega, lamba dabao to hat jayegi."
        }
    }

    private fun show(f: File) {
        val bmp = BitmapFactory.decodeFile(f.absolutePath) ?: return
        val iv = ImageView(this).apply { setImageBitmap(bmp); adjustViewBounds = true }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(IntruderCam.reasonOf(f) + "\n" + df.format(Date(f.lastModified())))
            .setView(iv)
            .setPositiveButton("Theek hai", null)
            .setNegativeButton("Hatao") { _, _ -> f.delete(); loadPhotos() }
            .show()
    }

    private fun confirmDelete(f: File) {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Ye photo hatani hai?")
            .setPositiveButton("Hatao") { _, _ -> f.delete(); loadPhotos() }
            .setNegativeButton("Nahi", null).show()
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = photos.size
        override fun getItem(p: Int) = photos[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val outer = (cv as? FrameLayout) ?: FrameLayout(this@SecurityActivity).apply {
                setPadding(k.dp(12), k.dp(3), k.dp(12), k.dp(3))
                addView(LinearLayout(context).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(k.dp(10), k.dp(8), k.dp(14), k.dp(8))
                    background = k.glass(16, 22, 50)
                    addView(ImageView(context).apply { scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams(k.dp(64), k.dp(64)))
                    addView(LinearLayout(context).apply {
                        orientation = LinearLayout.VERTICAL
                        addView(k.tv("", 15f)); addView(k.tv("", 12f, k.dim(150)))
                    }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(14) })
                }, FrameLayout.LayoutParams(-1, -2))
            }
            val row = outer.getChildAt(0) as LinearLayout
            val f = photos[p]
            val key = f.absolutePath
            var bmp = thumbs.get(key)
            if (bmp == null) {
                val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                bmp = BitmapFactory.decodeFile(key, o)
                if (bmp != null) thumbs.put(key, bmp)
            }
            (row.getChildAt(0) as ImageView).setImageBitmap(bmp)
            val col = row.getChildAt(1) as LinearLayout
            (col.getChildAt(0) as TextView).text = IntruderCam.reasonOf(f)
            (col.getChildAt(1) as TextView).text = df.format(Date(f.lastModified()))
            return outer
        }
    }
}
