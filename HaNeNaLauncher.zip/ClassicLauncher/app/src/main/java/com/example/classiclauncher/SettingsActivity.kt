package com.example.classiclauncher

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.content.ContextCompat
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var scroll: ScrollView

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            Toast.makeText(this,
                if (Prefs.saveWallpaper(this, it)) "Wallpaper lag gaya" else "Wallpaper set nahi hua",
                Toast.LENGTH_SHORT).show()
        }
    }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { startLock() }

    private fun startLock() {
        try { ContextCompat.startForegroundService(this, Intent(this, LockService::class.java)) } catch (e: Exception) {}
    }

    private fun setLock(on: Boolean) = setFeature(Prefs.LOCK, on)

    private fun setFeature(key: String, on: Boolean) {
        Prefs.put(this, key, if (on) 1 else 0)
        if (!on) { if (!LockService.wanted(this)) stopService(Intent(this, LockService::class.java)); return }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Pehle 'Display over other apps' ki ijazat do", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        else startLock()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun acc() = Prefs.get(this, Prefs.ACCENT)
    private fun g(k: String) = Prefs.get(this, k)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B0B0D")
        window.navigationBarColor = Color.parseColor("#0B0B0D")
        scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B0B0D")); isVerticalScrollBarEnabled = false
        }
        setContentView(scroll)
        render()
    }

    // ---------------------------- helpers ----------------------------
    private fun label(t: String, size: Float = 14f, color: Int = Color.parseColor("#BBBBBB")) =
        TextView(this).apply { text = t; textSize = size; setTextColor(color) }

    private fun card(title: String, body: LinearLayout.() -> Unit): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(16))
        background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat(); setColor(Color.parseColor("#141416"))
            setStroke(dp(1), Color.parseColor("#26262B"))
        }
        addView(TextView(context).apply {
            text = title.uppercase(); textSize = 12f; letterSpacing = 0.15f
            setTextColor(acc()); setPadding(0, 0, 0, dp(10))
        })
        body()
    }

    private fun LinearLayout.gap(h: Int = 12) = addView(View(context), -1, dp(h))

    private fun chips(opts: List<String>, sel: Int, faces: List<Typeface>? = null, onPick: (Int) -> Unit): View {
        val row = LinearLayout(this)
        opts.forEachIndexed { i, t ->
            row.addView(TextView(this).apply {
                text = t; textSize = 15f
                faces?.let { typeface = it[i] }
                setPadding(dp(14), dp(9), dp(14), dp(9))
                val on = i == sel
                setTextColor(if (on) Color.BLACK else Color.parseColor("#DDDDDD"))
                background = GradientDrawable().apply {
                    cornerRadius = dp(20).toFloat()
                    if (on) setColor(acc()) else { setColor(Color.TRANSPARENT); setStroke(dp(1), Color.parseColor("#3A3A40")) }
                }
                setOnClickListener { onPick(i) }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        }
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
    }

    private fun swatches(cols: List<Int>, sel: Int, onPick: (Int) -> Unit): View {
        val row = LinearLayout(this)
        cols.forEach { c ->
            val ring = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                if (c != 0) setColor(c) else setColor(Color.parseColor("#1E1E22"))
                if (c == sel) setStroke(dp(3), Color.WHITE) else setStroke(dp(1), Color.parseColor("#44444A"))
            }
            val v: View = if (c == 0) TextView(this).apply {
                text = "A"; gravity = Gravity.CENTER; textSize = 14f; setTextColor(acc()); background = ring
            } else View(this).apply { background = ring }
            v.setOnClickListener { onPick(c) }
            row.addView(v, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(10) })
        }
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
    }

    private fun seek(text: String, lo: Int, hi: Int, key: String, unit: String = "%"): View {
        val v = g(key)
        val head = label("$text: $v$unit")
        val sb = SeekBar(this).apply {
            this.max = hi - lo; progress = v - lo
            progressTintList = ColorStateList.valueOf(acc()); thumbTintList = ColorStateList.valueOf(acc())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    head.text = "$text: ${p + lo}$unit"
                    if (user) Prefs.put(this@SettingsActivity, key, p + lo)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(head); addView(sb) }
    }

    private fun hueSeek(key: String): View {
        val hsv = FloatArray(3); Color.colorToHSV(Prefs.colorOr(this, key), hsv)
        val sb = SeekBar(this).apply {
            max = 360; progress = hsv[0].toInt()
            progressTintList = ColorStateList.valueOf(acc()); thumbTintList = ColorStateList.valueOf(acc())
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    if (user) Prefs.put(this@SettingsActivity, key,
                        Color.HSVToColor(floatArrayOf(p.toFloat(), 0.6f, 1f)))
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { render() }
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label("Apna rang banao (slider)")); addView(sb)
        }
    }

    private fun switchRow(text: String, key: String): View = Switch(this).apply {
        this.text = text; setTextColor(Color.parseColor("#DDDDDD")); textSize = 15f
        isChecked = g(key) == 1
        setOnCheckedChangeListener { _, b -> Prefs.put(this@SettingsActivity, key, if (b) 1 else 0) }
    }

    private fun switchRowRender(text: String, key: String): View = Switch(this).apply {
        this.text = text; setTextColor(Color.parseColor("#DDDDDD")); textSize = 15f
        isChecked = g(key) == 1
        setOnCheckedChangeListener { _, b -> Prefs.put(this@SettingsActivity, key, if (b) 1 else 0); render() }
    }

    private fun button(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 15f; gravity = Gravity.CENTER
        setTextColor(acc()); setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setStroke(dp(1), acc()) }
        setOnClickListener { onClick() }
    }

    // ----------------------------- screen -----------------------------
    private fun render() {
        val y = scroll.scrollY
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(48))
        }
        fun add(v: View) = col.addView(v, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        val script = Prefs.typeface(this, 0)

        add(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(context).apply { text = "‹ Wapas"; textSize = 15f; setTextColor(acc())
                setPadding(0, 0, 0, dp(8)); setOnClickListener { finish() } })
            addView(TextView(context).apply { text = Prefs.name(context); typeface = script; textSize = 44f; setTextColor(acc()) })
            addView(label("Launcher settings"))
        })

        add(card("Ready designs") {
            addView(chips(Opts.presets.map { it.title }, -1) { Prefs.apply(this@SettingsActivity, Opts.presets[it]); render() })
            gap(6); addView(label("Ek tap par poora design badal jata hai. Phir neeche se kuch bhi alag kar sakte ho.", 12f, Color.parseColor("#777777")))
        })

        add(card("Auto mode (khud badalne wala launcher)") {
            addView(label("On karo to launcher apne aap badalta rahega: har hafte naya design, clock ka style khud badle, aur Jume (Friday) ko alag design, clock aur music style. Aapki apni settings delete nahi hoti, auto band karte hi wapas aa jati hain.", 12f, Color.parseColor("#777777")))
            gap(8); addView(switchRowRender("Auto mode on", Prefs.AUTO))
            if (g(Prefs.AUTO) == 1) {
                gap(10); addView(label("Abhi chal raha hai:", 13f, Color.parseColor("#999999")))
                gap(4); addView(label(Auto.status(this@SettingsActivity), 14f, Color.parseColor("#DDDDDD")))
                gap(14); addView(label("Clock style kab badle"))
                gap(8); addView(chips(Opts.autoRot, Prefs.raw(this@SettingsActivity, Prefs.AUTOROT)) { Prefs.put(this@SettingsActivity, Prefs.AUTOROT, it); render() })
                gap(4); addView(label("Charging clock ka design bhi saath badalta hai.", 12f, Color.parseColor("#777777")))
                gap(12); addView(switchRowRender("Har hafte naya design (Monday se)", Prefs.AUTOWEEK))
                gap(6); addView(switchRowRender("Design ke saath home layout bhi badlo", Prefs.AUTOLAY))
                gap(6); addView(switchRowRender("Jume (Friday) ka alag look", Prefs.FRI))
                if (Prefs.raw(this@SettingsActivity, Prefs.FRI) == 1) {
                    gap(10); addView(label("Jume ka clock"))
                    gap(8); addView(chips(Opts.clocks, Prefs.raw(this@SettingsActivity, Prefs.FRICLOCK)) { Prefs.put(this@SettingsActivity, Prefs.FRICLOCK, it); render() })
                    gap(10); addView(label("Jume ka design"))
                    gap(8); addView(chips(Opts.presets.map { it.title }, Prefs.raw(this@SettingsActivity, Prefs.FRIPRESET)) { Prefs.put(this@SettingsActivity, Prefs.FRIPRESET, it); render() })
                    gap(10); addView(label("Jume ka music style"))
                    gap(8); addView(chips(Opts.musicStyles, Prefs.raw(this@SettingsActivity, Prefs.FRIMUSIC)) { Prefs.put(this@SettingsActivity, Prefs.FRIMUSIC, it); render() })
                }
            }
        })

        add(card("Music player") {
            addView(label("HaNeNa ka apna music player: phone ke gaane, ghoomta vinyl, neon bars, glass card. Lock screen par bhi dikhta hai.", 12f, Color.parseColor("#777777")))
            gap(10); addView(button("Music player kholo") { startActivity(Intent(this@SettingsActivity, MusicActivity::class.java)) })
            gap(12); addView(label("Music style"))
            gap(8); addView(chips(Opts.musicStyles, g(Prefs.MUSTYLE)) { Prefs.put(this@SettingsActivity, Prefs.MUSTYLE, it); render() })
            if (g(Prefs.AUTO) == 1) { gap(4); addView(label("Auto mode on hai, isliye style abhi khud badal raha hai.", 12f, Color.parseColor("#777777"))) }
            gap(10); addView(switchRow("Lock screen par music player dikhao", Prefs.MUSLOCK))
            gap(6); addView(switchRow("Home par chhota music bar (gaana chalte waqt)", Prefs.MUSCHIP))
            gap(6); addView(label("Lock screen par card ke liye 'Lock screen' wala feature on hona chahiye. Music ko Home ki favourite apps mein bhi jod sakte ho: Saari apps mein 'HaNeNa Music' ko long-press karo.", 12f, Color.parseColor("#777777")))
        })

        add(card("Rang (colors)") {
            addView(label("Animation / accent rang"))
            gap(8); addView(swatches(Opts.accents, g(Prefs.ACCENT)) { Prefs.put(this@SettingsActivity, Prefs.ACCENT, it); render() })
            gap(8); addView(hueSeek(Prefs.ACCENT))
            gap(10); addView(label("Text ka rang"))
            gap(8); addView(swatches(Opts.texts, g(Prefs.TEXT)) { Prefs.put(this@SettingsActivity, Prefs.TEXT, it); render() })
            gap(14); addView(label("Icon ka rang  (A = accent jaisa)"))
            gap(8); addView(swatches(listOf(0) + Opts.accents, g(Prefs.ICONC)) { Prefs.put(this@SettingsActivity, Prefs.ICONC, it); render() })
            gap(8); addView(hueSeek(Prefs.ICONC))
            gap(14); addView(label("Ring ka rang  (camera ring, wheel ring aur animations)"))
            gap(8); addView(swatches(listOf(0) + Opts.accents, g(Prefs.RINGC)) { Prefs.put(this@SettingsActivity, Prefs.RINGC, it); render() })
            gap(8); addView(hueSeek(Prefs.RINGC))
            gap(14); addView(switchRow("Saari apps (app drawer) ke icons bhi theme rang mein. Band ho to asli rang dikhte hain", Prefs.DRTINT))
            gap(16); addView(switchRowRender("Mix rang (do rang milao)", Prefs.MIX))
            if (g(Prefs.MIX) == 1) {
                gap(8); addView(label("Dusra rang  (pehle rang ke saath mix hoga)"))
                gap(8); addView(swatches(Opts.accents, g(Prefs.ACCENT2)) { Prefs.put(this@SettingsActivity, Prefs.ACCENT2, it); render() })
                gap(8); addView(hueSeek(Prefs.ACCENT2))
                gap(10); addView(label("Mix kahan lagana hai", 13f, Color.parseColor("#999999")))
                gap(4); addView(switchRow("HaNeNa naam (dono rang dheere dheere badalte hain)", Prefs.MIXNAME))
                gap(4); addView(switchRow("Icons (pehle se dusre rang tak gradient)", Prefs.MIXICON))
                gap(4); addView(switchRow("Charging clock (rang behta rehta hai)", Prefs.MIXCHG))
            }
        })

        add(card("Clock style") {
            addView(chips(Opts.clocks, g(Prefs.CLOCK)) { Prefs.put(this@SettingsActivity, Prefs.CLOCK, it); render() })
            if (g(Prefs.AUTO) == 1) { gap(6); addView(label("Auto mode on hai, clock abhi khud badal raha hai (upar Auto mode card dekho).", 12f, Color.parseColor("#777777"))) }
        })

        add(card("Home layout") {
            addView(chips(Opts.layouts, g(Prefs.LAYOUT)) { Prefs.put(this@SettingsActivity, Prefs.LAYOUT, it); render() })
            gap(10); addView(switchRow("ABCD bar (A se Z) dikhao", Prefs.ALPHA))
        })

        add(card("Font aur size") {
            addView(chips(Opts.fonts.map { "$it Aa" }, g(Prefs.FONT), (0..5).map { Prefs.typeface(this@SettingsActivity, it) }) {
                Prefs.put(this@SettingsActivity, Prefs.FONT, it); render() })
            gap(12); addView(seek("Text size", 70, 140, Prefs.SCALE))
        })

        add(card("Size (sab ka size apne haath mein)") {
            addView(seek("Icon size", 50, 160, Prefs.ICONSZ))
            gap(10); addView(seek("Clock size", 60, 160, Prefs.CLOCKSZ))
            gap(10); addView(seek("Naam (HaNeNa) size", 50, 160, Prefs.NAMESZ))
            gap(10); addView(seek("Gol wheel size", 70, 130, Prefs.WHEELSZ))
            gap(10); addView(seek("Camera ring size", 60, 180, Prefs.RINGSZ))
            gap(10); addView(seek("Volume bar size", 60, 180, Prefs.VOLSZ))
        })

        add(card("Animation") {
            addView(switchRow("Animation on", Prefs.FXON))
            gap(6); addView(switchRow("Camera ring", Prefs.CAM))
            gap(10); addView(chips(Opts.fxs, g(Prefs.FX)) { Prefs.put(this@SettingsActivity, Prefs.FX, it); render() })
            gap(10); addView(switchRow("Gol wheel Snapchat jaisa: side wale item par tap karo to beech mein aaye, beech wale par tap karo to khule", Prefs.SNAPTAP))
            gap(12); addView(seek("Wave taqat (apps ka hilna)", 0, 40, Prefs.WAVE, " dp"))
        })

        add(card("Charging clock") {
            addView(label("Charger lagte hi landscape mein khoobsurat clock. Screen lock ho tab bhi chalti hai. Touch karo to band.", 12f, Color.parseColor("#777777")))
            gap(8)
            addView(Switch(context).apply {
                text = "Charging clock on"; setTextColor(Color.parseColor("#DDDDDD")); textSize = 15f
                isChecked = g(Prefs.CHARGE) == 1
                setOnCheckedChangeListener { _, b -> setFeature(Prefs.CHARGE, b) }
            })
            gap(12); addView(label("Clock ka design"))
            gap(8); addView(chips(Opts.chargeStyles, g(Prefs.CHSTYLE)) { Prefs.put(this@SettingsActivity, Prefs.CHSTYLE, it); render() })
            gap(12); addView(switchRow("Screen lock / band ho tab bhi charging clock dikhao", Prefs.CHLOCK))
            gap(6); addView(switchRow("Charger lagte hi screen khud on karo", Prefs.CHWAKE))
            gap(6); addView(switchRow("Seconds dikhao", Prefs.CHSEC))
            gap(6); addView(switchRow("Date dikhao", Prefs.CHDATE))
            gap(6); addView(switchRow("Burn-in se bachao (clock halka sa khisakta rahe)", Prefs.CHDRIFT))
            gap(12); addView(label("Time format"))
            gap(8); addView(chips(listOf("Auto", "12 ghanta", "24 ghanta"), g(Prefs.CH24)) { Prefs.put(this@SettingsActivity, Prefs.CH24, it); render() })
            gap(12); addView(seek("Brightness", 5, 100, Prefs.CHBRIGHT))
            gap(10); addView(button("Overlay ki ijazat do (zaroori)") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            })
            gap(8); addView(button("Charging clock abhi test karo") {
                startActivity(Intent(this@SettingsActivity, ChargeClockActivity::class.java).putExtra("test", true))
            })
        })

        add(card("Advance settings") {
            addView(seek("Home par apps ki ginti", 3, 10, Prefs.APPS, ""))
            gap(10); addView(switchRow("Apps ke naam dikhao (dock, rail, cards mein)", Prefs.LABELS))
            gap(6); addView(switchRow("Neeche se upar swipe karo to saari apps khule", Prefs.SWIPEUP))
            gap(6); addView(switchRow("Status bar chhupao (full screen home)", Prefs.HIDESB))
            gap(10); addView(label("Favourite apps chunne ke liye: Saari apps mein kisi app ko long-press karo, 'Home mein jodo'.", 12f, Color.parseColor("#777777")))
        })

        add(card("Lock screen") {
            addView(label("Screen band hone par HaNeNa lock screen aati hai: chehre ki scan animation ke saath.", 12f, Color.parseColor("#777777")))
            gap(8)
            addView(Switch(context).apply {
                text = "Lock screen on"; setTextColor(Color.parseColor("#DDDDDD")); textSize = 15f
                isChecked = g(Prefs.LOCK) == 1
                setOnCheckedChangeListener { _, b -> setLock(b) }
            })
            gap(6); addView(switchRow("Khud face scan shuru karo", Prefs.AUTOSCAN))
            gap(10); addView(button("Overlay ki ijazat do (zaroori)") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            })
            gap(8); addView(button("Lock screen abhi test karo") { startActivity(Intent(this@SettingsActivity, LockActivity::class.java)) })
            gap(8); addView(label("Tecno: Settings, Battery mein is app ko 'No restrictions' do aur auto-start on karo, warna phone service band kar deta hai.", 12f, Color.parseColor("#777777")))
        })

        add(card("Naam") {
            addView(EditText(context).apply {
                setText(Prefs.name(context)); setTextColor(Color.WHITE); hint = "Apna naam"
                setHintTextColor(Color.parseColor("#666666")); setSingleLine()
                filters = arrayOf(InputFilter.LengthFilter(14))
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setStroke(dp(1), Color.parseColor("#3A3A40")) }
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        Prefs.putName(this@SettingsActivity, s.toString().trim().ifEmpty { "HaNeNa" })
                    }
                })
            })
            gap(10)
            // photo jaisa background par live preview
            addView(FrameLayout(context).apply {
                clipChildren = false
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    intArrayOf(Color.parseColor("#1B2A41"), Color.parseColor("#324A5F"), Color.parseColor("#0C1821"))).apply {
                    cornerRadius = dp(14).toFloat() }
                addView(NameView(context).also {
                    it.name = Prefs.name(context); it.nameStyle = g(Prefs.NSTYLE); it.accent = acc()
                    it.textColor = g(Prefs.TEXT); it.scriptTf = script
                    it.tf = Prefs.typeface(context, g(Prefs.FONT)); it.scale = g(Prefs.SCALE) / 100f
                }, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            }, LinearLayout.LayoutParams(-1, dp(110)))
            gap(10); addView(chips(Opts.nameStyles, g(Prefs.NSTYLE)) { Prefs.put(this@SettingsActivity, Prefs.NSTYLE, it); render() })
            gap(10); addView(switchRow("Wallpaper ke bina bhi dikhao", Prefs.ALWAYS))
        })

        add(card("Wallpaper") {
            addView(button("Gallery se wallpaper chuno") { pick.launch("image/*") })
            gap(8); addView(button("Wallpaper hatao") { Prefs.removeWallpaper(this@SettingsActivity) })
            gap(12); addView(seek("Andhera (dim)", 0, 90, Prefs.DIM))
        })

        add(card("Aur") {
            addView(button("Is launcher ko default banao") {
                try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
                catch (e: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            })
            gap(8); addView(button("Sab kuch reset karo") { Prefs.reset(this@SettingsActivity); render() })
        })

        scroll.removeAllViews(); scroll.addView(col)
        scroll.post { scroll.scrollTo(0, y) }
    }
}
