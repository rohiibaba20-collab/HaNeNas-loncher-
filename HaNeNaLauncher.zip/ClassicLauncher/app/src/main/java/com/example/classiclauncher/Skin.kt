package com.example.classiclauncher

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import androidx.core.graphics.ColorUtils

/**
 * Har naye HaNeNa app (Video, Phone, Messages, Security) ko launcher ka rang / font deta hai,
 * aur chhote UI helper (glass card, chip, button) ek jagah rakhta hai.
 */
class Skin(val ctx: Context) {
    val accent: Int = Prefs.get(ctx, Prefs.ACCENT)
    val accent2: Int = if (Prefs.get(ctx, Prefs.MIX) == 1) Prefs.get(ctx, Prefs.ACCENT2) else accent
    val textC: Int = Prefs.get(ctx, Prefs.TEXT)
    val tf: Typeface = Prefs.typeface(ctx, Prefs.get(ctx, Prefs.FONT))
    val script: Typeface = Prefs.typeface(ctx, 0)
    val d: Float = ctx.resources.displayMetrics.density
    val red: Int = Color.parseColor("#FF5C5C")

    fun dp(v: Int): Int = (v * d).toInt()
    fun al(c: Int, a: Int): Int = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))
    fun bgTop(): Int = ColorUtils.blendARGB(Color.BLACK, accent, 0.22f)
    fun dim(a: Int = 170): Int = al(textC, a)

    fun gradient(): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bgTop(), Color.BLACK, Color.BLACK))

    fun glass(radius: Int = 18, fill: Int = 26, stroke: Int = 70): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(radius).toFloat(); setColor(Color.argb(fill, 255, 255, 255)); setStroke(dp(1), al(accent, stroke))
    }

    fun oval(fill: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(fill); setStroke(dp(1), stroke)
    }

    fun tv(t: String, size: Float, color: Int = textC, useScript: Boolean = false): TextView = TextView(ctx).apply {
        text = t; textSize = size; setTextColor(color); typeface = if (useScript) script else tf
    }

    fun button(t: String, onTap: () -> Unit): TextView = TextView(ctx).apply {
        text = t; textSize = 14f; typeface = tf; setTextColor(accent); gravity = Gravity.CENTER
        setPadding(dp(16), dp(10), dp(16), dp(10))
        background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), accent) }
        isClickable = true; setOnClickListener { onTap() }
    }

    fun chips(opts: List<String>, sel: Int, pick: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        opts.forEachIndexed { i, o ->
            val on = i == sel
            box.addView(TextView(ctx).apply {
                text = o; textSize = 13f; typeface = tf; gravity = Gravity.CENTER
                setTextColor(if (on) Color.BLACK else textC)
                setPadding(dp(6), dp(9), dp(6), dp(9))
                background = GradientDrawable().apply {
                    cornerRadius = dp(18).toFloat()
                    if (on) setColor(accent) else { setColor(Color.argb(24, 255, 255, 255)); setStroke(dp(1), al(accent, 90)) }
                }
                isClickable = true; setOnClickListener { pick(i) }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        return box
    }

    fun lp(top: Int = 0, w: Int = -1, h: Int = -2) = LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }

    fun sw(on: Boolean, change: (Boolean) -> Unit): Switch = Switch(ctx).apply {
        isChecked = on
        thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(accent, Color.GRAY))
        trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(al(accent, 120), Color.DKGRAY))
        setOnCheckedChangeListener { _, v -> change(v) }
    }

    fun switchRow(t: String, on: Boolean, change: (Boolean) -> Unit): LinearLayout = LinearLayout(ctx).apply {
        gravity = Gravity.CENTER_VERTICAL
        addView(tv(t, 15f), LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(10) })
        addView(sw(on, change))
    }

    fun card(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = glass()
    }
}
