package com.example.classiclauncher

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** HaNeNa Messages: chats ki list (gol avatar, unread ginti, search) */
class SmsActivity : AppCompatActivity() {

    private lateinit var k: Skin
    private lateinit var lv: ListView
    private lateinit var none: TextView
    private var all: List<SmsData.Conv> = emptyList()
    private var shown: List<SmsData.Conv> = emptyList()
    private var query = ""
    private var pickTarget: EditText? = null
    private val hnd = Handler(Looper.getMainLooper())
    private val tfmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dfmt = SimpleDateFormat("dd MMM", Locale.getDefault())

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { reload() }
    private val pick = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uri = r.data?.data
        if (r.resultCode == RESULT_OK && uri != null) {
            try {
                contentResolver.query(uri, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)?.use { q ->
                    if (q.moveToFirst()) pickTarget?.setText(q.getString(0))
                }
            } catch (e: Exception) { }
        }
    }

    private val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { hnd.removeCallbacks(reloadRun); hnd.postDelayed(reloadRun, 500L) }
    }
    private val reloadRun = Runnable { reload() }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int) = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View = row(shown[p], cv)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        k = Skin(this)
        window.statusBarColor = k.bgTop(); window.navigationBarColor = Color.BLACK
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true; background = k.gradient() }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(8), k.dp(4), k.dp(16), 0) }
        head.addView(IconBtn(this, IconBtn.BACK).apply { color = k.accent; setOnClickListener { finish() } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        head.addView(k.tv("Messages", 28f, k.textC, true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(6) })
        head.addView(k.button("+ Naya") { compose() })
        root.addView(head, k.lp())

        val et = EditText(this).apply {
            hint = "Naam ya number dhundo"; setHintTextColor(Color.argb(120, 255, 255, 255)); setTextColor(Color.WHITE)
            textSize = 15f; setSingleLine(true); background = null; setPadding(k.dp(20), k.dp(12), k.dp(20), k.dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { query = s?.toString().orEmpty(); filter() }
            })
        }
        root.addView(FrameLayout(this).apply { background = k.glass(26, 34, 110); addView(et, FrameLayout.LayoutParams(-1, -2)) },
            k.lp(0).apply { setMargins(k.dp(16), k.dp(10), k.dp(16), k.dp(6)) })

        lv = ListView(this).apply {
            divider = null; selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false; setPadding(0, k.dp(2), 0, k.dp(14)); adapter = this@SmsActivity.adapter
        }
        none = k.tv("", 14f, k.dim(150)).apply { gravity = Gravity.CENTER; setPadding(k.dp(30), 0, k.dp(30), 0) }
        val frame = FrameLayout(this)
        frame.addView(lv, FrameLayout.LayoutParams(-1, -1)); frame.addView(none, FrameLayout.LayoutParams(-1, -1))
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val need = listOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS)
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) perms.launch(need.toTypedArray()) else reload()
    }

    override fun onResume() {
        super.onResume()
        try { contentResolver.registerContentObserver(Uri.parse("content://sms"), true, obs) } catch (e: Exception) { }
        reload()
    }

    override fun onPause() { try { contentResolver.unregisterContentObserver(obs) } catch (e: Exception) { }; super.onPause() }

    private fun reload() {
        Thread {
            ContactsData.load(this)
            val list = SmsData.conversations(this)
            runOnUiThread { all = list; filter() }
        }.start()
    }

    private fun filter() {
        val q = query.trim()
        shown = if (q.isEmpty()) all else all.filter {
            (ContactsData.nameFor(this, it.address) ?: "").contains(q, true) || it.address.contains(q) || it.last.body.contains(q, true)
        }
        adapter.notifyDataSetChanged()
        none.text = if (!SmsData.canRead(this)) "Messages padhne ki ijazat do (Settings, App, Permissions)."
            else if (all.isEmpty()) "Abhi koi message nahi." else if (shown.isEmpty()) "Kuch nahi mila." else ""
        none.visibility = if (none.text.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun whenOf(ms: Long): String {
        val n = Calendar.getInstance(); val t = Calendar.getInstance().apply { timeInMillis = ms }
        val same = n.get(Calendar.YEAR) == t.get(Calendar.YEAR) && n.get(Calendar.DAY_OF_YEAR) == t.get(Calendar.DAY_OF_YEAR)
        return if (same) tfmt.format(Date(ms)) else dfmt.format(Date(ms))
    }

    private fun row(c: SmsData.Conv, cv: View?): View {
        val outer = (cv as? FrameLayout) ?: FrameLayout(this).apply {
            setPadding(k.dp(12), k.dp(3), k.dp(12), k.dp(3))
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(12), k.dp(10), k.dp(14), k.dp(10)); background = k.glass(20, 20, 40)
                addView(TextView(context).apply {
                    gravity = Gravity.CENTER; textSize = 19f; setTextColor(Color.BLACK); typeface = k.script
                    background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(k.accent, k.accent2)).apply { shape = GradientDrawable.OVAL }
                }, LinearLayout.LayoutParams(k.dp(48), k.dp(48)))
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(k.tv("", 16f).apply { setSingleLine(true); ellipsize = TextUtils.TruncateAt.END })
                    addView(k.tv("", 13f, k.dim(150)).apply { setSingleLine(true); ellipsize = TextUtils.TruncateAt.END })
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(12); marginEnd = k.dp(8) })
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.END
                    addView(k.tv("", 11f, k.dim(140)))
                    addView(TextView(context).apply {
                        textSize = 11f; setTextColor(Color.BLACK); gravity = Gravity.CENTER; typeface = k.tf
                        setPadding(k.dp(7), k.dp(1), k.dp(7), k.dp(1))
                        background = GradientDrawable().apply { cornerRadius = k.dp(10).toFloat(); setColor(k.accent) }
                    }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = k.dp(5) })
                })
            }, FrameLayout.LayoutParams(-1, -2))
        }
        val row = outer.getChildAt(0) as LinearLayout
        val name = ContactsData.nameFor(this, c.address)
        val title = name ?: c.address
        (row.getChildAt(0) as TextView).text = if (name != null) title.trim().firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "#" else "✉"
        val mid = row.getChildAt(1) as LinearLayout
        (mid.getChildAt(0) as TextView).apply { text = title; setTextColor(k.textC); setTypeface(k.tf, if (c.unread > 0) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL) }
        (mid.getChildAt(1) as TextView).text = (if (c.last.type == 2) "Aap: " else "") + c.last.body.replace("\n", " ")
        val right = row.getChildAt(2) as LinearLayout
        (right.getChildAt(0) as TextView).text = whenOf(c.last.date)
        (right.getChildAt(1) as TextView).apply { text = c.unread.toString(); visibility = if (c.unread > 0) View.VISIBLE else View.INVISIBLE }
        row.setOnClickListener {
            startActivity(Intent(this, SmsChatActivity::class.java).putExtra("address", c.address))
        }
        return outer
    }

    private fun compose() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(k.dp(20), k.dp(10), k.dp(20), 0) }
        val num = EditText(this).apply { inputType = InputType.TYPE_CLASS_PHONE; hint = "Number" }
        pickTarget = num
        box.addView(num)
        box.addView(Button(this).apply {
            text = "Contact chuno"
            setOnClickListener { pick.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)) }
        })
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Naya message").setView(box)
            .setPositiveButton("Aage") { _, _ ->
                val n = num.text.toString().trim()
                if (n.isNotEmpty()) startActivity(Intent(this, SmsChatActivity::class.java).putExtra("address", n))
            }.setNegativeButton("Cancel", null).show()
    }
}
