package com.example.classiclauncher

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Ek chat: gradient bubbles, din ki patti, neeche likhne ki jagah. Naya message aate hi apne aap dikhta hai. */
class SmsChatActivity : AppCompatActivity() {

    private class Item(val sep: String?, val msg: SmsData.Msg?)

    private lateinit var k: Skin
    private lateinit var lv: ListView
    private lateinit var input: EditText
    private var address = ""
    private var key = ""
    private var items: List<Item> = emptyList()
    private var pending: String? = null
    private val hnd = Handler(Looper.getMainLooper())
    private val tfmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dfmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    private val sendPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) pending?.let { doSend(it) } else Toast.makeText(this, "Message bhejne ki ijazat chahiye", Toast.LENGTH_LONG).show()
        pending = null
    }

    private val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { hnd.removeCallbacks(reloadRun); hnd.postDelayed(reloadRun, 400L) }
    }
    private val reloadRun = Runnable { reload() }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(p: Int) = if (items[p].sep != null) 0 else 1
        override fun isEnabled(p: Int) = false
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val it = items[p]
            return if (it.sep != null) sepView(it.sep, cv) else bubble(it.msg!!, cv)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        k = Skin(this)
        address = intent.getStringExtra("address") ?: ""
        key = SmsData.keyOf(address)
        window.statusBarColor = k.bgTop(); window.navigationBarColor = Color.BLACK
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true; background = k.gradient() }

        val name = ContactsData.nameFor(this, address)
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(8), k.dp(4), k.dp(8), k.dp(4)) }
        head.addView(IconBtn(this, IconBtn.BACK).apply { color = k.accent; setOnClickListener { finish() } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        head.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(k.tv(name ?: address, 20f, k.textC, true).apply { setSingleLine(true) })
            if (name != null) addView(k.tv(address, 12f, k.dim(150)))
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(6) })
        head.addView(IconBtn(this, IconBtn.CALL).apply {
            color = k.accent
            setOnClickListener {
                try {
                    val u = Uri.parse("tel:" + Uri.encode(address))
                    if (checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) startActivity(Intent(Intent.ACTION_CALL, u))
                    else startActivity(Intent(Intent.ACTION_DIAL, u))
                } catch (e: Exception) { }
            }
        }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        root.addView(head, k.lp())

        lv = ListView(this).apply {
            divider = null; selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false; setPadding(0, k.dp(6), 0, k.dp(6)); adapter = this@SmsChatActivity.adapter
            transcriptMode = ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL
        }
        root.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))

        input = EditText(this).apply {
            hint = "Message likho"; setHintTextColor(Color.argb(120, 255, 255, 255)); setTextColor(Color.WHITE)
            textSize = 15f; background = null; maxLines = 4
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(k.dp(18), k.dp(10), k.dp(14), k.dp(10))
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(10), k.dp(6), k.dp(10), k.dp(8)) }
        bar.addView(FrameLayout(this).apply { background = k.glass(24, 34, 110); addView(input, FrameLayout.LayoutParams(-1, -2)) },
            LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(IconBtn(this, IconBtn.SEND).apply {
            color = Color.BLACK
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(k.accent, k.accent2)).apply { shape = GradientDrawable.OVAL }
            setOnClickListener { send() }
        }, LinearLayout.LayoutParams(k.dp(46), k.dp(46)).apply { marginStart = k.dp(8) })
        root.addView(bar, k.lp())
        setContentView(root)

        if (checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED)
            Toast.makeText(this, "Purane messages dekhne ke liye Messages kholkar ijazat do", Toast.LENGTH_LONG).show()
        reload()
    }

    override fun onResume() {
        super.onResume()
        try { contentResolver.registerContentObserver(Uri.parse("content://sms"), true, obs) } catch (e: Exception) { }
        SmsData.markSeen(this, key)
    }

    override fun onPause() {
        SmsData.markSeen(this, key)
        try { contentResolver.unregisterContentObserver(obs) } catch (e: Exception) { }
        super.onPause()
    }

    private fun reload() {
        Thread {
            val msgs = SmsData.thread(this, key)
            val out = ArrayList<Item>()
            var lastDay = -1; var lastYear = -1
            val cal = Calendar.getInstance()
            val today = Calendar.getInstance()
            for (m in msgs) {
                cal.timeInMillis = m.date
                val day = cal.get(Calendar.DAY_OF_YEAR); val yr = cal.get(Calendar.YEAR)
                if (day != lastDay || yr != lastYear) {
                    lastDay = day; lastYear = yr
                    val diff = (today.get(Calendar.YEAR) - yr) * 366 + (today.get(Calendar.DAY_OF_YEAR) - day)
                    out.add(Item(if (diff == 0) "Aaj" else if (diff == 1) "Kal" else dfmt.format(Date(m.date)), null))
                }
                out.add(Item(null, m))
            }
            runOnUiThread { items = out; adapter.notifyDataSetChanged(); lv.setSelection(adapter.count - 1) }
        }.start()
    }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        if (!SmsData.canSend(this)) { pending = t; sendPerm.launch(Manifest.permission.SEND_SMS); return }
        doSend(t)
    }

    private fun doSend(t: String) {
        if (SmsData.send(this, address, t)) { input.setText(""); reload() }
        else Toast.makeText(this, "Message nahi ja saka", Toast.LENGTH_SHORT).show()
    }

    private fun sepView(s: String, cv: View?): View {
        val v = (cv as? TextView) ?: TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 11f; setTextColor(k.dim(160)); typeface = k.tf
            setPadding(k.dp(12), k.dp(10), k.dp(12), k.dp(6)); letterSpacing = 0.08f
        }
        v.text = s
        return v
    }

    private fun bubble(m: SmsData.Msg, cv: View?): View {
        val maxW = (resources.displayMetrics.widthPixels * 0.78f).toInt()
        val outer = (cv as? FrameLayout) ?: FrameLayout(this).apply {
            setPadding(k.dp(12), k.dp(2), k.dp(12), k.dp(2))
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL; setPadding(k.dp(14), k.dp(9), k.dp(14), k.dp(7))
                addView(TextView(context).apply { textSize = 15f; typeface = k.tf; maxWidth = maxW; setTextIsSelectable(false) })
                addView(TextView(context).apply { textSize = 10f; typeface = k.tf; gravity = Gravity.END })
            }, FrameLayout.LayoutParams(-2, -2))
        }
        val box = outer.getChildAt(0) as LinearLayout
        val out = m.type == 2
        val lp = box.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (out) Gravity.END else Gravity.START
        box.layoutParams = lp
        box.background = if (out) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(k.accent, k.accent2)).apply {
            cornerRadii = floatArrayOf(k.dp(20).toFloat(), k.dp(20).toFloat(), k.dp(20).toFloat(), k.dp(20).toFloat(), k.dp(5).toFloat(), k.dp(5).toFloat(), k.dp(20).toFloat(), k.dp(20).toFloat())
        } else GradientDrawable().apply {
            cornerRadii = floatArrayOf(k.dp(20).toFloat(), k.dp(20).toFloat(), k.dp(20).toFloat(), k.dp(20).toFloat(), k.dp(20).toFloat(), k.dp(20).toFloat(), k.dp(5).toFloat(), k.dp(5).toFloat())
            setColor(Color.argb(34, 255, 255, 255)); setStroke(k.dp(1), k.al(k.accent, 60))
        }
        (box.getChildAt(0) as TextView).apply { text = m.body; setTextColor(if (out) Color.BLACK else k.textC) }
        (box.getChildAt(1) as TextView).apply { text = tfmt.format(Date(m.date)); setTextColor(if (out) Color.argb(150, 0, 0, 0) else k.dim(130)) }
        box.setOnLongClickListener {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("sms", m.body))
            Toast.makeText(this, "Copy ho gaya", Toast.LENGTH_SHORT).show(); true
        }
        return outer
    }
}
