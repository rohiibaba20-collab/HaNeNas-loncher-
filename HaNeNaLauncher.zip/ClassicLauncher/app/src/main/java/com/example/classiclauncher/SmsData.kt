package com.example.classiclauncher

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import org.json.JSONArray
import org.json.JSONObject

/**
 * Messages ka data. Hum phone ke default SMS app nahi hain, isliye padh sakte hain aur bhej sakte hain,
 * par system ke andar "padha hua" nishan ya delete nahi kar sakte. Bheje hue message ek chhote local record mein bhi rakhte hain,
 * taake aapki apni chat mein dikhein (kuch phones bhejne par khud save nahi karte).
 */
object SmsData {
    class Msg(val address: String, val body: String, val date: Long, val type: Int, val read: Boolean)   // type 1 = aaya, 2 = gaya
    class Conv(val key: String, val address: String, val last: Msg, val unread: Int, val count: Int)

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("sms", Context.MODE_PRIVATE)

    fun canRead(c: Context) = c.checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
    fun canSend(c: Context) = c.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

    fun keyOf(addr: String) = ContactsData.norm(addr)

    fun seen(c: Context, key: String): Long = sp(c).getLong("seen_$key", 0L)
    fun markSeen(c: Context, key: String) { sp(c).edit().putLong("seen_$key", System.currentTimeMillis()).apply() }

    private fun addLocal(c: Context, address: String, body: String, date: Long) {
        try {
            val arr = JSONArray(sp(c).getString("local", "[]"))
            arr.put(JSONObject().put("a", address).put("b", body).put("d", date))
            val keep = JSONArray()
            for (i in maxOf(0, arr.length() - 400) until arr.length()) keep.put(arr.get(i))
            sp(c).edit().putString("local", keep.toString()).apply()
        } catch (e: Exception) { }
    }

    private fun provider(c: Context): List<Msg> {
        if (!canRead(c)) return emptyList()
        val out = ArrayList<Msg>()
        try {
            c.contentResolver.query(Uri.parse("content://sms"), arrayOf("address", "body", "date", "type", "read"), null, null, "date DESC")?.use { q ->
                while (q.moveToNext() && out.size < 6000) {
                    val type = q.getInt(3)
                    if (type == 3) continue                         // draft
                    out.add(Msg(q.getString(0) ?: "", q.getString(1) ?: "", q.getLong(2), if (type == 1) 1 else 2, q.getInt(4) == 1))
                }
            }
        } catch (e: Exception) { }
        return out
    }

    private fun localMsgs(c: Context, prov: List<Msg>): List<Msg> {
        val out = ArrayList<Msg>()
        try {
            val arr = JSONArray(sp(c).getString("local", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val a = o.getString("a"); val b = o.getString("b"); val d = o.getLong("d")
                val dup = prov.any { it.type == 2 && keyOf(it.address) == keyOf(a) && it.body == b && Math.abs(it.date - d) < 600_000L }
                if (!dup) out.add(Msg(a, b, d, 2, true))
            }
        } catch (e: Exception) { }
        return out
    }

    /** Sab messages, nayi se purani */
    fun all(c: Context): List<Msg> {
        val prov = provider(c)
        return (prov + localMsgs(c, prov)).sortedByDescending { it.date }
    }

    fun conversations(c: Context): List<Conv> {
        val groups = LinkedHashMap<String, MutableList<Msg>>()
        for (m in all(c)) groups.getOrPut(keyOf(m.address)) { ArrayList() }.add(m)
        val out = ArrayList<Conv>()
        for ((key, list) in groups) {
            val seenAt = seen(c, key)
            val unread = list.count { it.type == 1 && !it.read && it.date > seenAt }
            out.add(Conv(key, list[0].address, list[0], unread, list.size))
        }
        return out
    }

    /** Ek chat ke messages, purane se naye */
    fun thread(c: Context, key: String): List<Msg> = all(c).filter { keyOf(it.address) == key }.reversed()

    fun send(c: Context, address: String, body: String): Boolean {
        if (!canSend(c) || body.isBlank() || address.isBlank()) return false
        return try {
            @Suppress("DEPRECATION")
            val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            val parts = sm.divideMessage(body)
            if (parts.size > 1) sm.sendMultipartTextMessage(address, null, parts, null, null)
            else sm.sendTextMessage(address, null, body, null, null)
            addLocal(c, address, body, System.currentTimeMillis())
            true
        } catch (e: Exception) { false }
    }
}
