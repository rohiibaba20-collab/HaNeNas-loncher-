package com.example.classiclauncher

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import java.util.concurrent.Executors

/** Gallery / Video ke chhote thumbnails: cache ke saath, peeche (background) mein load hote hain */
object Thumbs {
    private val cache = LruCache<String, Bitmap>(140)
    private val none = HashSet<String>()
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun key(video: Boolean, id: Long, w: Int, h: Int) = (if (video) "v" else "i") + id + "_" + w + "x" + h

    fun peek(k: String): Bitmap? = cache.get(k)

    /** cb main thread par aata hai; thumbnail na ban sake to null */
    fun load(ctx: Context, uri: Uri, id: Long, video: Boolean, w: Int, h: Int, cb: (Bitmap?) -> Unit) {
        val k = key(video, id, w, h)
        cache.get(k)?.let { cb(it); return }
        if (none.contains(k)) { cb(null); return }
        val app = ctx.applicationContext
        pool.execute {
            var b: Bitmap? = null
            try {
                b = if (Build.VERSION.SDK_INT >= 29) app.contentResolver.loadThumbnail(uri, Size(w, h), null)
                else if (video) MediaStore.Video.Thumbnails.getThumbnail(app.contentResolver, id, MediaStore.Video.Thumbnails.MINI_KIND, null)
                else MediaStore.Images.Thumbnails.getThumbnail(app.contentResolver, id, MediaStore.Images.Thumbnails.MINI_KIND, null)
            } catch (e: Exception) { }
            main.post {
                if (b != null) cache.put(k, b) else none.add(k)
                cb(b)
            }
        }
    }
}
