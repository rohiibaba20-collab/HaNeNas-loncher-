package com.example.classiclauncher

import android.Manifest
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/** Card ka thumbnail: gol kone, neeche andhera, duration, aur dekhne ka bacha hua hissa (resume bar) */
class VideoThumbView(ctx: android.content.Context, private val k: Skin) : View(ctx) {
    var bmp: Bitmap? = null
        set(v) { field = v; shader = null; invalidate() }
    var dur = ""
    var progress = 0f
    private var shader: BitmapShader? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private val m = Matrix()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { shader = null }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val r = k.dp(16).toFloat()
        rf.set(0f, 0f, w, h)
        val b = bmp
        p.style = Paint.Style.FILL
        if (b != null) {
            if (shader == null) {
                val sh = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
                val sc = maxOf(w / b.width, h / b.height)
                m.reset(); m.setScale(sc, sc); m.postTranslate((w - b.width * sc) / 2f, (h - b.height * sc) / 2f)
                sh.setLocalMatrix(m); shader = sh
            }
            p.shader = shader; c.drawRoundRect(rf, r, r, p); p.shader = null
        } else { p.color = Color.rgb(28, 28, 34); c.drawRoundRect(rf, r, r, p) }
        // neeche halka andhera
        p.color = Color.argb(110, 0, 0, 0)
        rf.set(0f, h * 0.55f, w, h); c.save(); c.clipRect(0f, h * 0.55f, w, h)
        rf.set(0f, 0f, w, h); c.drawRoundRect(rf, r, r, p); c.restore()
        // play nishan
        val cx = w / 2f; val cy = h / 2f; val u = k.dp(16).toFloat()
        p.color = Color.argb(120, 0, 0, 0); c.drawCircle(cx, cy, u * 1.45f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = k.dp(1).toFloat(); p.color = k.al(k.accent, 220); c.drawCircle(cx, cy, u * 1.45f, p)
        p.style = Paint.Style.FILL; p.color = k.accent
        val path = android.graphics.Path()
        path.moveTo(cx - u * 0.45f, cy - u * 0.65f); path.lineTo(cx + u * 0.7f, cy); path.lineTo(cx - u * 0.45f, cy + u * 0.65f); path.close()
        c.drawPath(path, p)
        // duration
        p.typeface = k.tf; p.textSize = k.dp(11).toFloat(); p.textAlign = Paint.Align.RIGHT; p.color = Color.WHITE
        c.drawText(dur, w - k.dp(8).toFloat(), h - k.dp(10).toFloat(), p)
        p.textAlign = Paint.Align.LEFT
        if (progress > 0.01f) {
            val ph = k.dp(3).toFloat()
            p.color = Color.argb(90, 255, 255, 255); c.drawRect(k.dp(10).toFloat(), h - k.dp(4).toFloat() - ph, w - k.dp(60).toFloat(), h - k.dp(4).toFloat(), p)
            p.color = k.accent; c.drawRect(k.dp(10).toFloat(), h - k.dp(4).toFloat() - ph, k.dp(10).toFloat() + (w - k.dp(70).toFloat()) * progress.coerceAtMost(1f), h - k.dp(4).toFloat(), p)
        }
    }
}

/** HaNeNa Video: phone ki videos ka cinema jaisa grid; dabate hi apna player khulta hai */
class VideoActivity : AppCompatActivity() {

    private class V(val id: Long, val title: String, val dur: Long, val size: Long, val w: Int, val h: Int, val uri: Uri)

    private lateinit var k: Skin
    private lateinit var grid: GridView
    private lateinit var msg: TextView
    private lateinit var count: TextView
    private var all: List<V> = emptyList()
    private var shown: List<V> = emptyList()

    private val perm: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

    private val ask = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) load() else showNeed() }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).toInt()
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int) = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val colW = (resources.displayMetrics.widthPixels - k.dp(12 * 3)) / 2
            val cell = (cv as? LinearLayout) ?: LinearLayout(this@VideoActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(VideoThumbView(context, k), LinearLayout.LayoutParams(colW, colW * 9 / 16))
                addView(k.tv("", 13f).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = k.dp(6) })
                addView(k.tv("", 11f, k.dim(140)).apply { setSingleLine(true) })
            }
            val v = shown[p]
            val th = cell.getChildAt(0) as VideoThumbView
            th.dur = fmt(v.dur)
            val saved = getSharedPreferences("video", MODE_PRIVATE).getLong("p" + v.uri.toString().hashCode(), 0L)
            th.progress = if (v.dur > 0 && saved > 5000L) saved.toFloat() / v.dur else 0f
            th.tag = v.id
            val tk = Thumbs.key(true, v.id, 480, 270)
            val have = Thumbs.peek(tk)
            th.bmp = have
            if (have == null) Thumbs.load(this@VideoActivity, v.uri, v.id, true, 480, 270) { b -> if (th.tag == v.id) th.bmp = b }
            (cell.getChildAt(1) as TextView).text = v.title
            (cell.getChildAt(2) as TextView).text = (if (v.h > 0) "${minOf(v.w, v.h)}p  •  " else "") + "%.1f MB".format(v.size / 1048576f)
            cell.setPadding(k.dp(6), k.dp(6), k.dp(6), k.dp(8))
            cell.setOnClickListener { play(p) }
            return cell
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        k = Skin(this)
        window.statusBarColor = k.bgTop(); window.navigationBarColor = Color.BLACK
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true; background = k.gradient() }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(8), k.dp(4), k.dp(16), 0) }
        head.addView(IconBtn(this, IconBtn.BACK).apply { color = k.accent; setOnClickListener { finish() } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        head.addView(k.tv("HaNeNa Video", 26f, k.textC, true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(6) })
        count = k.tv("", 12f, k.accent)
        head.addView(count, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = k.dp(10) })
        head.addView(k.button("Link") { askLink() })
        root.addView(head, k.lp())

        val et = EditText(this).apply {
            hint = "Video dhundo"; setHintTextColor(Color.argb(120, 255, 255, 255)); setTextColor(Color.WHITE)
            textSize = 15f; setSingleLine(true); background = null; setPadding(k.dp(20), k.dp(12), k.dp(20), k.dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { filter(s?.toString().orEmpty()) }
            })
        }
        root.addView(FrameLayout(this).apply { background = k.glass(26, 34, 110); addView(et, FrameLayout.LayoutParams(-1, -2)) },
            k.lp(0).apply { setMargins(k.dp(16), k.dp(10), k.dp(16), k.dp(6)) })

        grid = GridView(this).apply {
            numColumns = 2; stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            clipToPadding = false; setPadding(k.dp(6), k.dp(4), k.dp(6), k.dp(14)); adapter = this@VideoActivity.adapter
            verticalSpacing = k.dp(4)
        }
        msg = k.tv("", 14f, k.dim(160)).apply { gravity = Gravity.CENTER; setPadding(k.dp(30), 0, k.dp(30), 0) }
        val frame = FrameLayout(this)
        frame.addView(grid, FrameLayout.LayoutParams(-1, -1)); frame.addView(msg, FrameLayout.LayoutParams(-1, -1))
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) load() else ask.launch(perm)
    }

    override fun onResume() { super.onResume(); adapter.notifyDataSetChanged() }

    private fun showNeed() { msg.text = "Videos dikhane ke liye ijazat do"; msg.visibility = View.VISIBLE }

    private fun load() {
        Thread {
            val out = ArrayList<V>()
            try {
                val base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                val proj = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.DURATION,
                    MediaStore.Video.Media.SIZE, MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT)
                contentResolver.query(base, proj, null, null, MediaStore.Video.Media.DATE_ADDED + " DESC")?.use { q ->
                    while (q.moveToNext()) {
                        val id = q.getLong(0)
                        val name = (q.getString(1) ?: "Video").substringBeforeLast('.')
                        out.add(V(id, name, q.getLong(2), q.getLong(3), q.getInt(4), q.getInt(5), ContentUris.withAppendedId(base, id)))
                    }
                }
            } catch (e: Exception) { }
            runOnUiThread { all = out; filter(""); msg.visibility = if (out.isEmpty()) View.VISIBLE else View.GONE; if (out.isEmpty()) msg.text = "Phone mein koi video nahi mili" }
        }.start()
    }

    private fun filter(q: String) {
        val t = q.trim()
        shown = if (t.isEmpty()) all else all.filter { it.title.contains(t, true) }
        count.text = "${shown.size} videos"
        adapter.notifyDataSetChanged()
    }

    private fun play(p: Int) {
        val list = shown.take(400)
        val idx = p.coerceIn(0, list.size - 1)
        startActivity(Intent(this, VideoPlayerActivity::class.java)
            .putExtra(VideoPlayerActivity.X_URIS, list.map { it.uri.toString() }.toTypedArray())
            .putExtra(VideoPlayerActivity.X_TITLES, list.map { it.title }.toTypedArray())
            .putExtra(VideoPlayerActivity.X_INDEX, idx))
    }

    private fun askLink() {
        val et = EditText(this).apply { inputType = InputType.TYPE_TEXT_VARIATION_URI; hint = "https://... (mp4, m3u8, mpd)" }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Link se chalao").setMessage("m3u8 / mpd links mein quality badal sakte ho.").setView(et)
            .setPositiveButton("Chalao") { _, _ ->
                val u = et.text.toString().trim()
                if (u.isNotEmpty()) startActivity(Intent(this, VideoPlayerActivity::class.java)
                    .putExtra(VideoPlayerActivity.X_URIS, arrayOf(u)).putExtra(VideoPlayerActivity.X_TITLES, arrayOf(u.substringAfterLast('/')))
                    .putExtra(VideoPlayerActivity.X_INDEX, 0))
            }.setNegativeButton("Cancel", null).show()
    }
}
