package com.example.classiclauncher

import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.abs

/** Video ko sahi aspect mein dikhane wala dabba: Fit / Fill / Zoom / 16:9 / 4:3 */
class VideoFrame(ctx: Context) : FrameLayout(ctx) {
    val surface = SurfaceView(ctx)
    var vw = 16
    var vh = 9
    var par = 1f
    var mode = 0

    init { addView(surface, LayoutParams(-1, -1)) }

    override fun onMeasure(ws: Int, hs: Int) {
        val w = MeasureSpec.getSize(ws); val h = MeasureSpec.getSize(hs)
        setMeasuredDimension(w, h)
        var ar = if (vh > 0) vw * par / vh else 1.7778f
        if (mode == 3) ar = 16f / 9f
        if (mode == 4) ar = 4f / 3f
        val fr = if (h > 0) w.toFloat() / h else 1f
        var cw = w; var ch = h
        if (mode == 1) {
            // poori screen tak kheencho
        } else if (mode == 2) {
            if (fr > ar) { cw = w; ch = (w / ar).toInt() } else { ch = h; cw = (h * ar).toInt() }
        } else {
            if (fr > ar) { ch = h; cw = (h * ar).toInt() } else { cw = w; ch = (w / ar).toInt() }
        }
        surface.measure(MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = surface.measuredWidth; val ch = surface.measuredHeight
        val x = ((r - l) - cw) / 2; val y = ((b - t) - ch) / 2
        surface.layout(x, y, x + cw, y + ch)
    }
}

/**
 * HaNeNa ka apna video player (ExoPlayer par): gestures (double tap = 10 second, side par upar-neeche = awaaz / roshni, side mein kheencho = seek),
 * audio track badlo, subtitles, quality, speed, aspect, orientation, repeat, aur "yahan se dobara dekho".
 */
class VideoPlayerActivity : AppCompatActivity() {

    companion object {
        const val X_URIS = "uris"
        const val X_TITLES = "titles"
        const val X_INDEX = "index"
    }

    private lateinit var k: Skin
    private lateinit var player: ExoPlayer
    private lateinit var frame: VideoFrame
    private lateinit var root: FrameLayout
    private lateinit var controls: FrameLayout
    private lateinit var titleTv: TextView
    private lateinit var seek: SeekBar
    private lateinit var curTv: TextView
    private lateinit var totTv: TextView
    private lateinit var playBtn: IconBtn
    private lateinit var subTv: TextView
    private lateinit var infoTv: TextView
    private lateinit var sheet: LinearLayout
    private lateinit var sheetBody: LinearLayout
    private lateinit var sheetTabs: FrameLayout
    private lateinit var scrim: View

    private var uris: List<String> = emptyList()
    private var titles: List<String> = emptyList()
    private var index = 0
    private var controlsOn = true
    private var seeking = false
    private var tracks: Tracks = Tracks.EMPTY
    private var orient = 0
    private var loop = 0
    private var boost = 0
    private var enhancer: LoudnessEnhancer? = null
    private var cat = 0
    private var gMode = 0
    private var startPos = 0L
    private var startB = 0.5f
    private var startV = 0
    private var seekTarget = -1L
    private var lastSave = 0L
    private val hnd = Handler(Looper.getMainLooper())
    private val hideRun = Runnable { showControls(false) }
    private val infoHide = Runnable { infoTv.visibility = View.GONE }
    private val tick = object : Runnable { override fun run() { updateProgress(); hnd.postDelayed(this, 400L) } }
    private val prefs by lazy { getSharedPreferences("video", MODE_PRIVATE) }
    private val audio by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).toInt().coerceAtLeast(0)
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
    }

    private fun posKey() = "p" + uris[index].hashCode()

    // ------------------------------ player ke events ------------------------------
    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playBtn.kind = if (isPlaying) IconBtn.PAUSE else IconBtn.PLAY; playBtn.invalidate()
            if (isPlaying) showControls(controlsOn) else showControls(true)
        }
        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_ENDED) onEnded()
            if (state == Player.STATE_READY && boost > 0) applyBoost(boost)
        }
        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (videoSize.width > 0 && videoSize.height > 0) {
                frame.vw = videoSize.width; frame.vh = videoSize.height; frame.par = videoSize.pixelWidthHeightRatio
                frame.requestLayout()
                if (orient == 0) requestedOrientation =
                    if (videoSize.width >= videoSize.height) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
        }
        override fun onTracksChanged(t: Tracks) {
            tracks = t
            if (sheet.visibility == View.VISIBLE) openSheet(cat)
        }
        override fun onCues(cueGroup: CueGroup) {
            val s = cueGroup.cues.joinToString("\n") { it.text?.toString() ?: "" }.trim()
            subTv.text = s
            subTv.visibility = if (s.isEmpty()) View.GONE else View.VISIBLE
        }
        override fun onPlayerError(error: PlaybackException) { showInfo("Video chal nahi paya: " + (error.message ?: "error"), 4000L) }
    }

    // ------------------------------ screen ------------------------------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        k = Skin(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        uris = intent.getStringArrayExtra(X_URIS)?.toList() ?: emptyList()
        if (uris.isEmpty()) intent.data?.let { uris = listOf(it.toString()) }
        titles = intent.getStringArrayExtra(X_TITLES)?.toList() ?: emptyList()
        if (uris.isEmpty()) { finish(); return }
        index = intent.getIntExtra(X_INDEX, 0).coerceIn(0, uris.size - 1)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
        buildUi()
        hideBars()
        player = ExoPlayer.Builder(this).build()
        player.setVideoSurfaceView(frame.surface)
        player.addListener(listener)
        playIndex(index)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (sheet.visibility == View.VISIBLE) closeSheet() else finish() }
        })
    }

    private fun hideBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) hideBars() }

    override fun onResume() { super.onResume(); hnd.removeCallbacks(tick); hnd.post(tick) }

    override fun onPause() {
        hnd.removeCallbacks(tick)
        if (::player.isInitialized) { player.pause(); saveProgress(false) }
        super.onPause()
    }

    override fun onDestroy() {
        try { enhancer?.release() } catch (e: Exception) { }
        if (::player.isInitialized) { try { player.release() } catch (e: Exception) { } }
        super.onDestroy()
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        frame = VideoFrame(this)
        root.addView(frame, FrameLayout.LayoutParams(-1, -1))

        subTv = TextView(this).apply {
            textSize = 17f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; visibility = View.GONE
            setShadowLayer(4f, 0f, 1f, Color.BLACK); setPadding(k.dp(14), k.dp(6), k.dp(14), k.dp(6))
            background = GradientDrawable().apply { cornerRadius = k.dp(10).toFloat(); setColor(Color.argb(110, 0, 0, 0)) }
        }
        root.addView(subTv, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = k.dp(110); marginStart = k.dp(30); marginEnd = k.dp(30) })

        controls = FrameLayout(this)
        // ---- upar ----
        titleTv = k.tv("", 16f, Color.WHITE).apply { setSingleLine(true); ellipsize = android.text.TextUtils.TruncateAt.END }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(8), k.dp(8), k.dp(12), k.dp(28))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(200, 0, 0, 0), 0))
        }
        top.addView(IconBtn(this, IconBtn.BACK).apply { color = Color.WHITE; setOnClickListener { finish() } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        top.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(6) })
        top.addView(IconBtn(this, IconBtn.ROTATE).apply { color = Color.WHITE; setOnClickListener { rotateNow() } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        top.addView(IconBtn(this, IconBtn.GEAR).apply { color = k.accent; setOnClickListener { openSheet(0) } }, LinearLayout.LayoutParams(k.dp(44), k.dp(44)))
        controls.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // ---- neeche ----
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(k.dp(16), k.dp(30), k.dp(16), k.dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(Color.argb(210, 0, 0, 0), 0))
        }
        curTv = k.tv("0:00", 12f, Color.WHITE); totTv = k.tv("0:00", 12f, Color.WHITE)
        seek = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(k.accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(k.accent)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(80, 255, 255, 255))
            secondaryProgressTintList = android.content.res.ColorStateList.valueOf(Color.argb(120, 255, 255, 255))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, pr: Int, user: Boolean) {
                    if (user) { val d = player.duration; if (d > 0) curTv.text = fmt(d * pr / 1000) }
                }
                override fun onStartTrackingTouch(s: SeekBar?) { seeking = true; hnd.removeCallbacks(hideRun) }
                override fun onStopTrackingTouch(s: SeekBar?) {
                    seeking = false
                    val d = player.duration
                    if (d > 0) player.seekTo(d * (s?.progress ?: 0) / 1000)
                    showControls(true)
                }
            })
        }
        val srow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(curTv, LinearLayout.LayoutParams(-2, -2))
            addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
            addView(totTv, LinearLayout.LayoutParams(-2, -2))
        }
        bottom.addView(srow, LinearLayout.LayoutParams(-1, -2))
        playBtn = IconBtn(this, IconBtn.PLAY).apply { color = k.accent; ring = true; setOnClickListener { togglePlay() } }
        val crow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        fun b(kind: Int, sz: Int, tap: () -> Unit) = IconBtn(this, kind).apply { color = Color.WHITE; setOnClickListener { tap() } }
        crow.addView(b(IconBtn.PREV, 0) { playIndex(index - 1) }, LinearLayout.LayoutParams(k.dp(52), k.dp(52)))
        crow.addView(b(IconBtn.REW, 0) { seekBy(-10_000L) }, LinearLayout.LayoutParams(k.dp(52), k.dp(52)))
        crow.addView(playBtn, LinearLayout.LayoutParams(k.dp(68), k.dp(68)).apply { setMargins(k.dp(12), 0, k.dp(12), 0) })
        crow.addView(b(IconBtn.FWD, 0) { seekBy(10_000L) }, LinearLayout.LayoutParams(k.dp(52), k.dp(52)))
        crow.addView(b(IconBtn.NEXT, 0) { playIndex(index + 1) }, LinearLayout.LayoutParams(k.dp(52), k.dp(52)))
        bottom.addView(crow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = k.dp(2) })
        controls.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        root.addView(controls, FrameLayout.LayoutParams(-1, -1))
        ViewCompat.setOnApplyWindowInsetsListener(controls) { v, wi ->
            val ins = wi.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(ins.left, ins.top, ins.right, ins.bottom)
            wi
        }

        infoTv = TextView(this).apply {
            textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = k.tf; visibility = View.GONE
            setPadding(k.dp(20), k.dp(10), k.dp(20), k.dp(10))
            background = GradientDrawable().apply { cornerRadius = k.dp(22).toFloat(); setColor(Color.argb(170, 0, 0, 0)); setStroke(k.dp(1), k.al(k.accent, 160)) }
        }
        root.addView(infoTv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        // ---- settings sheet ----
        scrim = View(this).apply { setBackgroundColor(Color.argb(90, 0, 0, 0)); visibility = View.GONE; setOnClickListener { closeSheet() } }
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        sheetTabs = FrameLayout(this)
        sheetBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; setPadding(k.dp(12), k.dp(12), k.dp(12), k.dp(12))
            background = GradientDrawable().apply { cornerRadius = k.dp(22).toFloat(); setColor(Color.argb(244, 14, 14, 18)); setStroke(k.dp(1), k.al(k.accent, 80)) }
            isClickable = true
            addView(sheetTabs, LinearLayout.LayoutParams(-1, -2))
            addView(ScrollView(context).apply { isVerticalScrollBarEnabled = false; addView(sheetBody) }, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = k.dp(8) })
        }
        root.addView(sheet, FrameLayout.LayoutParams(k.dp(330), -1, Gravity.END))

        // ---- touch: double tap, seek, roshni, awaaz ----
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                gMode = 0; seekTarget = -1L
                startPos = player.currentPosition
                val b = window.attributes.screenBrightness
                startB = if (b < 0f) 0.5f else b
                startV = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                return true
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { showControls(!controlsOn); return true }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val x = e.x / root.width
                if (x < 0.33f) seekBy(-10_000L) else if (x > 0.67f) seekBy(10_000L) else togglePlay()
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                val x1 = e1?.x ?: e2.x; val y1 = e1?.y ?: e2.y
                val tx = e2.x - x1; val ty = e2.y - y1
                if (gMode == 0) gMode = if (abs(tx) > abs(ty)) 1 else if (x1 < root.width / 2f) 2 else 3
                when (gMode) {
                    1 -> {
                        val d = player.duration
                        val t = (startPos + tx / root.width * 90_000f).toLong().coerceIn(0L, if (d > 0) d else Long.MAX_VALUE)
                        seekTarget = t
                        val diff = (t - startPos) / 1000
                        showInfo(fmt(t) + "   (" + (if (diff >= 0) "+" else "") + diff + " s)", 700L)
                    }
                    2 -> {
                        val v = (startB - ty / root.height * 1.3f).coerceIn(0.02f, 1f)
                        val lp = window.attributes; lp.screenBrightness = v; window.attributes = lp
                        showInfo("Roshni  " + (v * 100).toInt() + "%", 700L)
                    }
                    else -> {
                        val mx = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        val v = (startV - ty / root.height * mx * 1.4f).toInt().coerceIn(0, mx)
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0)
                        showInfo("Awaaz  $v / $mx", 700L)
                    }
                }
                return true
            }
        })
        root.setOnTouchListener { _, e ->
            gd.onTouchEvent(e)
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (gMode == 1 && seekTarget >= 0L) player.seekTo(seekTarget)
                gMode = 0; seekTarget = -1L
            }
            true
        }
        setContentView(root)
    }

    // ------------------------------ chalane ke kaam ------------------------------
    private fun playIndex(i: Int) {
        if (i !in uris.indices) return
        if (::player.isInitialized && player.mediaItemCount > 0) saveProgress(false)
        index = i
        val u = Uri.parse(uris[i])
        titleTv.text = titles.getOrNull(i) ?: (u.lastPathSegment ?: "Video")
        player.setMediaItem(MediaItem.fromUri(u))
        player.prepare()
        val saved = prefs.getLong(posKey(), 0L)
        if (saved > 5000L) player.seekTo(saved)
        player.playWhenReady = true
        subTv.visibility = View.GONE
    }

    private fun onEnded() {
        prefs.edit().remove(posKey()).apply()
        if (loop == 1) return
        if (index < uris.size - 1) playIndex(index + 1)
        else if (loop == 2) playIndex(0)
        else showControls(true)
    }

    private fun togglePlay() { if (player.isPlaying) player.pause() else player.play() }

    private fun seekBy(ms: Long) {
        val d = player.duration
        player.seekTo((player.currentPosition + ms).coerceIn(0L, if (d > 0) d else Long.MAX_VALUE))
        showInfo((if (ms > 0) "+" else "-") + abs(ms / 1000) + " s", 600L)
    }

    private fun saveProgress(clear: Boolean) {
        val d = player.duration; val pos = player.currentPosition
        if (clear || (d > 0 && pos > d - 8000L)) prefs.edit().remove(posKey()).apply()
        else if (pos > 5000L) prefs.edit().putLong(posKey(), pos).apply()
    }

    private fun updateProgress() {
        val d = player.duration; val pos = player.currentPosition
        val dd = if (d > 0) d else 0L
        if (!seeking) {
            seek.progress = if (dd > 0) (pos * 1000 / dd).toInt() else 0
            curTv.text = fmt(pos)
        }
        seek.secondaryProgress = if (dd > 0) (player.bufferedPosition * 1000 / dd).toInt() else 0
        totTv.text = fmt(dd)
        val now = System.currentTimeMillis()
        if (player.isPlaying && now - lastSave > 5000L) { lastSave = now; saveProgress(false) }
    }

    private fun showControls(on: Boolean) {
        controlsOn = on
        controls.animate().cancel()
        if (on) controls.visibility = View.VISIBLE
        controls.animate().alpha(if (on) 1f else 0f).setDuration(220L).withEndAction {
            controls.visibility = if (controlsOn) View.VISIBLE else View.INVISIBLE
        }.start()
        hnd.removeCallbacks(hideRun)
        if (on && player.isPlaying && sheet.visibility != View.VISIBLE) hnd.postDelayed(hideRun, 3500L)
    }

    private fun showInfo(t: String, ms: Long) {
        infoTv.text = t; infoTv.visibility = View.VISIBLE
        hnd.removeCallbacks(infoHide); hnd.postDelayed(infoHide, ms)
    }

    private fun rotateNow() {
        val land = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        setOrient(if (land) 2 else 1)
    }

    private fun setOrient(o: Int) {
        orient = o
        requestedOrientation = when (o) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            3 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR
            else -> if (frame.vw >= frame.vh) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        }
    }

    private fun applyBoost(i: Int) {
        boost = i
        try {
            enhancer?.release(); enhancer = null
            if (i > 0) { val e = LoudnessEnhancer(player.audioSessionId); e.setTargetGain(i * 300); e.setEnabled(true); enhancer = e }
        } catch (e: Exception) { }
    }

    // ------------------------------ settings sheet ------------------------------
    private fun opt(label: String, sub: String?, sel: Boolean, tap: () -> Unit): View {
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(k.dp(12), k.dp(11), k.dp(12), k.dp(11))
            background = GradientDrawable().apply {
                cornerRadius = k.dp(14).toFloat()
                if (sel) { setColor(k.al(k.accent, 45)); setStroke(k.dp(1), k.accent) } else setColor(Color.argb(18, 255, 255, 255))
            }
            isClickable = true; setOnClickListener { tap() }
        }
        row.addView(View(this).apply { background = k.oval(if (sel) k.accent else Color.TRANSPARENT, if (sel) k.accent else k.dim(120)) },
            LinearLayout.LayoutParams(k.dp(14), k.dp(14)))
        row.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(k.tv(label, 14f, if (sel) k.accent else k.textC))
            if (sub != null && sub.isNotEmpty()) addView(k.tv(sub, 11f, k.dim(140)))
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = k.dp(12) })
        return row
    }

    private fun addOpt(label: String, sub: String?, sel: Boolean, tap: () -> Unit) { sheetBody.addView(opt(label, sub, sel, tap), k.lp(6)) }
    private fun note(t: String) { sheetBody.addView(k.tv(t, 12f, k.dim(140)), k.lp(10)) }
    private fun head(t: String) { sheetBody.addView(k.tv(t, 14f, k.textC), k.lp(16)) }

    private fun openSheet(c: Int) {
        cat = c
        val sw = minOf(k.dp(330), (resources.displayMetrics.widthPixels * 0.92f).toInt())
        sheet.layoutParams = FrameLayout.LayoutParams(sw, -1, Gravity.END).apply { setMargins(k.dp(8), k.dp(10), k.dp(10), k.dp(10)) }
        sheet.visibility = View.VISIBLE; scrim.visibility = View.VISIBLE
        sheetTabs.removeAllViews()
        sheetTabs.addView(k.chips(listOf("Audio", "Subs", "Quality", "Speed", "Screen"), c) { openSheet(it) })
        sheetBody.removeAllViews()
        when (c) { 0 -> audioTab(); 1 -> subsTab(); 2 -> qualityTab(); 3 -> speedTab(); else -> screenTab() }
        hnd.removeCallbacks(hideRun)
    }

    private fun closeSheet() { sheet.visibility = View.GONE; scrim.visibility = View.GONE; showControls(true) }

    private fun langName(l: String?): String? {
        if (l.isNullOrEmpty() || l == "und") return null
        return try { java.util.Locale(l).displayLanguage.takeIf { it.isNotBlank() } } catch (e: Exception) { l }
    }

    private fun pick(g: Tracks.Group, i: Int) {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(g.type, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, i)).build()
    }

    private fun audioTab() {
        var n = 0
        for (g in tracks.groups) {
            if (g.type != C.TRACK_TYPE_AUDIO) continue
            for (i in 0 until g.length) {
                n++
                val f = g.getTrackFormat(i)
                val title = f.label ?: langName(f.language) ?: "Audio $n"
                val ch = when (f.channelCount) { 1 -> "Mono"; 2 -> "Stereo"; 6 -> "5.1"; 8 -> "7.1"; else -> if (f.channelCount > 0) "${f.channelCount} ch" else "" }
                val codec = (f.sampleMimeType ?: "").substringAfter('/').uppercase()
                addOpt(title, listOf(ch, codec).filter { it.isNotEmpty() }.joinToString("  •  "), g.isTrackSelected(i)) { pick(g, i) }
            }
        }
        if (n == 0) note("Is video mein koi audio track nahi mila.")
        else if (n == 1) note("Is video mein sirf ek audio track hai. Dusre track wali videos (jaise dual audio) mein yahan se badal sakte ho.")
        head("Awaaz boost")
        sheetBody.addView(k.chips(listOf("Off", "+3 dB", "+6 dB", "+9 dB"), boost) { applyBoost(it); openSheet(0) }, k.lp(8))
    }

    private fun subsTab() {
        var any = false
        var n = 0
        for (g in tracks.groups) if (g.type == C.TRACK_TYPE_TEXT) for (i in 0 until g.length) if (g.isTrackSelected(i)) any = true
        val off = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT) || !any
        addOpt("Band", null, off) {
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
            subTv.visibility = View.GONE; openSheet(1)
        }
        for (g in tracks.groups) {
            if (g.type != C.TRACK_TYPE_TEXT) continue
            for (i in 0 until g.length) {
                n++
                val f = g.getTrackFormat(i)
                addOpt(f.label ?: langName(f.language) ?: "Subtitle $n", (f.sampleMimeType ?: "").substringAfter('/').uppercase(), g.isTrackSelected(i) && !off) { pick(g, i) }
            }
        }
        if (n == 0) note("Is video ke andar subtitles nahi hain.")
    }

    private fun qualityTab() {
        val params = player.trackSelectionParameters
        var cur: Format? = null
        var count = 0
        for (g in tracks.groups) {
            if (g.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until g.length) { count++; if (g.isTrackSelected(i)) cur = g.getTrackFormat(i) }
        }
        cur?.let {
            val fps = if (it.frameRate > 0) "  •  " + it.frameRate.toInt() + " fps" else ""
            val br = if (it.bitrate > 0) "  •  " + String.format("%.1f", it.bitrate / 1_000_000f) + " Mbps" else ""
            note("Abhi: " + it.width + " x " + it.height + fps + br)
        }
        val hasOverride = params.overrides.values.any { it.type == C.TRACK_TYPE_VIDEO }
        addOpt("Auto (behtareen)", null, !hasOverride && params.maxVideoHeight == Int.MAX_VALUE) {
            player.trackSelectionParameters = params.buildUpon().clearOverridesOfType(C.TRACK_TYPE_VIDEO).setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE).build()
            openSheet(2)
        }
        for ((h, ls) in listOf(1080 to 1920, 720 to 1280, 480 to 854, 360 to 640, 240 to 426)) {
            addOpt(h.toString() + "p tak", null, !hasOverride && params.maxVideoHeight == ls) {
                player.trackSelectionParameters = params.buildUpon().clearOverridesOfType(C.TRACK_TYPE_VIDEO).setMaxVideoSize(ls, ls).build()
                openSheet(2)
            }
        }
        if (count > 1) {
            head("Alag alag quality")
            for (g in tracks.groups) {
                if (g.type != C.TRACK_TYPE_VIDEO) continue
                for (i in 0 until g.length) {
                    val f = g.getTrackFormat(i)
                    val br = if (f.bitrate > 0) String.format("%.1f", f.bitrate / 1_000_000f) + " Mbps" else ""
                    addOpt(f.height.toString() + "p", br, g.isTrackSelected(i) && hasOverride) { pick(g, i) }
                }
            }
        } else note("Local file mein ek hi quality hoti hai, isliye yahan badalne ke liye kuch nahi. Quality badalna streaming links (m3u8 / mpd) mein kaam karta hai.")
    }

    private fun speedTab() {
        val cur = player.playbackParameters.speed
        for (s in listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f)) {
            addOpt((if (s == 1f) "Normal  1x" else "${s}x"), null, abs(cur - s) < 0.01f) { player.setPlaybackSpeed(s); openSheet(3) }
        }
    }

    private fun screenTab() {
        head("Screen ka size")
        sheetBody.addView(k.chips(listOf("Fit", "Fill", "Zoom"), if (frame.mode < 3) frame.mode else -1) { frame.mode = it; frame.requestLayout(); openSheet(4) }, k.lp(8))
        sheetBody.addView(k.chips(listOf("16:9", "4:3"), if (frame.mode >= 3) frame.mode - 3 else -1) { frame.mode = it + 3; frame.requestLayout(); openSheet(4) }, k.lp(6))
        head("Screen ghumana")
        sheetBody.addView(k.chips(listOf("Auto", "Landscape", "Portrait", "Sensor"), orient) { setOrient(it); openSheet(4) }, k.lp(8))
        head("Dobara chalana")
        sheetBody.addView(k.chips(listOf("Band", "Ek hi video", "Sab videos"), loop) {
            loop = it
            player.repeatMode = if (it == 1) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
            openSheet(4)
        }, k.lp(8))
    }
}
