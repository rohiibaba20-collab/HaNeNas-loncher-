package com.example.classiclauncher

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.Drawable
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Gol (round) app wheel, smooth ghoomta hai. mode 0 = Circle, 1 = Arc (right side), 2 = Bottom wheel.
 * Draw ke waqt koi naya object nahi banta, isliye kam RAM wale phone par bhi halka chalta hai.
 */
class WheelView(ctx: Context) : View(ctx) {

    class Item(val label: String, val icon: Drawable, val intent: Intent?)
    private class Hit(val item: Item, val x: Float, val y: Float, val r: Float)

    var items: List<Item> = emptyList()
    var mode = 0
    var ringColor = Color.parseColor("#D4AF37")
    var textColor = Color.WHITE
    var tf: Typeface = Typeface.DEFAULT
    var fs = 1f
    var sizeScale = 1f      // wheel ka size
    var iconScale = 1f      // icon ka size
    var onOpen: (Item) -> Unit = {}
    var onLong: () -> Unit = {}
    /** (badla hua angle, wheel ka markaz x, y, radius) */
    var onSpin: (Float, Float, Float, Float) -> Unit = { _, _, _, _ -> }

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val hits = ArrayList<Hit>()

    private var angle = 0f
    private var anim: ValueAnimator? = null
    private var cx = 0f; private var cy = 0f; private var rad = 0f
    private var downX = 0f; private var downY = 0f; private var lastA = 0f
    private var moved = false; private var longDone = false
    private var vt: VelocityTracker? = null
    private var thA = FloatArray(0); private var dsA = FloatArray(0); private var order = IntArray(0)
    private val longRun = Runnable {
        if (!moved) { longDone = true; performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); onLong() }
    }

    private val step get() = if (items.isEmpty()) 360f else 360f / items.size
    private val off get() = if (mode == 1) -90f else 0f

    fun setup() { angle = off; invalidate() }

    private fun setAngle(a: Float) {
        val dl = a - angle
        angle = a
        if (dl != 0f) { geom(); onSpin(dl, cx, cy, rad) }
        postInvalidateOnAnimation()
    }

    private fun norm(a: Float): Float {
        var x = a % 360f
        if (x > 180f) x -= 360f
        if (x <= -180f) x += 360f
        return x
    }

    private fun al(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun geom() {
        val w = width.toFloat(); val h = height.toFloat()
        when (mode) {
            0 -> { rad = min(w, h) / 2f - 46 * d; cx = w / 2f; cy = h / 2f }
            1 -> { rad = min(h * 0.46f, w * 0.78f); cx = w - 8 * d; cy = h / 2f }
            else -> { rad = w * 0.55f; cx = w / 2f; cy = h + rad * 0.35f }
        }
        rad *= sizeScale
    }

    override fun onDraw(c: Canvas) {
        val n = items.size
        if (n == 0) return
        geom(); hits.clear()
        if (thA.size != n) { thA = FloatArray(n); dsA = FloatArray(n); order = IntArray(n) }

        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f * d; p.color = al(ringColor, 70)
        c.drawCircle(cx, cy, rad, p)
        if (mode == 0) { p.color = al(ringColor, 30); c.drawCircle(cx, cy, rad - 52 * d, p) }

        val focus = if (mode == 1) -90f else 0f
        for (i in 0 until n) {
            thA[i] = norm(angle + i * step)
            dsA[i] = if (mode == 0) 0f else abs(norm(thA[i] - focus))
            order[i] = i
        }
        for (i in 1 until n) {                       // door wale pehle (insertion sort)
            val v = order[i]; var j = i - 1
            while (j >= 0 && dsA[order[j]] < dsA[v]) { order[j + 1] = order[j]; j-- }
            order[j + 1] = v
        }

        for (k in 0 until n) {
            val i = order[k]
            val rr = Math.toRadians(thA[i].toDouble())
            val x = cx + rad * sin(rr).toFloat()
            val y = cy - rad * cos(rr).toFloat()
            val scale = if (mode == 0) 1f else (1.2f - dsA[i] / 150f).coerceIn(0.7f, 1.2f)
            val a = if (mode == 0) 1f else (1f - dsA[i] / 170f).coerceIn(0.25f, 1f)
            val size = 40 * d * scale * iconScale
            if (x < size * 0.7f || x > width - size * 0.7f - (if (mode == 1) 14 * d else 0f)) continue
            if (y < size * 0.7f || y > height - size * 0.9f) continue

            p.style = Paint.Style.FILL; p.color = Color.argb((95 * a).toInt(), 0, 0, 0)
            c.drawCircle(x, y, size * 0.78f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.4f * d; p.color = al(ringColor, (170 * a).toInt())
            c.drawCircle(x, y, size * 0.78f, p)

            val h = (size / 2f).toInt()
            val ic = items[i].icon
            ic.setBounds((x - h).toInt(), (y - h).toInt(), (x + h).toInt(), (y + h).toInt())
            ic.alpha = (255 * a).toInt(); ic.draw(c)

            p.style = Paint.Style.FILL; p.typeface = tf; p.textAlign = Paint.Align.CENTER
            p.textSize = 12f * fs * d * (0.9f + 0.2f * (scale - 0.7f))
            p.color = al(textColor, (255 * a).toInt())
            c.drawText(items[i].label, x, y + size * 0.78f + 14 * d, p)
            p.textAlign = Paint.Align.LEFT

            hits.add(Hit(items[i], x, y, size * 0.9f))
        }
    }

    // ------------------------------ touch ------------------------------
    private fun angOf(x: Float, y: Float) =
        Math.toDegrees(atan2((x - cx).toDouble(), -(y - cy).toDouble())).toFloat()

    override fun onTouchEvent(e: MotionEvent): Boolean {
        geom()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                anim?.cancel()
                downX = e.x; downY = e.y; lastA = angOf(e.x, e.y)
                moved = false; longDone = false
                vt = VelocityTracker.obtain().also { it.addMovement(e) }
                postDelayed(longRun, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (!moved && hypot(e.x - downX, e.y - downY) > slop) { moved = true; removeCallbacks(longRun) }
                if (moved) {
                    val a2 = angOf(e.x, e.y)
                    setAngle(angle + norm(a2 - lastA)); lastA = a2
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longRun)
                vt?.addMovement(e)
                if (e.actionMasked == MotionEvent.ACTION_UP) {
                    if (!moved && !longDone) {
                        hits.filter { hypot(e.x - it.x, e.y - it.y) < it.r }
                            .minByOrNull { hypot(e.x - it.x, e.y - it.y) }?.let { onOpen(it.item) }
                    } else if (moved) fling(e)
                } else snapTo(angle, 450L, false)
                vt?.recycle(); vt = null
            }
        }
        return true
    }

    private fun fling(e: MotionEvent) {
        val v = vt ?: return
        v.computeCurrentVelocity(1000)
        val dx = e.x - cx; val dy = e.y - cy
        val r = hypot(dx, dy).coerceAtLeast(60 * d)
        val th = atan2(dx.toDouble(), -dy.toDouble())
        val omega = ((v.xVelocity * cos(th) + v.yVelocity * sin(th)) / r * 57.2958).toFloat()
        val dur = (550 + abs(omega) * 0.9f).toLong().coerceIn(550L, 1300L)
        snapTo(angle + (omega * 0.35f).coerceIn(-720f, 720f), dur, false)
    }

    private fun snapTo(target: Float, dur: Long, bounce: Boolean) {
        if (items.isEmpty()) return
        val k = ((target - off) / step).roundToInt()
        val end = off + k * step
        anim?.cancel()
        anim = ValueAnimator.ofFloat(angle, end).apply {
            duration = dur
            interpolator = if (bounce) OvershootInterpolator(2f) else PathInterpolator(0.16f, 0.85f, 0.22f, 1f)
            addUpdateListener { setAngle(it.animatedValue as Float) }
            start()
        }
    }

    /** Volume dabane par wheel ek jagah ghoom jata hai */
    fun kick(dir: Int) { snapTo(angle + dir * step, 700L, true) }

    override fun onDetachedFromWindow() {
        anim?.cancel(); removeCallbacks(longRun); super.onDetachedFromWindow()
    }
}
