package com.example.classiclauncher

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.HapticFeedbackConstants
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Gol (round) app wheel. Ungli se ghumao, chhodo to spring ki tarah ruk jata hai.
 * mode 0 = Circle, 1 = Arc (right side), 2 = Bottom wheel
 */
class WheelView(ctx: Context) : View(ctx) {

    class Item(val label: String, val icon: Drawable, val intent: Intent?)
    private class Hit(val item: Item, val x: Float, val y: Float, val r: Float)

    var items: List<Item> = emptyList()
    var mode = 0
    var accent = Color.parseColor("#D4AF37")
    var textColor = Color.WHITE
    var tf: Typeface = Typeface.DEFAULT
    var fs = 1f
    var onOpen: (Item) -> Unit = {}
    var onLong: () -> Unit = {}

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val hits = mutableListOf<Hit>()

    private var angle = 0f
    private var anim: ValueAnimator? = null
    private var cx = 0f; private var cy = 0f; private var rad = 0f
    private var downX = 0f; private var downY = 0f; private var lastA = 0f
    private var moved = false; private var longDone = false
    private var vt: VelocityTracker? = null
    private val longRun = Runnable {
        if (!moved) { longDone = true; performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); onLong() }
    }

    private val step get() = if (items.isEmpty()) 360f else 360f / items.size
    private val off get() = if (mode == 1) -90f else 0f      // jis jagah item "focus" mein rukta hai

    fun setup() { angle = off; invalidate() }

    private fun norm(a: Float): Float {
        var x = a % 360f
        if (x > 180f) x -= 360f
        if (x <= -180f) x += 360f
        return x
    }

    private fun a(c: Int, al: Int) = Color.argb(al.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun geom() {
        val w = width.toFloat(); val h = height.toFloat()
        when (mode) {
            0 -> { rad = min(w, h) / 2f - 46 * d; cx = w / 2f; cy = h / 2f }
            1 -> { rad = min(h * 0.46f, w * 0.78f); cx = w - 8 * d; cy = h / 2f }
            else -> { rad = w * 0.55f; cx = w / 2f; cy = h + rad * 0.35f }
        }
    }

    override fun onDraw(c: Canvas) {
        if (items.isEmpty()) return
        geom(); hits.clear()

        p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f * d; p.color = a(accent, 70)
        c.drawCircle(cx, cy, rad, p)
        if (mode == 0) { p.color = a(accent, 30); c.drawCircle(cx, cy, rad - 52 * d, p) }

        val focus = if (mode == 1) -90f else 0f
        data class Slot(val i: Int, val th: Float, val dist: Float)
        val slots = items.indices.map { i ->
            val th = norm(angle + i * step)
            Slot(i, th, if (mode == 0) 0f else abs(norm(th - focus)))
        }.sortedByDescending { it.dist }

        for (s in slots) {
            val rr = Math.toRadians(s.th.toDouble())
            val x = cx + rad * sin(rr).toFloat()
            val y = cy - rad * cos(rr).toFloat()
            val scale = if (mode == 0) 1f else (1.2f - s.dist / 150f).coerceIn(0.7f, 1.2f)
            val al = if (mode == 0) 1f else (1f - s.dist / 170f).coerceIn(0.25f, 1f)
            val size = 40 * d * scale
            if (x < size * 0.7f || x > width - size * 0.7f - (if (mode == 1) 14 * d else 0f)) continue
            if (y < size * 0.7f || y > height - size * 0.9f) continue

            p.style = Paint.Style.FILL; p.color = Color.argb((95 * al).toInt(), 0, 0, 0)
            c.drawCircle(x, y, size * 0.78f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 1.4f * d; p.color = a(accent, (170 * al).toInt())
            c.drawCircle(x, y, size * 0.78f, p)

            val h = (size / 2f).toInt()
            val ic = s.let { items[it.i].icon }
            ic.setBounds((x - h).toInt(), (y - h).toInt(), (x + h).toInt(), (y + h).toInt())
            ic.alpha = (255 * al).toInt(); ic.draw(c)

            p.style = Paint.Style.FILL; p.typeface = tf; p.textAlign = Paint.Align.CENTER
            p.textSize = 12f * fs * d * (0.9f + 0.2f * (scale - 0.7f))
            p.color = a(textColor, (255 * al).toInt())
            c.drawText(items[s.i].label, x, y + size * 0.78f + 14 * d, p)
            p.textAlign = Paint.Align.LEFT

            hits.add(Hit(items[s.i], x, y, size * 0.9f))
        }
    }

    // ------------------------------ touch ------------------------------
    private fun angOf(x: Float, y: Float) =
        Math.toDegrees(atan2((x - cx).toDouble(), -(y - cy).toDouble())).toFloat()

    override fun onTouchEvent(e: MotionEvent): Boolean {
        geom()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                anim?.cancel()
                downX = e.x; downY = e.y; lastA = angOf(e.x, e.y)
                moved = false; longDone = false
                vt = VelocityTracker.obtain().also { it.addMovement(e) }
                postDelayed(longRun, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                if (!moved && hypot(e.x - downX, e.y - downY) > slop) { moved = true; removeCallbacks(longRun) }
                if (moved) {
                    val a2 = angOf(e.x, e.y)
                    angle += norm(a2 - lastA); lastA = a2
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longRun)
                vt?.addMovement(e)
                if (e.actionMasked == MotionEvent.ACTION_UP) {
                    if (!moved && !longDone) {
                        hits.filter { hypot(e.x - it.x, e.y - it.y) < it.r }
                            .minByOrNull { hypot(e.x - it.x, e.y - it.y) }?.let { onOpen(it.item) }
                    } else if (moved) fling(e)
                } else snapTo(angle, false)
                vt?.recycle(); vt = null
            }
        }
        return true
    }

    private fun fling(e: MotionEvent) {
        val v = vt ?: return
        v.computeCurrentVelocity(1000)
        val dx = e.x - cx; val dy = e.y - cy
        val r = hypot(dx, dy).coerceAtLeast(60 * d)
        val th = atan2(dx.toDouble(), -dy.toDouble())
        val omega = ((v.xVelocity * cos(th) + v.yVelocity * sin(th)) / r * 57.2958).toFloat()
        snapTo(angle + (omega * 0.22f).coerceIn(-400f, 400f), false)
    }

    private fun snapTo(target: Float, bounce: Boolean) {
        if (items.isEmpty()) return
        val k = ((target - off) / step).roundToInt()
        val end = off + k * step
        anim?.cancel()
        anim = ValueAnimator.ofFloat(angle, end).apply {
            duration = if (bounce) 650 else 550
            interpolator = if (bounce) OvershootInterpolator(2.2f) else DecelerateInterpolator(1.6f)
            addUpdateListener { angle = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    /** Volume dabane par wheel ek jagah ghoom jata hai */
    fun kick(dir: Int) { snapTo(angle + dir * step, true) }

    override fun onDetachedFromWindow() {
        anim?.cancel(); removeCallbacks(longRun); super.onDetachedFromWindow()
    }
}
